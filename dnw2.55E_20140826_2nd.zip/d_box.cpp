#define STRICT
#define WIN32_LEAN_AND_MEAN

#include "resource.h" /* warning fix */


#include <windows.h>
#include <windowsx.h>
#include <commctrl.h>
#include <tchar.h>
#include <string.h>
#include <process.h>
#include <stdlib.h>
//#include </include/wx/ctb/win32/serport.h>
//#include <serport.h>


#include "def.h"
#include "d_box.h"
#include "dnw.h"
#include "engine.h"
#include "fileopen.h"
#include "regmgr.h"  /// added.
#include "rwbulk.h" /// added.

#include <stdio.h>
#include <time.h>
#include <memory.h> /// added.


FILE 	*fFileWrite = NULL;
unsigned char buff_fin[DATE_LEN] = { 0, };

#define UMON_TEXT_CONFIG 	".\\dnwconfig\\dnw_UmonTx.ini"
#define UMON_FILES_NUM 		2

#define EBOOT_IDX 		0
#define STEPLDR_IDX 	1	
#define NK_IDX 			2	


#define USER_TEXT_CONFIG 	".\\dnwconfig\\dnw_usbboot.ini"
#define NAND_FILES_NUM 		3


BOOL isFileExist(TCHAR *file);
extern int   BinFileIndex; /// added.
extern WORD  DownloadedBin; /// added.

extern TCHAR szFileName[FILENAMELEN];
extern TCHAR szUmonFileName[FILENAMELEN]; /// added.
extern HINSTANCE hInstance;
extern HWND _EditHwnd, _MainHwnd; /// added.
extern void SetFont(HWND hwndEdit);


#if defined(COLOR_DISP2) /// 2010.05.14
extern HBRUSH m_Brush; /// background color
extern DWORD ColorTable[]; ///COLOR_NUM_MAX
#endif

// 'volatile' is important because _hDlgDownloadProgress is accessed in two threads.
volatile HWND _hDlgDownloadProgress=NULL; 
HWND _hProgressControl;
volatile HWND _hDlgSerialSettings;

int downloadCanceled;


extern int idBaudRate,userBaudRate;
extern int userComPort;
extern int autoSendKey, msgSaveOnOff, msgMode, localTime;
extern int FontType;
extern int RetryUSB; /// 2012.03.10

#if defined(COLOR_DISP2) /// 2010.05.14
extern int ColorType; /// 2010.05.14 added
#endif

extern int CPUtype; /// 6410:0, SMDKC100:1
BOOL bCheckedCPU = FALSE;
BOOL bBaudrate = FALSE;


extern int TotalROMfilenum, UmonFileNum;
extern int TotalRAMfils;

extern DWORD downloadAddress;
extern TCHAR szDownloadAddress[ADDR_LENGTH];

extern TCHAR szUserBaudRate[16]; /// 2014.04.15

#ifdef HEXA_MODE_SUPPORT	/* 2012.07.03 Hexa mode display */
extern DWORD ColumnNumber;
extern TCHAR szColumnNumber[16];
#endif

#ifdef COM_SETTINGS /// 2012.07.11
extern int userCOMparity, userCOMstop, userCOMdataIdx;
static int tempCOMparity;
static int tempCOMstop;
static int tempCOMdataIdx=1; /// 8bit default
#endif

static int tempIdBaudRate,tempComPort;
static int tempAutoSend, tempMsgSave, tempLocalTime, tempCPUtype;
static int tempFontType;
static int tempRetryUSB;
#if 1 /* 2011.02.09 , Hexa mode */
static int tempOutMode; /* Text display or Hexa display */
#endif
#if defined(COLOR_DISP2)
static int tempColorType;
#endif


extern int transmitMenuNumber;
extern int UbootMenuNumber;
extern int UbootMenuNumber2;
extern TCHAR szDownloadString[MAXHISTORY][FILENAMELEN];
//#ifdef SANSIX_SMP201_CUSTOMIZING
extern TCHAR szQuickDownloadString[MAXHISTORY][FILENAMELEN];
extern TCHAR szQuickFileName[MAXHISTORY][FILENAMELEN];
extern TCHAR szUMONDownloadString[MAXHISTORY][FILENAMELEN];
extern TCHAR szUMONSFileName[MAXHISTORY][FILENAMELEN];
//#endif


UINT hex2int(TCHAR *str);
UINT str2int(TCHAR *str);


int WriteQuickUserConfig(void);
BOOL LOGFile_open(void);
void LOGFile_close(void);


BOOL CALLBACK DownloadProgressProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	TCHAR szTitle[FILENAMELEN] = {0,};
	TCHAR tUSBspeed[32] = {0,};

	switch(message)
	{
	    case WM_INITDIALOG:

			if( USB_TX_SIZE >= (4096*4) ) ///   TX_SIZE_1 ) /* 2013.04.22 */
			{
				lstrcpy(szTitle,TEXT("Downloading "));

				//////////////2010.5.27 added ////////////////////
				sprintf(tUSBspeed,"[%dK] ", (USB_TX_SIZE/1024) );
				lstrcat(szTitle, tUSBspeed);
				////////////////////////////////////////////////
				
				lstrcat(szTitle,szFileName);
				SetWindowText(hDlg,szTitle);
				_hDlgDownloadProgress=hDlg;
			}
			else
			{ /// 2013.04.22 added...
				downloadCanceled = 1;
				EB_Printf(TEXT("[dnw] DownloadProgressProc() error, USB_TX_SIZE[%d], szFileName=%s \r\n"),  USB_TX_SIZE , szFileName );
			}
			return TRUE;
		
	    case WM_CLOSE: 
			//If the [X] button is clicked, WM_CLOSE message is received.
			//Originally, DefWindowProc() called DestroyWindow();
			//But, there is no DefWindowProc(), We have to process WM_CLOSE message.
			if( hDlg )
			{
				DestroyWindow(hDlg); 
				CloseHandle(hDlg); 
				hDlg=NULL; 
			} /// added.

			if( _hDlgDownloadProgress ) 
			{
				DestroyWindow(_hDlgDownloadProgress);
				CloseHandle(_hDlgDownloadProgress);
				_hDlgDownloadProgress=NULL;
			}
			downloadCanceled=1;
			//break;
			return TRUE; //why not?
    }

    return FALSE;
}

void InitDownloadProgress(void)
{
    while( NULL == _hDlgDownloadProgress )
    {
		Sleep(0); //wait until the progress dialog box is ready.
    }

    _hProgressControl = GetDlgItem(_hDlgDownloadProgress,IDC_PROGRESS1);
    SendMessage(_hProgressControl,PBM_SETRANGE,0,MAKELPARAM(0, 100));
    downloadCanceled=0;
}

void DisplayDownloadProgress(int percent)
{
    SendMessage(_hProgressControl,PBM_SETPOS,(WPARAM)percent,0); 
}
    
void CloseDownloadProgress(void)
{
    if(_hDlgDownloadProgress!=NULL)
    {
    	//DestroyWindow(_hDlgDownloadProgress); 
	//Doesn't work because CloseDownloadProgress() is called another thread,
	//which is different the thread calling CreatDialog().
    
        SendMessage(_hDlgDownloadProgress,WM_CLOSE,0,0); 
    	_hDlgDownloadProgress=NULL;
    }
}


BOOL CALLBACK OptionsProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
    int tmp;
	static BOOL ctemp;
	static int iprevCPUtype = 1;

    switch(message)
    {
    case WM_INITDIALOG:
		_hDlgSerialSettings=hDlg;

		tempIdBaudRate = idBaudRate;
		tempComPort    = userComPort;
		tempAutoSend   = autoSendKey;
		tempLocalTime  = localTime;
		tempMsgSave    = msgSaveOnOff;
		tempFontType   = FontType;
#ifdef HEXA_MODE_SUPPORT	/* 2011.02.08 Hexa mode display */
		tempOutMode    = msgMode; /* Text display or Hexa display */
#endif

		tempRetryUSB   = RetryUSB;

#if defined(COLOR_DISP2)
		tempColorType  = ColorType;
#endif

		/// 2014.04.11, added
		tempCPUtype    = CPUtype;


		CheckRadioButton(hDlg,IDC_RADIO921600,IDC_RADIO2400,IDC_RADIO921600+tempIdBaudRate);
		CheckRadioButton(hDlg,IDC_RADIOCOM0,IDC_RADIOCOM37,IDC_RADIOCOM0+(tempComPort /*-1*/));

		/* SPACE-BAR key auto send on/off */
		CheckRadioButton(hDlg,IDC_RADIO_AUTO_SEND_OFF,IDC_RADIO_AUTO_SEND_ON,IDC_RADIO_AUTO_SEND_OFF+tempAutoSend);

		/* Message log save on/off */
		CheckRadioButton(hDlg,IDC_RADIO_MSG_SAVE_OFF,IDC_RADIO_MSG_SAVE_ON,IDC_RADIO_MSG_SAVE_OFF+tempMsgSave);

		/* Font style */
		CheckRadioButton(hDlg,IDC_FONT0_OEM_FIX, IDC_FONT3_SYSTEM_FIX, IDC_FONT0_OEM_FIX+tempFontType);

#ifdef HEXA_MODE_SUPPORT	/* 2011.02.08 Hexa mode display */
		/* Text / Hex mode */
		CheckRadioButton(hDlg,IDC_OUT_TEXT_MODE, IDC_OUT_HEXA1_MODE, IDC_OUT_TEXT_MODE+tempOutMode);
#endif

		/* 2012.03.10, Retry USB port */
		CheckRadioButton(hDlg,IDC_RETRY_USB_DEFAULT, IDC_RETRY_USB_40_TIMES, IDC_RETRY_USB_DEFAULT+tempRetryUSB);

#ifdef COM_SETTINGS /// 2012.07.11
		/* 2012.07.11, COM port - parity */
		CheckRadioButton(hDlg,IDC_COM_NOPARITY, IDC_COM_SPACEPARITY, IDC_COM_NOPARITY+tempCOMparity);

		/* 2012.07.11, COM port - stop bit */
		CheckRadioButton(hDlg,IDC_COM_ONESTOPBIT, IDC_COM_TWOSTOPBITS, IDC_COM_ONESTOPBIT+tempCOMstop);

		/* 2012.07.11, COM port - data bit */
		CheckRadioButton(hDlg,IDC_COM_DATA_7BIT, IDC_COM_DATA_8BIT, IDC_COM_DATA_7BIT+tempCOMdataIdx);
#endif


		CheckRadioButton(hDlg,IDC_LOCALTIME_NONE, IDC_LOCALTIME_DATETIME, IDC_LOCALTIME_NONE+tempLocalTime);

		/// 2014.4.10 added
		CheckRadioButton(hDlg,IDC_CPU_SMDK6410, IDC_CPU_SMDKC100, IDC_CPU_SMDK6410+tempCPUtype);



#if defined(COLOR_DISP2)
		/* Color background */
		CheckRadioButton(hDlg,IDC_COLOR_TYPE_GRAY, IDC_COLOR_TYPE_BLACK, IDC_COLOR_TYPE_GRAY+tempColorType);
#endif


		SendMessage(GetDlgItem(hDlg,IDC_EDIT1),EM_REPLACESEL,0,(LPARAM)(LPCSTR)szDownloadAddress);  

		
		/// 2014.04.15, Baudrate ---
		if( userBaudRate > 0 )
		{
			wsprintf(szUserBaudRate, "%d", userBaudRate);
		}
		else if( 0xFFFF != idBaudRate )
		{
			userBaudRate = baudTable[idBaudRate];
			wsprintf(szUserBaudRate, "%d", userBaudRate);
	    }
		else
		{
			idBaudRate = 8;
			userBaudRate = baudTable[idBaudRate];
			wsprintf(szUserBaudRate, "%d", userBaudRate);
		}
		SendMessage(GetDlgItem(hDlg,IDC_EDIT2),EM_REPLACESEL,0,(LPARAM)(LPCSTR)szUserBaudRate);	


#ifdef HEXA_MODE_SUPPORT	/* 2012.07.03 Hexa mode display */
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_HEX_COL),EM_REPLACESEL,0,(LPARAM)(LPCSTR)szColumnNumber);  
#endif		


    	return TRUE;



    case WM_COMMAND:
		switch(LOWORD(wParam))
		{
		case IDOK:

			if( bCheckedCPU )
			{
				bCheckedCPU = FALSE;

				/// 2014.04.11, added
				switch( tempCPUtype )
				{
					case 0: /// SMDK6410,  IDC_CPU_SMDK6410
						downloadAddress=0x50100000;
						lstrcpy(szDownloadAddress,TEXT("0x50100000"));
						break;

					case 1: /// SMDKC100, IDC_CPU_SMDKC100
					default:
						downloadAddress=0x20030000;
						lstrcpy(szDownloadAddress,TEXT("0x20030000"));
						break;
				}

				CPUtype = tempCPUtype;

			}
			else
			{

			    //get downloadAddress
			    *((WORD *)szDownloadAddress)=15;
				//The first WORD should be max character number for EM_GETLINE!
			    tmp=SendMessage(GetDlgItem(hDlg,IDC_EDIT1),
						        EM_GETLINE,(WPARAM)0,(LPARAM)(LPCSTR)szDownloadAddress);
			    szDownloadAddress[tmp]='\0'; //EM_GETLINE string doesn't have '\0'.
			    downloadAddress=hex2int(szDownloadAddress);	     
			}


			if( bBaudrate )  /// Checked Button !!!
			{
				bBaudrate = FALSE;

				wsprintf(szUserBaudRate, "%d", userBaudRate);

			}
			else
			{
				static int iEditBaud = 0;
				int  iBaud;
				BOOL bBaudOK = FALSE;
			
				/// 2014.04.15, UART baudrate
				//get downloadAddress
				*((WORD *)szUserBaudRate)=15;
				//The first WORD should be max character number for EM_GETLINE!
				tmp=SendMessage(GetDlgItem(hDlg,IDC_EDIT2),
								EM_GETLINE,(WPARAM)0,(LPARAM)(LPCSTR)szUserBaudRate);
				szUserBaudRate[tmp]='\0'; //EM_GETLINE string doesn't have '\0'.
				iEditBaud = str2int(szUserBaudRate); 	 

				bBaudOK = FALSE;
				for(iBaud=0; iBaud<BAUD_RATE_NUM; iBaud++)
				{
					if( iEditBaud == baudTable[iBaud] )
					{
						idBaudRate   = tempIdBaudRate = iBaud;  /// index
						userBaudRate = baudTable[idBaudRate];
						bBaudOK = TRUE;
						break;
					}
				}
				if( FALSE == bBaudOK )
				{
					idBaudRate   = tempIdBaudRate = 0xFFFF; /// NOne  Index In COM Port List 
					userBaudRate = iEditBaud;
				}
			}



#ifdef HEXA_MODE_SUPPORT	/* 2012.07.03 Hexa mode display */
			*((WORD *)szColumnNumber)=15;
		    tmp=SendMessage(GetDlgItem(hDlg,IDC_EDIT_HEX_COL),
					        EM_GETLINE,(WPARAM)0,(LPARAM)(LPCSTR)szColumnNumber);
		    szColumnNumber[tmp]='\0'; //EM_GETLINE string doesn't have '\0'.
		    ColumnNumber=str2int(szColumnNumber);
#endif


		    EndDialog(hDlg,1);

			if( 0xFFFF != tempIdBaudRate )
			{
			    idBaudRate    = tempIdBaudRate;
			    userBaudRate  = baudTable[idBaudRate];
			}
		    userComPort   = tempComPort;
			autoSendKey   = tempAutoSend; /// added.
			localTime     = tempLocalTime;
			BinFileIndex  = 0; /* automatic 1st index */
			DownloadedBin = 0x00;

			msgSaveOnOff  = tempMsgSave; /// added.
			FontType      = tempFontType; /// added.
#ifdef HEXA_MODE_SUPPORT	/* 2011.02.08 Hexa mode display */
			msgMode 	  = tempOutMode; /* 2011.02.08, Text display or Hexa display */
#endif

			RetryUSB      = tempRetryUSB; /// 2012.03.10

#if defined(COLOR_DISP2)
			ctemp = ColorType;
			ColorType = tempColorType;
#endif


#ifdef COM_SETTINGS /// 2012.07.11
			userCOMparity  = tempCOMparity;
			userCOMstop    = tempCOMstop;
			userCOMdataIdx = tempCOMdataIdx;
#endif


			SetFont( _EditHwnd ); /// added.

		    WriteUserConfig();

			WriteQuickUMONConfig(); /// added.
			///WriteQuickUserConfig(); /// added.

			LOGFile_open(); /// added.
		
			SetRegistry();

			if( hDlg ) { CloseHandle(hDlg); } /// added. 

#if defined(COLOR_DISP2) /// 2010.05.14
			/* background color �� �����ϸ� �̻��Ͽ� appl ������ �ٽ� �����϶� !!*/
			if( ctemp != ColorType )
			{
				MessageBox( _MainHwnd, TEXT("Color style is changed.\n"), "Save",MB_OK);
				SendMessage( _MainHwnd, WM_COMMAND, CM_EXIT, 0 );
			}
#endif
		    return TRUE;

		case IDCANCEL:
		    EndDialog(hDlg,0);
			if( hDlg ) { CloseHandle(hDlg); } /// added.
		    return TRUE;

		case IDC_RADIOCOM0:
		case IDC_RADIOCOM1:
	    case IDC_RADIOCOM2:
		case IDC_RADIOCOM3:
		case IDC_RADIOCOM4:
		case IDC_RADIOCOM5:
		case IDC_RADIOCOM6:
		case IDC_RADIOCOM7:
		case IDC_RADIOCOM8:
		case IDC_RADIOCOM9:
		case IDC_RADIOCOM10:
		case IDC_RADIOCOM11:
		case IDC_RADIOCOM12:
		case IDC_RADIOCOM13:
		case IDC_RADIOCOM14:
		case IDC_RADIOCOM15:  
		case IDC_RADIOCOM16:
		case IDC_RADIOCOM17:
		case IDC_RADIOCOM18:
		case IDC_RADIOCOM19:
		case IDC_RADIOCOM20:
		case IDC_RADIOCOM21:
		case IDC_RADIOCOM22:
		case IDC_RADIOCOM23:
		case IDC_RADIOCOM24:
		case IDC_RADIOCOM25:  
		case IDC_RADIOCOM26:
		case IDC_RADIOCOM27:
		case IDC_RADIOCOM28:
		case IDC_RADIOCOM29:
		case IDC_RADIOCOM30:
		case IDC_RADIOCOM31:
		case IDC_RADIOCOM32:
		case IDC_RADIOCOM33:
		case IDC_RADIOCOM34:
		case IDC_RADIOCOM35:  
		case IDC_RADIOCOM36:
		case IDC_RADIOCOM37:
		    tempComPort=LOWORD(wParam)-IDC_RADIOCOM0 /*+1*/;
		    return TRUE;


		case IDC_RADIO921600:  /* 921.6 Kbps */
		case IDC_RADIO460800:
		case IDC_RADIO380400:
		case IDC_RADIO312500:  /// added 2011.1.27
		case IDC_RADIO256000:
		case IDC_RADIO230400:
		case IDC_RADIO153600:  /// added 2011.1.27, AVC-LAN comm.
		case IDC_RADIO128000:
	    case IDC_RADIO115200:
		case IDC_RADIO76800: /// 2011.12.16 added
		case IDC_RADIO57600:
		case IDC_RADIO56000:
		case IDC_RADIO38400:
		case IDC_RADIO31250:   /// added 2011.1.27
		case IDC_RADIO19200:
		case IDC_RADIO14400:
		case IDC_RADIO9600:
		case IDC_RADIO4800:
		case IDC_RADIO2400:
		    tempIdBaudRate=LOWORD(wParam)-IDC_RADIO921600;

			bBaudrate = TRUE;

		#if 1 /// 2014.08.26
			userBaudRate = baudTable[tempIdBaudRate];

			memset( szUserBaudRate, 0x00, sizeof(szUserBaudRate) );
			wsprintf(szUserBaudRate, "%d", userBaudRate);

			/// display clear ---------------
			SendMessage(GetDlgItem(hDlg,IDC_EDIT2),EM_SETSEL,0,-1); 
			SendMessage(GetDlgItem(hDlg,IDC_EDIT2),EM_REPLACESEL,0, (LPARAM)""); 
			
			/// new address displayed
			SendMessage(GetDlgItem(hDlg,IDC_EDIT2),EM_REPLACESEL, (WPARAM)0,(LPARAM)(LPCSTR)szUserBaudRate); 
		#endif

		    return TRUE;

	
		case IDC_RADIO_AUTO_SEND_OFF:
		case IDC_RADIO_AUTO_SEND_ON:
			tempAutoSend=LOWORD(wParam)-IDC_RADIO_AUTO_SEND_OFF;
			return TRUE;

		case IDC_RADIO_MSG_SAVE_OFF:
		case IDC_RADIO_MSG_SAVE_ON:
			tempMsgSave=LOWORD(wParam)-IDC_RADIO_MSG_SAVE_OFF;
			return TRUE;

		case IDC_FONT0_OEM_FIX:
		case IDC_FONT1_ANSI_FIX:
		case IDC_FONT2_DEVICE:
		case IDC_FONT3_SYSTEM_FIX:
			tempFontType=LOWORD(wParam)-IDC_FONT0_OEM_FIX;
			return TRUE;

		case IDC_RETRY_USB_DEFAULT:
		case IDC_RETRY_USB_20_TIMES:
		case IDC_RETRY_USB_30_TIMES:
		case IDC_RETRY_USB_40_TIMES:
			tempRetryUSB=LOWORD(wParam)-IDC_RETRY_USB_DEFAULT;
			return TRUE;

#ifdef HEXA_MODE_SUPPORT	/* 2011.02.08 Hexa mode display */
		/* Text display or Hexa display */
		case IDC_OUT_TEXT_MODE:
		case IDC_OUT_HEXA1_MODE:
		//case IDC_OUT_HEXA2_MODE:
			tempOutMode=LOWORD(wParam)-IDC_OUT_TEXT_MODE;
			return TRUE;
#endif

#if defined(COLOR_DISP2) /// 2010.05.14
		case IDC_COLOR_TYPE_GRAY:
		case IDC_COLOR_TYPE_BLACK:
			tempColorType=LOWORD(wParam)-IDC_COLOR_TYPE_GRAY;
			return TRUE;
#endif 


#ifdef COM_SETTINGS /// 2012.07.11

		/* 2012.07.11, COM port - parity */
		case IDC_COM_NOPARITY: /// 0 // NOPARITY
		case IDC_COM_ODDPARITY: /// 1
		case IDC_COM_EVENPARITY: /// 2
		case IDC_COM_MARKPARITY: /// 3
		case IDC_COM_SPACEPARITY: /// 4
			tempCOMparity=LOWORD(wParam)-IDC_COM_NOPARITY;
			return TRUE;
		
		case IDC_COM_ONESTOPBIT: /// 0  (1 stop bit)
		case IDC_COM_ONE5STOPBITS: /// 1 ( 1.5 stop bits.)
		case IDC_COM_TWOSTOPBITS: /// 2 (2 stop bit)
			tempCOMstop=LOWORD(wParam)-IDC_COM_ONESTOPBIT;
			return TRUE;
		
		case IDC_COM_DATA_7BIT: /// 7 bit
		case IDC_COM_DATA_8BIT: /// 8 bit
			tempCOMdataIdx=LOWORD(wParam)-IDC_COM_DATA_7BIT; /* 7, 8*/
			return TRUE;
#endif

		case IDC_LOCALTIME_NONE:
		case IDC_LOCALTIME_TIMEONLY:
		case IDC_LOCALTIME_DATETIME:
			tempLocalTime=LOWORD(wParam)-IDC_LOCALTIME_NONE;
			return TRUE;

		/// 2014.04.11, added
		case IDC_CPU_SMDK6410:
		case IDC_CPU_SMDKC100:
			tempCPUtype=LOWORD(wParam)-IDC_CPU_SMDK6410;
			bCheckedCPU = TRUE;

		#if 1 /// 2014.08.26
			if( bCheckedCPU )
			{
				bCheckedCPU = FALSE;

				/// 2014.04.11, added
				switch( tempCPUtype )
				{
					case 0: /// SMDK6410,  IDC_CPU_SMDK6410
						downloadAddress=0x50100000;
						memset( szDownloadAddress, 0x00, sizeof(szDownloadAddress) );
						lstrcpy(szDownloadAddress,TEXT("0x50100000"));
						break;

					case 1: /// SMDKC100, IDC_CPU_SMDKC100
					default:
						downloadAddress=0x20030000;
						memset( szDownloadAddress, 0x00, sizeof(szDownloadAddress) );
						lstrcpy(szDownloadAddress,TEXT("0x20030000"));
						break;
				}

				CPUtype = tempCPUtype;

				/// display clear ---------------
				SendMessage(GetDlgItem(hDlg,IDC_EDIT1),EM_SETSEL,0,-1); 
				SendMessage(GetDlgItem(hDlg,IDC_EDIT1),EM_REPLACESEL,0, (LPARAM)""); 

				/// new address displayed
				SendMessage(GetDlgItem(hDlg,IDC_EDIT1),EM_REPLACESEL, (WPARAM)0,(LPARAM)(LPCSTR)szDownloadAddress);	

			}
		#endif /// 2014.08.26

			return TRUE;

		default:
			return FALSE;


		}

		return FALSE;


    default:
		return FALSE;
    }
    return FALSE;
}


//ReadUserConfig() is called once at first
int ReadUserConfig(HWND hwnd)
{
	HANDLE hFile = NULL;
	DWORD fileSize;
	DWORD CurrentPoint;
	DWORD temp;
	TCHAR *buf = NULL;
	TCHAR *token = NULL;
    DWORD i, j;
	HMENU MenuBar;
	HMENU SubMenuBar;
	int   iTx=0;

	for ( i = 0; i < MAXHISTORY; i++ )
	{
		szDownloadString[i][0] = '\0';
	}

    hFile = CreateFile(DNW_LOG_FILE,GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,0,NULL);
    
    if( INVALID_HANDLE_VALUE==hFile || NULL==hFile )
    {
AAAA:

	#if 0 /// 2014.04.14
		//EB_Printf(TEXT("[dnw] [ERROR:Can't open dnw.ini. So, the default configuration is used.]\n") );
		userComPort=1;
		idBaudRate=8; /* 115200 bps*/
//		autoSendKey=0; /// added.
//		tempMsgSave=0;
//		tempOutMode=0;

		userBaudRate=baudTable[idBaudRate];
		///downloadAddress=0xc000000;
		///lstrcpy(szDownloadAddress,TEXT("0xc000000"));


		downloadAddress=0x20030000;
		lstrcpy(szDownloadAddress,TEXT("0x20030000"));

		#ifdef COM_SETTINGS /// 2012.07.11
		userCOMparity = 0; //// IDC_COM_NOPARITY
		userCOMstop = 0; /// IDC_COM_ONESTOPBIT
		userCOMdataIdx = 1; /// index1: 8bit , IDC_COM_DATA_8BIT
		#endif

	#endif /// deleted at 2014.04.14---
	
	
	#ifdef HEXA_MODE_SUPPORT	/* 2012.07.03 Hexa mode display */
		ColumnNumber = 0;
		lstrcpy(szColumnNumber,TEXT("0"));
	#endif

		return TRUE;
    }



    fileSize = GetFileSize(hFile,NULL);
	if(fileSize == 0)
	{
		MessageBox(hwnd, TEXT("[dnw] ERROR:dnw.ini is corrupted!!!"), NULL,MB_OK);
		if(hFile) CloseHandle(hFile);
		goto AAAA;
	}

	CurrentPoint = 0;
    buf = (char *)malloc(fileSize);
	if( NULL==buf )
	{
		MessageBox(hwnd, TEXT("[dnw] buf is NULL !!!"), NULL,MB_OK);
		if(hFile) CloseHandle(hFile);
		goto AAAA;
	}
	
	memset(buf, 0, sizeof(TCHAR)*fileSize);
    
    ReadFile(hFile,buf,fileSize,&temp,NULL);


#if 0 /// 2014.04.14
    userComPort = *((TCHAR *)buf+0)-'0';	    //UNICODE problem!!!
    idBaudRate  = *((TCHAR *)buf+1)-'0';	    //UNICODE problem!!!
	//autoSendKey = *((TCHAR *)buf+2)-'0';  /// added.

    userBaudRate=baudTable[idBaudRate];

 #define ADDR_START 		2  /// 2
 
    if(buf[ADDR_START]!='\n')
    {

		for(i=0;i<fileSize;i++) //search first '\n'
		{
			if(buf[i]=='\n')
			{
				token = &buf[i+1];
				break;
			}
		}
		CurrentPoint = i+1;
//		token = strtok(buf, "\n");
		strncpy(szDownloadAddress,(TCHAR *)buf+ADDR_START, i-ADDR_START);
		downloadAddress=hex2int(szDownloadAddress);	
		token = &buf[CurrentPoint];
    }
    else
    {
		///downloadAddress=0xc000000;
		///lstrcpy(szDownloadAddress,TEXT("0xc000000"));

	#if 1
		/// ------- 2014.04.11, added -------
		switch( CPUtype )
		{
			case 0: /// SMDK6410,  IDC_CPU_SMDK6410
				downloadAddress=0x50100000;
				lstrcpy(szDownloadAddress,TEXT("0x50100000"));
				break;
	
			case 1: /// SMDKC100, IDC_CPU_SMDKC100
			default:
				downloadAddress=0x20030000;
				lstrcpy(szDownloadAddress,TEXT("0x20030000"));
				break;
		}

	#else
		downloadAddress=0x20030000;
		lstrcpy(szDownloadAddress,TEXT("0x20030000"));
	#endif		

    }

#ifdef COM_SETTINGS /// 2012.07.11
	userCOMparity = 0; //// IDC_COM_NOPARITY
	userCOMstop = 0; /// IDC_COM_ONESTOPBIT
	userCOMdataIdx = 1; /// index 1, 8bit IDC_COM_DATA_8BIT
#endif

#endif /// deleted at 2014.04.14---



#ifdef HEXA_MODE_SUPPORT	/* 2012.07.03 Hexa mode display */
	/// Default::::
	ColumnNumber = 0;
	lstrcpy(szColumnNumber,TEXT("0"));
#endif



//	token = strtok(buf, "\n");
	for ( i = 0; i < MAXHISTORY; i++ )
	{
		for(j=0;j<fileSize-CurrentPoint;j++)
		{
			if(buf[CurrentPoint+j]=='\n')
			{
				CurrentPoint += (j+1);
				break;
			}
		}
		if ( j != 0 )
		{
			strncpy(szDownloadString[i], token, j);
			if ( i < (MAXHISTORY/3) ) transmitMenuNumber++;
			if ( i >= (MAXHISTORY/3) && i < MAXHISTORY*2/3 ) UbootMenuNumber++;
			if ( i >= (MAXHISTORY*2/3) && i < MAXHISTORY ) UbootMenuNumber2++;
		}
		token = &buf[CurrentPoint];
	}

    if(buf) free(buf);
    if(hFile) CloseHandle(hFile);

	MenuBar = GetSubMenu(GetMenu(hwnd), 1);
	SubMenuBar = GetSubMenu(MenuBar, 0);
	for ( iTx = 0; iTx < transmitMenuNumber; iTx++ )
	{
		AppendMenu(SubMenuBar, MF_STRING, HISTORYMENUID + iTx, szDownloadString[iTx]);
	}

	MenuBar = GetSubMenu(GetMenu(hwnd), 1);
	SubMenuBar = GetSubMenu(MenuBar, 1);
	for ( iTx = (MAXHISTORY*2/3); iTx < (MAXHISTORY*2/3)+UbootMenuNumber2; iTx++ )
	{
		AppendMenu(SubMenuBar, MF_STRING, HISTORYMENUID + iTx, szDownloadString[iTx]);
	}

    return TRUE;
}


BOOL isFileExist(TCHAR *file)
{
	if(0==lstrcmp(file,TEXT("")) || NULL==file) return FALSE;

	HANDLE hFind = NULL;
	WIN32_FIND_DATA fd;

	memset( &fd, 0x00, sizeof(WIN32_FIND_DATA) );

	hFind = FindFirstFile (file, &fd);
	if (hFind != INVALID_HANDLE_VALUE) 
	{
		FindClose (hFind);
		return TRUE;
	}

	return FALSE;
}


int WriteUserConfig(void)
{
    HANDLE hFile = NULL;
    DWORD temp;
    TCHAR buf[MAXHISTORY*FILENAMELEN+1] = {0,};
	int i;
	DWORD dwFileAttr, dwError;

	if( isFileExist(DNW_LOG_FILE) )
	{
		dwFileAttr = FILE_ATTRIBUTE_ARCHIVE;
		
		if( FALSE == SetFileAttributes(DNW_LOG_FILE, dwFileAttr) )
		{
			dwError = GetLastError();					
			EB_Printf(TEXT("[dnw]::WriteUserConfig FileAttr:1:[0x%X], dwError(%d) \r\n"), DNW_LOG_FILE, dwFileAttr, dwError  );
		}
	}

    hFile = CreateFile(DNW_LOG_FILE, GENERIC_WRITE,
					     FILE_SHARE_WRITE,NULL,CREATE_ALWAYS,0,NULL);
    
    if( (INVALID_HANDLE_VALUE==hFile) || (NULL==hFile) )
    {
		EB_Printf(TEXT("[dnw] can not create dnw.ini file. (L:%d, Error=%u) \n"),  __LINE__ , GetLastError() );
		return FALSE;
    }

#if 0 /// 2014.04.14
    buf[0]=userComPort+'0';
    buf[1]=idBaudRate+'0';
    ///buf[2]=autoSendKey+'0'; /// added.
    lstrcpy(buf+2,szDownloadAddress);
    lstrcat(buf,TEXT("\n"));
//    lstrcat(&buf[0],TEXT("||+download Address\n"));
//    lstrcat(&buf[0],TEXT("|+-0:115200 1:57600 2:38400 3:19200 4:14400 5:9600\n"));
//    lstrcat(&buf[0],TEXT("+- 1:COM1 2:COM2 3:COM3 4:COM4......... 9:COM9\n"));


	for ( i = 0; i < MAXHISTORY; i++ )
	{
		lstrcat(buf,szDownloadString[i]);
		lstrcat(buf,TEXT("\n"));
	}
#else
	lstrcpy(buf,szDownloadString[0]);
	lstrcat(buf,TEXT("\n"));

	for ( i = 1; i < MAXHISTORY; i++ )
	{
		lstrcat(buf,szDownloadString[i]);
	    lstrcat(buf,TEXT("\n"));
	}
#endif



//	EB_Printf(TEXT("[dnw] %d\n"), lstrlen(buf));
//	EB_Printf(TEXT("[dnw] %s\n"), buf);

    if(WriteFile(hFile,buf,lstrlen(buf),&temp,NULL)==0)
    {
		/// 2011.11.29,  EB_Printf(TEXT("[dnw] ERROR:Can't write dnw.ini file! \n"));
    }
        
    CloseHandle(hFile);

	/* --- READ-ONLY dnw.ini ----- */
	if( isFileExist(DNW_LOG_FILE) )
	{
		dwFileAttr = FILE_ATTRIBUTE_READONLY|FILE_ATTRIBUTE_SYSTEM|FILE_ATTRIBUTE_ARCHIVE|FILE_ATTRIBUTE_HIDDEN;
		
		if( FALSE == SetFileAttributes(DNW_LOG_FILE, dwFileAttr) )
		{
			dwError = GetLastError();					
			EB_Printf(TEXT("[dnw]::WriteUserConfig FileAttr:2:[0x%X], dwError(%d) \r\n"), DNW_LOG_FILE, dwFileAttr, dwError  );
		}
	}

    return TRUE;
}


UINT hex2int(TCHAR *str)
{
	int i;
	UINT number=0; 
	int order=1;
	TCHAR ch;

    for(i=lstrlen(str)-1;i>=0;i--)
    {
		ch=str[i];
		if(ch=='x' || ch=='X')break;
		
		if(ch>='0' && ch<='9')
		{
		    number+=order*(ch-'0');
		    order*=16;
		}
		if(ch>='A' && ch<='F')
		{
		    number+=order*(ch-'A'+10);
		    order*=16;
		}
		if(ch>='a' && ch<='f')
		{
		    number+=order*(ch-'a'+10);
		    order*=16;
		}
    }
    return number;
}




UINT str2int(TCHAR *str)
{
	int i;
	UINT number=0; 
	int order=1;
	TCHAR ch;

    for(i=lstrlen(str)-1;i>=0;i--)
    {
		ch=str[i];
#if 0
		if(ch=='x' || ch=='X')break;
#else
		if(ch=='.' || ch=='-') return 0; 
#endif

		if(ch>='0' && ch<='9')
		{
		    number+=order*(ch-'0');
		    order*=10;
		}
#if 0		
		if(ch>='A' && ch<='F')
		{
		    number+=order*(ch-'A'+10);
		    order*=16;
		}
		if(ch>='a' && ch<='f')
		{
		    number+=order*(ch-'a'+10);
		    order*=16;
		}
#endif
    }
    return number;
}


//#ifdef SANSIX_SMP201_CUSTOMIZING

void 	FileNaming(void)
{
	time_t	sys_t;
	unsigned char buff_tmp[DATE_LEN], buff_txt[DATE_LEN];

	memset(buff_tmp, 0x00, sizeof(buff_tmp));
	memset(buff_txt, 0x00, sizeof(buff_txt));
	memset(buff_fin, 0x00, sizeof(buff_fin));

	time( &sys_t );
	strcpy( (char *)buff_tmp, ctime( &sys_t ) );

	/* ------------------------------------------------
		012345679012345678901234
		Mon May 03 20:06:43 2010
	--------------------------------------------------- */
	if( FALSE == isFileExist( TEXT(".\\dnwlog") ) )
	{
		///EB_Printf(TEXT("[dnw] none === \r\n"));
		if( FALSE == CreateDirectory( TEXT("dnwlog"), NULL) )
		{
			///EB_Printf(TEXT("[dnw] Can not create the LOG folder or already it!!! "));
		}
	}
	else
	{
		///EB_Printf(TEXT("[dnw] found!!!! === \r\n"));
	}

	/* year */
	strncpy((char *)&buff_txt[0],  (char *)&buff_tmp[20], 4);
	/* Month */
	strncpy((char *)&buff_txt[4],  (char *)&buff_tmp[4], 3);
	/* Date */
	strncpy((char *)&buff_txt[7],  (char *)&buff_tmp[8], 2);

	/* Seperator -- */
	strncpy((char *)&buff_txt[9],  (char *)"_", 1);

	/* Hour */
	strncpy((char *)&buff_txt[10],  (char *)&buff_tmp[11], 2);

	/* Minute */
	strncpy((char *)&buff_txt[12],  (char *)&buff_tmp[14], 2);

	/* Second  */
	strncpy((char *)&buff_txt[14],	(char *)&buff_tmp[17], 2);

	//EB_Printf(TEXT("..... [%s] \n"), TEXT(buff_fin) );
	
	strncpy( (char *)buff_fin, (char *)"dnwlog\\dnw_",  11);
	strcat( (char *)buff_fin, (char *)buff_txt); /// date and time
	strcat( (char *)buff_fin, (char *)".txt");
}



void LOGFile_close(void)
{
	if( fFileWrite )
	{
#if 0 /* 2012.07.07 fflush() ������� ����.... ��¹��۴� ��� ó���� �ȴ�... flclose() ��� ��� ���� */
		KillTimer(_MainHwnd, TIMER_ID_MSG_WRITE_TO_FILE );
#endif

		fclose(fFileWrite);
		fFileWrite = NULL;

		memset(buff_fin, 0x00, sizeof(buff_fin) );
	}
}


BOOL LOGFile_open(void)
{

	LOGFile_close();

	if(msgSaveOnOff)
	{
		FileNaming(); /* date & time */
		if( NULL == fFileWrite )
		{
			fFileWrite = fopen( (const char*)buff_fin, "w+");
			if( NULL == fFileWrite )
			{
				EB_Printf(TEXT("[dnw] can not write log file.. Do make DNWLOG directory. GetLastError(%u) \n"), GetLastError() );
				return FALSE;
			}
	#if 0 /* 2012.07.07 fflush() ������� ����.... ��¹��۴� ��� ó���� �ȴ�... flclose() ��� ��� ���� */
			if( _MainHwnd )
				SetTimer(_MainHwnd, TIMER_ID_MSG_WRITE_TO_FILE, 60*1000, NULL); /* 1�� �ֱ��... */
	#endif
			return TRUE;
		}
	}
	return FALSE;
}



int ReWriteQuickUserConfig(void)
{
	int idx, subidx, MaxLen, idx_seq=1;
	int eboot_idx=0xff, stepldr_idx=0xff, nk_idx=0xff;
	TCHAR sztmpString[MAXHISTORY][FILENAMELEN] = { 0, };
	TCHAR szuppString[MAXHISTORY][FILENAMELEN] = { 0, };
	HANDLE hFile = NULL;
	TCHAR buf[MAXHISTORY*FILENAMELEN+1] = {0,};
    DWORD temp;


	memset( szuppString, 0x00, sizeof(szuppString) );
	/* --------------- uppercase ------------------------------------- */
	for ( idx = 0; idx < MAXHISTORY; idx++ )
	{
		lstrcpy( szuppString[idx], szQuickDownloadString[idx] );

		MaxLen = strlen((char *)szuppString[idx]);
		for( subidx=0; subidx<MaxLen; subidx++) 
		{ 
			if(szuppString[idx][subidx] >= 'a' && szuppString[idx][subidx] <= 'z' )
				szuppString[idx][subidx] = (szuppString[idx][subidx])^0x20; 
			else
				szuppString[idx][subidx] = szuppString[idx][subidx];
		}
	}	
	/* -------------------------------------------------------------- */

	memset( sztmpString, 0x00, sizeof(sztmpString) );
	idx_seq = 1;
	for ( idx = 0; idx < MAXHISTORY; idx++ )
	{
		if( (0xff==nk_idx) && (NULL != strstr(szuppString[idx], "NK" )) )
		{
			lstrcpy(sztmpString[NK_IDX], szQuickDownloadString[idx] );
			lstrcat(sztmpString[NK_IDX], " \r\n");
			nk_idx = idx;
		}
		else if( (0xff==eboot_idx) && (NULL != strstr(szuppString[idx], "BOOT" )) )
		{
			lstrcpy(sztmpString[EBOOT_IDX], szQuickDownloadString[idx] );
			lstrcat(sztmpString[EBOOT_IDX], " \r\n");
			eboot_idx = idx;
		}
		else if( (0xff==stepldr_idx) && ( (NULL != strstr(szuppString[idx], "STEP" )) || (NULL != strstr(szuppString[idx], "BLOCK" )) ) )
		{
			lstrcpy(sztmpString[STEPLDR_IDX], szQuickDownloadString[idx] );
			lstrcat(sztmpString[STEPLDR_IDX], " \r\n");
			stepldr_idx = idx;
		}
		else
		{
			lstrcpy(sztmpString[NK_IDX+idx_seq], szQuickDownloadString[idx] );
			lstrcat(sztmpString[NK_IDX+idx_seq], " \r\n");
			idx_seq++;
		}
	}

	if( (EBOOT_IDX == eboot_idx) && (STEPLDR_IDX == stepldr_idx) && (NK_IDX == nk_idx) )
		return TRUE;
	//////////////////////////////////////////////////////////////////
	
	
	memset( szQuickDownloadString, 0x00, sizeof(szQuickDownloadString) );
	for ( idx = 0; idx < MAXHISTORY; idx++ )
	{
		lstrcpy( szQuickDownloadString[idx], sztmpString[idx] );
	}

	hFile = CreateFile( TEXT(USER_TEXT_CONFIG),GENERIC_WRITE, 0,NULL,CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL,NULL);

	memset(buf, 0x00, sizeof(buf));
	if(hFile!=INVALID_HANDLE_VALUE)
	{
		buf[0]=TotalROMfilenum+'0';
		lstrcat(buf,TEXT("\r\n"));

		for(idx=0; idx<TotalROMfilenum ; idx++)
		{
			lstrcat( &buf[0], szQuickDownloadString[idx] );
		}

		if(WriteFile(hFile,buf,lstrlen(buf),&temp,NULL)==0)
		{
			EB_Printf(TEXT("[dnw] can not write dnw_usbboot.ini file! (L:%d, Error=%u) \n"),  __LINE__ , GetLastError());
		}
	}
	else
	{
		EB_Printf(TEXT("[dnw] can not create dnw_usbboot.ini file!! (L:%d, Error=%u) \n"),	__LINE__ , GetLastError());
	}
	CloseHandle(hFile);
	return TRUE;
}


int WriteQuickUserConfig(void)
{
    HANDLE hFile = NULL;
    DWORD temp;
	TCHAR buf[MAXHISTORY*FILENAMELEN+1] = {0,};
	///int i;

	
    hFile = CreateFile( TEXT(USER_TEXT_CONFIG),GENERIC_WRITE, 0,NULL,CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL,NULL);

	memset(buf, 0x00, sizeof(buf));
    if(hFile!=INVALID_HANDLE_VALUE)
    {
	    buf[0]=NAND_FILES_NUM+'0';
	    lstrcat(buf,TEXT("\r\n"));
	#if 1 /* yhjoo87_20110219_BEGIN -- */
		lstrcat(&buf[0],TEXT("C:\\TOP.JOO\\dnw151C\\Release\\L2_EBOOT.bin \r\n"));
		lstrcat(&buf[0],TEXT("C:\\TOP.JOO\\dnw151C\\Release\\STEPLDR.nb0 \r\n"));
		lstrcat(&buf[0],TEXT("C:\\TOP.JOO\\dnw151C\\Release\\NK.bin \r\n"));
	#else
		lstrcat(&buf[0],TEXT("C:\\TOP.JOO\\dnw105C\\Release\\IROM_SDMMCBoot.bin \r\n"));
		lstrcat(&buf[0],TEXT("C:\\TOP.JOO\\dnw105C\\Release\\IROM_SDMMCStepldr.nb0 \r\n"));
		lstrcat(&buf[0],TEXT("C:\\TOP.JOO\\dnw105C\\Release\\NK.bin \r\n"));
	#endif /* AAA -- yhjoo87_20110219_END */

	#if 0
		lstrcat(&buf[0],TEXT(".\\UMON\\c100_bl1_usb.bin,"));
			lstrcat(&buf[0], szDownloadAddress );
			lstrcat(&buf[0],TEXT(" \r\n"));

		lstrcat(&buf[0],TEXT(".\\UMON\\IROM_SDMMCBoot.nb0,"));
			lstrcat(&buf[0], szDownloadAddress );
			lstrcat(&buf[0],TEXT(" \r\n"));
	#endif
		
	//	EB_Printf(TEXT("[dnw] %d\n"), lstrlen(buf));
	//	EB_Printf(TEXT("[dnw] %s\n"), buf);

	    if(WriteFile(hFile,buf,lstrlen(buf),&temp,NULL)==0)
	    {
			EB_Printf(TEXT("[dnw] can not write dnw_usbboot.ini file!!! (L:%d, Error=%u) \n"),  __LINE__ , GetLastError());
	    }
    }
	else
	{
		EB_Printf(TEXT("[dnw] can not create dnw_usbboot.ini file!!!! (L:%d, Error=%u) \n"),  __LINE__ , GetLastError());
	}

    CloseHandle(hFile);

    return TRUE;
}



int ReadQuickUserConfig(HWND hwnd)
{
	HANDLE hFile = NULL;
	DWORD fileSize;
	DWORD CurrentPoint = 0;
	DWORD temp;
	TCHAR *buf = NULL;
	TCHAR *token = NULL;
	UINT i, j, len;
	int idx=0;
	
	for ( i = 0; i < MAXHISTORY; i++ )
	{
		szQuickDownloadString[i][0] = '\0';
	}

	hFile = CreateFile( TEXT(USER_TEXT_CONFIG),GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,0,NULL);

	if( (INVALID_HANDLE_VALUE==hFile)|| (NULL==hFile) )
	{
AAAA:
		EB_Printf(TEXT("[dnw] can not open dnw_usbboot.ini file! Retry it.. (L:%d, Error=%u) \n"),  __LINE__ , GetLastError());
		WriteQuickUserConfig();
		return FALSE;
	}
    
	fileSize=GetFileSize(hFile,NULL);
	if (fileSize == 0)
	{
		/// EB_Printf(TEXT("[dnw] ERROR:Can't open dnw_usbboot.ini. \n") );
		MessageBox(hwnd, TEXT("[dnw] ERROR:dnw_usbboot.ini is corrupted!!!"), NULL,MB_OK);
		CloseHandle(hFile);
		goto AAAA;
	}

	CurrentPoint = 0;

	buf=(char *)malloc(fileSize);
	memset(buf, 0, sizeof(TCHAR)*fileSize);

	ReadFile(hFile,buf,fileSize,&temp,NULL);

	TotalROMfilenum=*((TCHAR *)buf+0)-'0';	    //UNICODE problem!!!

	if(buf[1]!='\n')
	{
		for(i=0;i<fileSize;i++) //search first '\n'
		{
			if(buf[i]=='\n')
			{
				token = &buf[i+1];
				break;
			}
		}
		CurrentPoint = i+1;
	}
	else
	{
		///TotalROMfilenum=NAND_FILES_NUM;
		////EB_Printf(TEXT("buf[1] = (0x%X)\n"),buf[1] );
	}
	///EB_Printf(TEXT("[dnw] ++Searched ROM Files = %d:++\n"), TotalROMfilenum );

	for ( idx = 0; idx < TotalROMfilenum; idx++ )
	{
		for(j=0;j<fileSize-CurrentPoint;j++)
		{
			if(buf[CurrentPoint+j]=='\n')
			{
				CurrentPoint += (j+1);
				break;
			}
		}
		if ( j != 0 )
		{
			strncpy(szQuickDownloadString[idx], token, j);
			///strncpy(szQuickDownloadString[idx], token, j-1);
			///EB_Printf(TEXT("[dnw] ++%d:[%s]++\n"), idx, szQuickDownloadString[idx] );
		}
		token = &buf[CurrentPoint];
	}

	free(buf);
	CloseHandle(hFile);

	memset(szQuickFileName, 0x00, sizeof(szQuickFileName) );
	for ( idx=0; idx < TotalROMfilenum; idx++ )
	{
		for(len=FILENAMELEN-1; len>=0; len--)
		{
			if( szQuickDownloadString[idx][len] == ' ' 
				|| szQuickDownloadString[idx][len] == '\n'
				|| szQuickDownloadString[idx][len] == '\r'
				) 
			{ 
				szQuickDownloadString[idx][len]='\0'; 
			}

			if(szQuickDownloadString[idx][len] == '\\' )
			{
				lstrcpy(szQuickFileName[idx], &szQuickDownloadString[idx][len+1] );   /* strcpy() -> lstrcpy() */
				break;
			}
		}
	}

#if 0
	for(idx=0; idx<TotalROMfilenum; idx++)
		EB_Printf(TEXT("\nROM File = %s [%s]"), szQuickDownloadString[idx],szQuickFileName[idx] );
#endif


    return TRUE;
}


int WriteQuickUMONConfig(void)
{
    HANDLE hFile = NULL;
    DWORD temp;
    TCHAR buf[2048] = {0,};
	FILE *fileck = NULL;

	fileck = fopen( (const char*)UMON_TEXT_CONFIG, "r");
	if( NULL != fileck )
	{
		fclose(fileck);
		///EB_Printf(TEXT("[dnw] can open dnw_UmonTx.ini file! (L:%d) -- OK \n"), __LINE__ );
		return TRUE;
	}
	
    hFile = CreateFile( TEXT(UMON_TEXT_CONFIG),GENERIC_WRITE, 0,NULL,CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL,NULL);

	memset(buf, 0x00, sizeof(buf));
    if(hFile!=INVALID_HANDLE_VALUE)
    {
	    buf[0]=UMON_FILES_NUM+'0';
	    lstrcat(buf,TEXT("\r\n"));

		lstrcat(&buf[0],TEXT(".\\QuickUMON\\c100_bl1_usb.bin,"));
			lstrcat(&buf[0], szDownloadAddress );
			lstrcat(&buf[0],TEXT(" \r\n"));

		///lstrcat(&buf[0],TEXT(".\\QuickUMON\\IROM_SDMMCBoot.nb0,")); /* for iNAND */
		lstrcat(&buf[0],TEXT(".\\QuickUMON\\EBOOT.nb0,"));
			lstrcat(&buf[0], szDownloadAddress );
			lstrcat(&buf[0],TEXT(" \r\n"));
		
	//	EB_Printf(TEXT("[dnw] %d\n"), lstrlen(buf));
	//	EB_Printf(TEXT("[dnw] %s\n"), buf);

	    if(WriteFile(hFile,buf,lstrlen(buf),&temp,NULL)==0)
	    {
			EB_Printf(TEXT("[dnw] can not write dnw_UmonTx.ini file! (L:%d, Error=%u) \n"), __LINE__ , GetLastError());
	    }
    }
	else
	{
		EB_Printf(TEXT("[dnw] can not create dnw_UmonTx.ini file! (L:%d, Error=%u) \n") , __LINE__ , GetLastError());
	}

    CloseHandle(hFile);

    return TRUE;
}



int ReadQuickUMONConfig(HWND hwnd)
{
    HANDLE hFile = NULL;
    DWORD fileSize;
	DWORD CurrentPoint = 0;
    DWORD temp;
    TCHAR *buf = NULL;
    TCHAR *token = NULL;
    UINT i, j, len;
	int idx=0;
//	HMENU MenuBar;
//	HMENU SubMenuBar;
	
	for ( i = 0; i < MAXHISTORY; i++ )
	{
		szUMONDownloadString[i][0] = '\0';
	}

    hFile = CreateFile( TEXT(UMON_TEXT_CONFIG),GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,0,NULL);
    
    if( (INVALID_HANDLE_VALUE==hFile)|| (NULL==hFile) )
    {
AAAA:
		EB_Printf(TEXT("[dnw] can not open dnw_UmonTx.ini. so retry it... Error=%u\n"), GetLastError() );
		WriteQuickUMONConfig();
		return FALSE;
    }
    
    fileSize=GetFileSize(hFile,NULL);
	if (fileSize == 0)
	{
		///EB_Printf(TEXT("[dnw] [ERROR:Can't open dnw_UmonTx.ini.]\n") );
		MessageBox(hwnd, TEXT("[dnw] can not open dnw_UmonTx.ini. maybe corrupted!!!"), NULL,MB_OK);
		CloseHandle(hFile);
		goto AAAA;
	}

	CurrentPoint = 0;

    buf=(char *)malloc(fileSize);
	memset(buf, 0, sizeof(TCHAR)*fileSize);
    
    ReadFile(hFile,buf,fileSize,&temp,NULL);
    
    UmonFileNum=*((TCHAR *)buf+0)-'0';	    //UNICODE problem!!!
 
    if(buf[1]!='\n')
    {
		for(i=0;i<fileSize;i++) //search first '\n'
		{
			if(buf[i]=='\n')
			{
				token = &buf[i+1];
				break;
			}
		}
		CurrentPoint = i+1;
    }
    else
    {
		UmonFileNum=UMON_FILES_NUM;
    }
	///EB_Printf(TEXT("[dnw] ++Searched ROM Files = %d:++\n"), TotalROMfilenum );

	for ( idx = 0; idx < UmonFileNum; idx++ )
	{
		for(j=0; j<fileSize-CurrentPoint; j++)
		{
			if(buf[CurrentPoint+j]=='\n')
			{
				CurrentPoint += (j+1);
				break;
			}
		}
		if ( j != 0 )
		{
			strncpy(szUMONDownloadString[idx], token, j);
			///strncpy(szUMONDownloadString[idx], token, j-1);
			///EB_Printf(TEXT("[dnw] ++%d:[%s]++\n"), idx, szUMONDownloadString[idx] );
		}
		token = &buf[CurrentPoint];
	}

    if(buf) free(buf);
    CloseHandle(hFile);

	memset(szUMONSFileName, 0x00, sizeof(szUMONSFileName) );
	for ( idx=0; idx < UmonFileNum; idx++ )
	{
		for(len=FILENAMELEN-1; len>=0; len--)
		{
			if( szUMONDownloadString[idx][len] == ' ' 
				|| szUMONDownloadString[idx][len] == '\n'
				|| szUMONDownloadString[idx][len] == '\r'
				) 
			{ 
				szUMONDownloadString[idx][len]='\0'; 
			}

			if(szUMONDownloadString[idx][len] == '\\' )
			{
				lstrcpy(szUMONSFileName[idx], &szUMONDownloadString[idx][len+1] );  /* strcpy() -> lstrcpy() */
				break;
			}
		}
	}

#if 0
	for(idx=0; idx<TotalROMfilenum; idx++)
		EB_Printf(TEXT("\nROM File = %s [%s]"), szUMONDownloadString[idx],szUMONSFileName[idx] );
#endif


    return TRUE;
}

//#endif




