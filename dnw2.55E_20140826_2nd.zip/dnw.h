#ifndef __DNW_H__
#define __DNW_H__

BOOL MenuConnect(HWND hwnd);
BOOL MenuConnectDisconnect(HWND hwnd);
void MenuDisconnect(HWND hwnd);
void MenuTransmit(HWND hwnd);
void MenuOptions(HWND hwnd);
void MenuAbout(HWND hwnd);
void Quit(HWND hwnd);

void UpdateWindowTitle(void);

BOOL OpenComPort(int port);
void CloseComPort(void);

void DoRxTx(void *args); 
int ReadCommBlock(char *buf,int maxLen);
void TxFile(void *args);
void WriteCommBlock(char c);

#define HISTORYMENUID 	41000
#define MAXHISTORY 		24
#define FILENAMELEN		256

#define ADDR_LENGTH 	16

#define X_CAL			8
#define Y_CAL			50

#if 1 /// 2012.05.23
#define THREAD_STACK_SIZE 		0x2000  /* 8KB, LSI original */
#else
#define THREAD_STACK_SIZE 		0x4000  /* 16KB */
#endif




#define COLOR_BLACK				RGB(0,0,0)
#define COLOR_BLUE				RGB(0,0,255)
#define COLOR_RED				RGB(255,0,0)
#define COLOR_GREEN				RGB(0,255,0)
#define COLOR_WHITE				RGB(255,255,255)
#define COLOR_YELLOW			RGB(255,255,0)
#define COLOR_CYAN				RGB(0x00,0xff,0xff)
#define COLOR_MAGENTA			RGB(0xff,0x00,0xff)
#define COLOR_TRANSPARENT		RGB(255,0,255)
#define COLOR_J_GRAY			RGB(0x7F,0x7F,0x7F)
#define COLOR_GRAY				RGB(192,192,192)
//#define COLOR_GRAY				RGB(205,205,205)
//#define COLOR_GRAY				RGB(175,175,175)
#define COLOR_NULL				-1

#define COLOR_NUM_MAX 			9


#define SANSIX_SMP201_CUSTOMIZING


///WORD         g_AllImagesDownload = 0; /// DiCOiN


#define MSG_DNW_BEGIN_TXT          TEXT("$$BGN@$")
#define MSG_DNW_END_TXT            TEXT("$$END@$")
#define MSG_DNW_NK_FIN_TXT         TEXT("$$NKB@$")
#define MSG_DNW_EBOOT_FIN_TXT      TEXT("$$EBT@$") 
#define MSG_DNW_STEPLDR_FIN_TXT    TEXT("$$STL@$")  
#define MSG_DNW_SCR_CLEAR_TXT      TEXT("$$CLR@$")  


#define MSG_DNW_BEGIN_LEN          7 /// strlen(MSG_DNW_BEGIN_TXT)
#define MSG_DNW_END_LEN            7 /// strlen(MSG_DNW_END_TXT)
#define MSG_DNW_NK_FIN_LEN         7 /// strlen(MSG_DNW_NK_FIN_TXT)
#define MSG_DNW_EBOOT_FIN_LEN      7 /// strlen(MSG_DNW_EBOOT_FIN_TXT) 
#define MSG_DNW_STEPLDR_FIN_LEN    7 /// strlen(MSG_DNW_STEPLDR_FIN_TXT)  
#define MSG_DNW_SCR_CLEAR_LEN      7 /// strlen(MSG_DNW_SCR_CLEAR_TXT)  


#define DNW_CLR 		0x0001
#define DNW_BGN 		0x0002
#define DNW_END 		0x0004
#define DNW_NK 			0x0010
#define DNW_EBOOT		0x0020
#define DNW_STEP 		0x0040

#define DNW_OTHER 		0x0800
#define DNW_ING 		0x8000



#define TOTAL_BIN_OK    (DNW_NK | DNW_EBOOT | DNW_STEP)


#ifdef SANSIX_SMP201_CUSTOMIZING
	#ifdef CUSTOMER_MODE
	#define APPNAME TEXT("DNW v2.55C - TOP.JOO")  /* CUSTOMER_MODE on !! AutoSend Downlloading �� */
	#else
	#define APPNAME TEXT("DNW v2.55E - TOP.JOO")  /* ENGINEER_MODE on !! Engineer �� */
	#endif

	#define EDIT_SCREEN_X (8*100)
	#define EDIT_SCREEN_Y (16*34)
#else
	#define APPNAME TEXT("DNW v0.60C - For WinCE")
	#define EDIT_SCREEN_X (8*80)  //640
	#define EDIT_SCREEN_Y (16*24) //384
#endif



#define SCREEN_X    (EDIT_SCREEN_X+2+16+2) //border(1+1)+scroll_bar(16)+space(1+1)
#define SCREEN_Y    (EDIT_SCREEN_Y+2+16+2) //border(1+1)+scroll_bar(16)+space(1+1)
/*
#define WINDOW_XSIZE (SCREEN_X+6)
#define WINDOW_YSIZE (SCREEN_Y+6+38) 
*/
#define WINDOW_XSIZE (SCREEN_X+8)
#define WINDOW_YSIZE (SCREEN_Y+8+38) 

#endif //__DNW_H__



