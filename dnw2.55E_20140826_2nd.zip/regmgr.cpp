// =============================================
// Program Name: engine
// =============================================

#define STRICT
#define WIN32_LEAN_AND_MEAN

#include "resource.h"

///#define RICHED_COLOR
#include <windows.h>
#include <mmsystem.h>
#include <winreg.h>

#include <string.h>
#include <stdlib.h>
#include <tchar.h>
#include <stdio.h> //for _vsntprintf()
#include <time.h>
#include <stdio.h>
#include <winuser.h>

#include "engine.h"
#include "dnw.h"
#include "fileopen.h"
#include "font.h"
#include "d_box.h"
#include "usbtxrx.h"
#include "regmgr.h"  /// added.


DWORD	WIN_XSIZE = WINDOW_XSIZE;
DWORD	WIN_YSIZE = WINDOW_YSIZE;

DWORD	editXBgn=0, editWidth;
DWORD	editYBgn=0, editHeight;

DWORD	MainXBgn=0, MainWidth;
DWORD	MainYBgn=0, MainHeight;

DWORD 	WIN_XBgn=0, WIN_YBgn=0;


extern int userComPort, idBaudRate,userBaudRate;
extern DWORD downloadAddress;
extern TCHAR szDownloadAddress[ADDR_LENGTH];
extern int autoSendKey;
extern int localTime; /// 2013.04.09
extern int msgSaveOnOff;
/* 2011.02.08 , Text Mode or Hexa Mode */
extern int msgMode;

extern int FontType;
extern int RetryUSB; /// 2012.03.10

#if defined(COLOR_DISP2) /// 2010.05.14
extern int ColorType; /// 2010.05.14 added
#endif

extern int CPUtype; /// 6410:0, SMDKC100:1


void SetRegistry(void)
{
	HKEY hKey = NULL;
	LONG lRet;
	DWORD dwSize;
	TCHAR strBuild[32] = {0,};
	
	lRet = RegCreateKeyEx(HKEY_CURRENT_USER, REG_LOC, 0, NULL, 
					REG_OPTION_NON_VOLATILE, KEY_ALL_ACCESS, NULL, &hKey, &dwSize);

	if( ERROR_SUCCESS != lRet )
	{
		WIN_XSIZE = WINDOW_XSIZE;
		WIN_YSIZE = WINDOW_YSIZE;
		autoSendKey = 0;
		msgSaveOnOff = 0; /// added.
		localTime = 0;

		userComPort  = 1;
		idBaudRate   = 8; /* 115200 bps*/
		userBaudRate = baudTable[idBaudRate];
		
#if 0
		userComPort = 1;
		idBaudRate = 8; /* 115,200 bps*/
		userBaudRate = baudTable[idBaudRate];
		downloadAddress = 0x20030000;
		lstrcpy(szDownloadAddress, TEXT("0x20030000") );
#endif
	}

	lRet = RegSetValueEx(hKey, REG_X_TEXT,          0, REG_DWORD, (const BYTE *)&WIN_XSIZE, sizeof(DWORD) );
	lRet = RegSetValueEx(hKey, REG_Y_TEXT,          0, REG_DWORD, (const BYTE *)&WIN_YSIZE, sizeof(DWORD) );
	lRet = RegSetValueEx(hKey, REG_AUTO_TEXT,       0, REG_DWORD, (const BYTE *)&autoSendKey, sizeof(DWORD) );
	lRet = RegSetValueEx(hKey, REG_MSG_SAVE_TEXT,   0, REG_DWORD, (const BYTE *)&msgSaveOnOff, sizeof(DWORD) );

	lRet = RegSetValueEx(hKey, REG_FONT_TYPE,		0, REG_DWORD, (const BYTE *)&FontType, sizeof(DWORD) );

#if defined(COLOR_DISP2)
	lRet = RegSetValueEx(hKey, REG_COLOR_TYPE,      0, REG_DWORD, (const BYTE *)&ColorType, sizeof(DWORD) );
#endif

	lRet = RegSetValueEx(hKey, REG_RETRY_USB,		0, REG_DWORD, (const BYTE *)&RetryUSB, sizeof(DWORD) );

#if 0
	lRet = RegSetValueEx(hKey, REG_COM_Port_TEXT,   0, REG_DWORD, (const BYTE *)&userComPort, sizeof(DWORD) );
	lRet = RegSetValueEx(hKey, REG_B_RATE_IDX_TEXT, 0, REG_DWORD, (const BYTE *)&idBaudRate, sizeof(DWORD) );
	userBaudRate = baudTable[idBaudRate];

	lRet = RegSetValueEx(hKey, REG_BAUDRATE_TEXT,   0, REG_DWORD, (const BYTE *)&userBaudRate, sizeof(DWORD) );

	dwSize = sizeof(szDownloadAddress);
	lRet = RegSetValueEx(hKey, REG_DL_TEXT,         0, REG_SZ,    (PBYTE)&szDownloadAddress, dwSize );
#endif

//////////////////

	lRet = RegSetValueEx(hKey, REG_X_START,		0, REG_DWORD, (const BYTE *)&WIN_XBgn, sizeof(DWORD) );
	lRet = RegSetValueEx(hKey, REG_Y_START, 	0, REG_DWORD, (const BYTE *)&WIN_YBgn, sizeof(DWORD) );
	lRet = RegSetValueEx(hKey, REG_MAIN_XPOS, 	0, REG_DWORD, (const BYTE *)&MainXBgn, sizeof(DWORD) );
	lRet = RegSetValueEx(hKey, REG_MAIN_YPOS, 	0, REG_DWORD, (const BYTE *)&MainYBgn, sizeof(DWORD) );
	lRet = RegSetValueEx(hKey, REG_MAIN_WID, 	0, REG_DWORD, (const BYTE *)&MainWidth, sizeof(DWORD) );
	lRet = RegSetValueEx(hKey, REG_MAIN_HEI, 	0, REG_DWORD, (const BYTE *)&MainHeight, sizeof(DWORD) );

	lRet = RegSetValueEx(hKey, REG_SAMSUNG_CPU,	0, REG_DWORD, (const BYTE *)&CPUtype, sizeof(DWORD) );

	lRet = RegSetValueEx(hKey, REG_DNW_COMPORT, 0, REG_DWORD, (const BYTE *)&userComPort, sizeof(DWORD) );
	lRet = RegSetValueEx(hKey, REG_DNW_BAUDRATE,0, REG_DWORD, (const BYTE *)&idBaudRate, sizeof(DWORD) );

	if( 0xFFFF != idBaudRate )
		userBaudRate = baudTable[idBaudRate];
	lRet = RegSetValueEx(hKey, REG_DNW_USRBAUD,	0, REG_DWORD, (const BYTE *)&userBaudRate, sizeof(DWORD) );	

	dwSize = sizeof(szDownloadAddress);
	lRet = RegSetValueEx(hKey, REG_DNW_USB_ADDR,0, REG_SZ,	  (PBYTE)&szDownloadAddress, dwSize );


///////////////

	/* -------------------------------------------------------------------------------------- */
	dwSize = sizeof(REG_AUTHOR1_ID_TEXT);
	lRet = RegSetValueEx(hKey, REG_AUTHOR1_TEXT,  0, REG_SZ,    (PBYTE)&REG_AUTHOR1_ID_TEXT, dwSize );

	memset(strBuild, 0x00, sizeof(strBuild) );
	sprintf(strBuild,TEXT("July 27 2012,14:33:00"));
	dwSize = sizeof(strBuild);
	lRet = RegSetValueEx(hKey, REG_BUILDING1_TEXT, 0, REG_SZ,    (PBYTE)&strBuild, dwSize );

	/* --- modify ------ */
	dwSize = sizeof(REG_AUTHOR2_ID_TEXT);
	lRet = RegSetValueEx(hKey, REG_AUTHOR2_TEXT,   0, REG_SZ,    (PBYTE)&REG_AUTHOR2_ID_TEXT, dwSize );

	memset(strBuild, 0x00, sizeof(strBuild) );
	sprintf(strBuild,TEXT("%s,%s"), __DATE__, __TIME__ );
	dwSize = sizeof(strBuild);
	lRet = RegSetValueEx(hKey, REG_BUILDING2_TEXT,   0, REG_SZ,    (PBYTE)&strBuild, dwSize );
	/* -------------------------------------------------------------------------------------- */


	RegCloseKey(hKey);
}


void GetRegistry(void)
{
	/* HKEY_CURRENT_USER\Software\DNW ���� �о���δ�.	*/
	DWORD dwType, dwData=4;
	HKEY hKey = NULL;
	LONG lRet;
	BOOL rewrite=FALSE;

	/* Ű�� �����Ѵ�. */
	if ((lRet = RegOpenKeyEx(HKEY_CURRENT_USER, REG_LOC, 0, 
				KEY_READ | KEY_QUERY_VALUE , &hKey)) == ERROR_SUCCESS)	 
	{	
		if( (lRet = RegQueryValueEx(hKey, REG_X_TEXT, NULL, &dwType, (const LPBYTE)&WIN_XSIZE, &dwData))!=ERROR_SUCCESS )	
		{	
			WIN_XSIZE = WINDOW_XSIZE;
			rewrite=TRUE;
		}	

		if((lRet = RegQueryValueEx(hKey, REG_Y_TEXT, NULL, &dwType, (const LPBYTE)&WIN_YSIZE, &dwData))!=ERROR_SUCCESS )	
		{	
			WIN_YSIZE = WINDOW_YSIZE;
			rewrite=TRUE;
		}	

	#ifdef ENGINEER_MODE /// auto Send Key default Off  : �����ڿ��� �ʿ����.
		autoSendKey = 0; /* auto key send off */
		localTime = 0;
	#else
		if((lRet = RegQueryValueEx(hKey, REG_AUTO_TEXT, NULL, &dwType, (const LPBYTE)&autoSendKey, &dwData))!=ERROR_SUCCESS )	
		{	
			autoSendKey = 0; /* auto key send off */
			localTime = 0;
			rewrite=TRUE;
		}	
	#endif

	#if 1 /// LOG file save ���� ����... always off mode
		msgSaveOnOff = 0; /* Save off */
	#else
		if((lRet = RegQueryValueEx(hKey, REG_MSG_SAVE_TEXT, NULL, &dwType, (const LPBYTE)&msgSaveOnOff, &dwData))!=ERROR_SUCCESS )	
		{	
			msgSaveOnOff = 0; /* Save off */
			rewrite=TRUE;
		}
	#endif

		if((lRet = RegQueryValueEx(hKey, REG_FONT_TYPE, NULL, &dwType, (const LPBYTE)&FontType, &dwData))!=ERROR_SUCCESS )	
		{	
			FontType = 3; /// index COLOR_GRAY;
			rewrite=TRUE;
		}	

	#if 1 /// Default Text Mode 
		msgMode = 0; /* Text Mode : 0, Hexa Mode : 1 */
	#endif
	
#if defined(COLOR_DISP2)
		if((lRet = RegQueryValueEx(hKey, REG_COLOR_TYPE, NULL, &dwType, (const LPBYTE)&ColorType, &dwData))!=ERROR_SUCCESS )	
		{	
			ColorType = 0; /// index COLOR_GRAY;
			rewrite=TRUE;
		}	
#endif

	#ifdef ENGINEER_MODE /// auto Send Key default Off	: �����ڿ��� �ʿ����.
			RetryUSB = 0; 
	#else
		if((lRet = RegQueryValueEx(hKey, REG_RETRY_USB, NULL, &dwType, (const LPBYTE)&RetryUSB, &dwData))!=ERROR_SUCCESS )	
		{	
			RetryUSB = 1; /// default,  if 20, then 10*20=200,  if 20, then 40*20=800, if 
			rewrite=TRUE;
		}	
	#endif


	#if 0
		if((lRet = RegQueryValueEx(hKey, REG_COM_Port_TEXT, NULL, &dwType, (const LPBYTE)&userComPort, &dwData))!=ERROR_SUCCESS )	
		{	
			userComPort = 1;
			rewrite=TRUE;
		}	

		if((lRet = RegQueryValueEx(hKey, REG_B_RATE_IDX_TEXT, NULL, &dwType, (const LPBYTE)&idBaudRate, &dwData))!=ERROR_SUCCESS )	
		{	
			idBaudRate = 8; /* 115,200 bps*/
			rewrite=TRUE;
		}	
		userBaudRate = baudTable[idBaudRate];


		dwData = sizeof(szDownloadAddress);
		memset(szDownloadAddress, 0x00, dwData );
		if((lRet = RegQueryValueEx(hKey, REG_DL_TEXT, NULL, &dwType, (const LPBYTE)szDownloadAddress, &dwData))!=ERROR_SUCCESS )	
		{	
			lstrcpy(szDownloadAddress, TEXT("0x20030000") );
			rewrite=TRUE;
		}	
	#endif


		if((lRet = RegQueryValueEx(hKey, REG_X_START, NULL, &dwType, (const LPBYTE)&WIN_XBgn, &dwData))!=ERROR_SUCCESS )	
		{	
			WIN_XBgn = 0; /// window x start
			rewrite=TRUE;
		}	
		if((lRet = RegQueryValueEx(hKey, REG_Y_START, NULL, &dwType, (const LPBYTE)&WIN_YBgn, &dwData))!=ERROR_SUCCESS )	
		{	
			WIN_YBgn = 0; /// window y start
			rewrite=TRUE;
		}	

		/* main window */
		if((lRet = RegQueryValueEx(hKey, REG_MAIN_XPOS, NULL, &dwType, (const LPBYTE)&MainXBgn, &dwData))!=ERROR_SUCCESS )	
		{	
			MainXBgn = 0; /// window y start
			rewrite=TRUE;
		}	
		if((lRet = RegQueryValueEx(hKey, REG_MAIN_YPOS, NULL, &dwType, (const LPBYTE)&MainYBgn, &dwData))!=ERROR_SUCCESS )	
		{	
			MainYBgn = 0; /// window y start
			rewrite=TRUE;
		}	
		if((lRet = RegQueryValueEx(hKey, REG_MAIN_WID, NULL, &dwType, (const LPBYTE)&MainWidth, &dwData))!=ERROR_SUCCESS )	
		{	
			MainWidth = 0; /// window y start
			rewrite=TRUE;
		}	
		if((lRet = RegQueryValueEx(hKey, REG_MAIN_HEI, NULL, &dwType, (const LPBYTE)&MainHeight, &dwData))!=ERROR_SUCCESS )	
		{	
			MainHeight = 0; /// window y start
			rewrite=TRUE;
		}	

		if((lRet = RegQueryValueEx(hKey, REG_SAMSUNG_CPU, NULL, &dwType, (const LPBYTE)&CPUtype, &dwData))!=ERROR_SUCCESS )	
		{	
			CPUtype = 1; /// SMDKC100
			rewrite=TRUE;
		}


		if((lRet = RegQueryValueEx(hKey, REG_DNW_COMPORT, NULL, &dwType, (const LPBYTE)&userComPort, &dwData))!=ERROR_SUCCESS )	
		{	
			userComPort = 1; /// COM port
			rewrite=TRUE;
		}

		if((lRet = RegQueryValueEx(hKey, REG_DNW_BAUDRATE, NULL, &dwType, (const LPBYTE)&idBaudRate, &dwData))!=ERROR_SUCCESS )	
		{	
			idBaudRate = 8; /// Baudrate Index:8 -> 115200bps
			rewrite=TRUE;
		}

		if((lRet = RegQueryValueEx(hKey, REG_DNW_USRBAUD, NULL, &dwType, (const LPBYTE)&userBaudRate, &dwData))!=ERROR_SUCCESS )	
		{	
			if( 0xFFFF != idBaudRate )
				userBaudRate = baudTable[idBaudRate]; /// Baudrate Index:8 -> 115200bps
			rewrite=TRUE;
		}

		dwData = sizeof(szDownloadAddress);
		memset(szDownloadAddress, 0x00, dwData );
		if((lRet = RegQueryValueEx(hKey, REG_DNW_USB_ADDR, NULL, &dwType, (const LPBYTE)szDownloadAddress, &dwData))!=ERROR_SUCCESS )	
		{	
			lstrcpy(szDownloadAddress, TEXT("0x20030000") );  /// C100
			rewrite=TRUE;
		}	
		

		RegCloseKey(hKey);	
	}
	else // ERROR
	{
		WIN_XSIZE = WINDOW_XSIZE;
		WIN_YSIZE = WINDOW_YSIZE;
		autoSendKey = 0; /* auto key send off */
		localTime = 0;
		msgSaveOnOff = 0; /* Save off */
		msgMode = 0; /* 2011.02.08 Text Mode : 0, Hexa Mode : 1 */
		FontType = 3;
#if defined(COLOR_DISP2)
		ColorType = 0; /// index COLOR_GRAY;
#endif

	#ifdef ENGINEER_MODE /// auto Send Key default Off	: �����ڿ��� �ʿ����.
		RetryUSB = 0;
	#else
		RetryUSB = 1;
	#endif


		CPUtype = 1; /// SMDKC100

		userComPort  = 1;
		idBaudRate   = 8;
		userBaudRate = baudTable[idBaudRate];

#if 0
		userComPort = 1;
		idBaudRate = 8; /* 115,200 bps*/
		userBaudRate = baudTable[idBaudRate];
		downloadAddress = 0x20030000;
		lstrcpy(szDownloadAddress, TEXT("0x20030000") );
#endif
	}


	if( WIN_XSIZE <= 10) { WIN_XSIZE = WINDOW_XSIZE; rewrite = TRUE; }
	if( WIN_YSIZE <= 10) { WIN_YSIZE = WINDOW_YSIZE; rewrite = TRUE; }

	if( rewrite ) SetRegistry();

}




void GetComPortRegistry(void)
{
	DWORD dwType, dwData=50;
	HKEY hKey = NULL;
	LONG lRet;
	BOOL rewrite=FALSE;
	BYTE lpData[50] = {0,};
	TCHAR RegKey[50] = {0, };
	TCHAR RegKeyTmp[10] = {0, };
	int   idx=0;
	static int   mExistCount=0;
	/* COM Port Reg Ű�� �����Ѵ�. */
	if ((lRet = RegOpenKeyEx(HKEY_LOCAL_MACHINE, 
							REG_COM_PORT_AVAIL, 
							0, 
							KEY_READ|KEY_QUERY_VALUE , 
							&hKey))== ERROR_SUCCESS
		)	 
	{	


		EB_Printf(TEXT("[dnw] The available COM port lists are as follows: \r\n"), RegKey );

		memset( RegKey, 0x00, sizeof(RegKey) );
		memset( RegKeyTmp, 0x00, sizeof(RegKeyTmp) );
		memset( lpData, 0x00, sizeof(lpData) ); 


		for(idx=0; idx<=256; idx++)
		{

			lstrcpy( RegKey, REG_COM_PORT_KEY);
			if( 0 == idx )
				lstrcat( RegKey, _T("0") );
			else
				lstrcat( RegKey, _itot(idx,RegKeyTmp,10) );

			//EB_Printf(TEXT("[[[[ %s ]]]]  \r\n"), RegKey );

			dwType = REG_SZ;
			if( (lRet = RegQueryValueEx(hKey, RegKey, NULL, &dwType, (PBYTE)lpData, &dwData))==ERROR_SUCCESS )	
			{	
				if( NULL != lpData )
				{
					EB_Printf(TEXT("     [%3d]:%s "), idx, lpData );
					mExistCount++;
				}
				if( 0==(mExistCount%5) ) EB_Printf(TEXT("\r\n") );
			}	
			else
			{
				///EB_Printf(TEXT("[2] dwType=%d, &lpData=%s, &dwData=%d	\r\n"), dwType, lpData, dwData );
			}
		}
		if( mExistCount ) EB_Printf(TEXT("\r\n") );
		else EB_Printf(TEXT("      The connected COM port is NONE...\r\n") );

	}
	
}


char *os_name(void)
{
    OSVERSIONINFO info;
    static char buf[128] = {0,};

    if(buf[0]) { return buf; }

    memset(&info, 0, sizeof(info));
    info.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
    if(0 == GetVersionEx(&info) )
    {
        exit(-1);
    }

	switch( info.dwPlatformId )
	{
		/* windows 32 ȣȯ : window 3.1  */
		case VER_PLATFORM_WIN32s:
			strcpy(buf, "WIN3.1");
			break;

		/* windows 32 ��Ʈ � ü�� : win95, win98 */
		case VER_PLATFORM_WIN32_WINDOWS:
			if(info.dwMinorVersion ==  0)      { strcpy(buf, "Windows 95"); }
			else if(info.dwMinorVersion  < 90) 
			{ 
				if(info.dwMinorVersion == 10 )
					strcpy(buf, "Windows 98 second edition"); 
				else
					strcpy(buf, "Windows 98"); 
			}
			else if(info.dwMinorVersion  == 90) { strcpy(buf, "Windows ME"); }
			else                                { strcpy(buf, "Unknow Windows "); }
			break;

	
		/* windows 32 ��Ʈ nt � ü�� : windows nt,  */
		case VER_PLATFORM_WIN32_NT:
			if(info.dwMajorVersion <=  4)      /// { strcpy(buf, "Windows NT"); }
			{
				sprintf(buf, "Windows NT %d.%d.%d", info.dwMajorVersion , info.dwMinorVersion, info.dwBuildNumber&0xFFFF);
			}
			else if(5 == info.dwMajorVersion)
			{
				switch(info.dwMinorVersion)
				{
					case 0: /// 5.0
						strcpy(buf, "Windows 2K(32bit)");
						break;
					case 1: /// 5.1
						strcpy(buf, "Windows XP(32bit)"); 
						break;
					default: /// 5.x
						strcpy(buf, "Windows *(32bit)"); 
						break;
				}
			}
			else if(6 == info.dwMajorVersion)
			{
				switch( info.dwMinorVersion )
				{
					case 0: /// 6.0
						strcpy(buf, "Windows Vista"); 
						break;

					case 1: /// 6.1
						strcpy(buf, "Windows7");
						break;

					case 2: /// 6.2
						strcpy(buf, "Windows8");
						break;

					case 3: /// 6.3
						strcpy(buf, "Windows8.1");
						break;

					default:
						sprintf(buf, "Windows NT(?) %d.%d %s", info.dwMajorVersion , info.dwMinorVersion, info.szCSDVersion);
						break;
				}
			}
			else
			{
				sprintf(buf, "Windows NT(?) %d.%d %s", info.dwMajorVersion , info.dwMinorVersion, info.szCSDVersion);
			}
			break;

//		case VER_PLATFORM_WIN64_NT:
//			break;

		default:
			sprintf(buf, "Windows (%d)", info.dwPlatformId);

			if(info.dwMajorVersion == 6)
			{
				if(info.dwMinorVersion == 0)      { strcat(buf, " Vista"); }
				else if(info.dwMinorVersion == 1) { strcat(buf, " 7"); }
			}
			
			break;
	}

    sprintf(buf + strlen(buf), " %d.%d.%d - %s", info.dwMajorVersion,
                                            info.dwMinorVersion,
                                            info.dwBuildNumber&0xFFFF, info.szCSDVersion );
    return buf;
}


