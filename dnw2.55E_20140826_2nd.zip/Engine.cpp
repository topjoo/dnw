// =============================================
// Program Name: engine
// =============================================

#define STRICT
#define WIN32_LEAN_AND_MEAN

#include "resource.h"

///#define RICHED_COLOR
#include <windows.h>
#include <mmsystem.h>
#include <winreg.h>
#include <commctrl.h>  /// 2010.05.28 added.

#if  0
#pragma comment(lib, "comctl32.lib") /// 2013.05.22
#endif



#pragma hdrstop
#include <string.h>
#include <stdlib.h>
#include <tchar.h>
#include <stdio.h> //for _vsntprintf()
#include <time.h>
#include <stdio.h>
#include <winuser.h>
#ifdef RICHED_COLOR //////////////////////////////////////
#include <richedit.h>
#endif

#include "engine.h"
#include "dnw.h"
#include "fileopen.h"
#include "font.h"
#include "d_box.h"
#include "usbtxrx.h"
#include "regmgr.h"  /// added.


extern BOOL isFileExist(TCHAR *file);

#pragma warning (disable : 4100)
#pragma warning (disable : 4068)

TCHAR szAppName[] = APPNAME;

HINSTANCE _hInstance;
HWND _hwnd, _MainHwnd, _EditHwnd;
static HWND _hwndEdit;

#ifdef RICHED_COLOR //////////////////////////////////////
static HMODULE hDll = NULL; /// added.
#endif

extern int FontType;
#if defined(COLOR_DISP2)
HBRUSH m_Brush = NULL; /// background color
extern int ColorType; /// 2010.05.14 added
#endif ////////


#define UMON_IRAM_BL1_FILE_INDEX 	0
#define UMON_EBOOT_FILE_INDEX 		1


#ifdef HEXA_MODE_SUPPORT	/* 2012.07.03 Hexa mode display */
extern DWORD ColumnNumber;
#endif



extern DWORD	WIN_XSIZE;
extern DWORD	WIN_YSIZE;


extern DWORD	editXBgn, editWidth;
extern DWORD	editYBgn, editHeight;

extern DWORD	MainXBgn, MainWidth;
extern DWORD	MainYBgn, MainHeight;

extern DWORD 	WIN_XBgn, WIN_YBgn;

static BOOL 	is_resize = FALSE;
static RECT   MainRect, rect;
DWORD   W_dif = X_CAL, H_dif = Y_CAL;
extern int autoSendKey;
extern int localTime;
extern int msgSaveOnOff;
extern int msgMode; /* Text display or Hexa display */

BOOL 	is_auto_download_Key = FALSE;
WORD 	DownloadedBin = 0x00;
int 	BinFileIndex = 0; /* start = 0*/


static BOOL is_ram_usbtransmit_bl1 = FALSE;

extern FILE 	*fFileWrite;  /// added.
extern unsigned char buff_fin[DATE_LEN];

#define DNW_WIN_NAME            TEXT("DNW")


extern void LOGFile_close(void);



#define EDITID     1
#define STATUSID   2
#define TOOLBAR_ID 3
#define HEXAID     4


//#define MAX_EDIT_BUF_SIZE (0x7FFE) 
//#define EDIT_BUF_SIZE (0x6000)   
//#define EDIT_BUF_DEC_SIZE (0x2000)
#define MAX_EDIT_BUF_SIZE 		(0x8000000) /* 4 MB : 0x7FFFFFFE */  /// (0x6400000) /* 100 MB */
#define EDIT_BUF_SIZE 			(0x7FFFF00)
#define EDIT_BUF_DEC_SIZE 		(0x2000)

//1) Why program doesn't work when EDIT_BUF_SIZE=50000? 
//   If the data size of the edit box is over about 30000, 
//   EM_REPLACESEL message needs very long time.
//   So,EDIT_BUF_SIZE is limited to 30000. 
//   If the size is bigger than 30000, the size will be decreased by 5000. 
//2) WM_CLEAR to the edit box doesn't work. only, EM_REPLACESEL message works.

// ==============================================
// INITIALIZATION
// ==============================================

//////////////////////////////////////
// The WinMain function is the program entry point.
//////////////////////////////////////
#pragma argsused
int WINAPI WinMain(HINSTANCE hInst, HINSTANCE hPrevInstance,
                   LPSTR  lpszCmdParam, int nCmdShow)
{
    MSG  Msg;
	HACCEL hAccel;

    _hInstance = hInst;

    //OutputDebugString("");

    if (!Register(hInst))
		return FALSE;

    if (!Create(hInst, nCmdShow))
		return FALSE;


	hAccel=LoadAccelerators(hInst,MAKEINTRESOURCE(IDR_ACCELERATOR1)); /// HOT Key

    while (GetMessage(&Msg, NULL, 0, 0))
    {
		if( _hDlgDownloadProgress ==0 || !IsDialogMessage(_hDlgDownloadProgress,&Msg) ) 
		    //To throw the message to dialog box procedure
		{
			/*
		    TranslateMessage(&Msg);

		    //To intercept key-board input instead of edit control.
		    if(Msg.message==WM_CHAR) 
			SendMessage(_hwnd,WM_CHAR,Msg.wParam,Msg.lParam);
		    else	//2000.1.26
			DispatchMessage(&Msg);
		    //EB_Printf("."); //for debug*/
			if (!TranslateAccelerator(_hwnd,hAccel,&Msg)) 
			{
				TranslateMessage(&Msg);
				if(Msg.message==WM_CHAR) 
					SendMessage(_hwnd,WM_CHAR,Msg.wParam,Msg.lParam);
				else	//2000.1.26
					DispatchMessage(&Msg);
			}

		}
    }
    return Msg.wParam;
}


//////////////////////////////////////
// Register Window
//////////////////////////////////////
BOOL Register(HINSTANCE hInst)
{
#if 0
  WNDCLASS WndClass;

  WndClass.style          = CS_HREDRAW | CS_VREDRAW;
  WndClass.lpfnWndProc    = WndProc;
  WndClass.cbClsExtra     = 0;
  WndClass.cbWndExtra     = 0;
  WndClass.hInstance      = hInst;
  WndClass.hIcon          = LoadIcon(hInst,MAKEINTRESOURCE(IDI_ICON1));
  WndClass.hCursor        = LoadCursor(NULL,IDC_ARROW);
  WndClass.hbrBackground  = (HBRUSH)(COLOR_WINDOW+1);
  WndClass.lpszMenuName   = MAKEINTRESOURCE(IDR_MENU1);
  WndClass.lpszClassName  = szAppName;

  return (RegisterClass (&WndClass) != 0);
#else
  WNDCLASSEX WndClass;

  WndClass.cbSize	      = sizeof(WNDCLASSEX);
  WndClass.style          = CS_HREDRAW | CS_VREDRAW;
  WndClass.lpfnWndProc    = WndProc;
  WndClass.cbClsExtra     = 0;
  WndClass.cbWndExtra     = 0;
  WndClass.hInstance      = hInst;
  WndClass.hIcon          = LoadIcon(hInst, MAKEINTRESOURCE(IDI_ICON1)); /// IDI_APPLICATION
  WndClass.hCursor        = LoadCursor(hInst,IDC_ARROW);
  WndClass.hbrBackground  = (HBRUSH)(COLOR_WINDOW+1);
  //WndClass.hbrBackground  = (HBRUSH)CreateSolidBrush( COLOR_GRAY );
  //WndClass.hbrBackground  = (HBRUSH)GetStockObject(WHITE_BRUSH);
  WndClass.lpszMenuName   = MAKEINTRESOURCE(IDR_MENU1);
  WndClass.lpszClassName  = szAppName;
  WndClass.hIconSm	      = LoadIcon(hInst,MAKEINTRESOURCE(IDI_ICON2));

  return (RegisterClassEx(&WndClass) != 0);

#endif
}


#ifdef __TOOL_BAR__
TBBUTTON ToolBtn[5]={
		  {0,10,TBSTATE_ENABLED,TBSTYLE_BUTTON,0,0,0,0},
		  {1,11,TBSTATE_ENABLED,TBSTYLE_BUTTON,0,0,0,0},
		  {5,0,0,TBSTYLE_SEP,0,0,0,0},
		  {2,12,TBSTATE_ENABLED | TBSTATE_CHECKED,TBSTYLE_CHECKGROUP,0,0,0,0},
		  {3,13,TBSTATE_ENABLED,TBSTYLE_CHECKGROUP,0,0,0,0}
	   };
#endif ////////


//////////////////////////////////////
// Create the window and show it.
//////////////////////////////////////
BOOL Create(HINSTANCE hInst, int nCmdShow)
{
	GetRegistry();

	HWND hwnd = CreateWindow(szAppName, szAppName,
							WS_OVERLAPPEDWINDOW /*&(~(WS_SIZEBOX|WS_MAXIMIZEBOX|WS_MINIMIZEBOX))*/,
							0, 0, /* CW_USEDEFAULT, CW_USEDEFAULT, */
							WIN_XSIZE, WIN_YSIZE, /*WINDOW_XSIZE, WINDOW_YSIZE, */
							NULL, NULL, hInst, NULL);

  
	if (hwnd == NULL)
		return FALSE;

	//_hwnd=hwnd; 

	GetWindowRect(hwnd,&MainRect); /// added.
	_MainHwnd = hwnd;  /// added.

	///////////////////////////////////////////////////////////////////////////////
#ifdef __TOOL_BAR__
	InitCommonControls();
	
	HWND hToolBar = CreateToolbarEx(hwnd, WS_CHILD | WS_VISIBLE | WS_BORDER,
						  TOOLBAR_ID, 4, hInst, NULL /*IDB_BITMAP1*/, ToolBtn, 5,
						  16,16,16,16,sizeof(TBBUTTON));
#endif
	///////////////////////////////////////////////////////////////////////////////


	ShowWindow(hwnd, nCmdShow);
	UpdateWindow(hwnd); /* ������ ���ν����� WM_PAINT �޽����� ���� �۾������� ������ �׸�����(��� �ٽñ׸�)  */

	return TRUE;
}

//==============================================
// IMPLEMENTATION
//==============================================
LRESULT CALLBACK WndProc(HWND hwnd, UINT Message, WPARAM wParam, LPARAM lParam)
{
    //static HINSTANCE hInst;
	int 		comp=0;
	int 		wmId, wmEvent;
	WORD 		BinType = 0;
	int 		tID=0; /* eTimerID */
	//HCURSOR 	hcur1;
#if  0
	static 		HWND hSB;
	PTSTR 		pstr = TEXT("Owner draw Text");
	BOOL 		fResult=FALSE;
#endif

	// ---- ȣȯ�� ������ ���� �� �ô��� �Ķ���ʹ� ������ ���� ---
	/// UNREFERENCED_PARAMETER(hPrevInstance);
	/// UNREFERENCED_PARAMETER(lpCmdLine);


	///HWND hwndRichedit = (HWND)GetWindowLong(hwnd, 0 ); /// added.
	
    switch(Message)
    {
    case WM_CREATE:


	   if( FALSE == isFileExist( TEXT(".\\dnwconfig") ) )
	   {
		   if( FALSE == CreateDirectory( TEXT("dnwconfig"), NULL) )
		   {
			   EB_Printf(TEXT("[dnw] Can not create the dnwconfig!!! "));
		   }
		   else
		   {
			   /// EB_Printf(TEXT("[dnw] dnwconfig!!! --- OK \r\n"));
		   }
	   }
	   else
	   {
		   ///EB_Printf(TEXT("[dnw] found!!!! === \r\n"));
	   }


       //PlaySound(TEXT("d:\\windows\\media\\chimes.wav"),NULL,SND_FILENAME|SND_ASYNC);
		_hwnd=hwnd;

        PopFileInitialize(hwnd);

		GetRegistry();  /// added.

		SetTimer(hwnd,TIMER_ID_WIN_UPDATE, 1000, NULL); /* dnw title - 1sec ���� update */


		// Create the edit control child window
		_hwndEdit = CreateWindow (TEXT("edit"),  NULL,
					WS_CHILD | WS_VISIBLE | WS_VSCROLL | /*WS_HSCROLL |*/ 
                    WS_BORDER | ES_LEFT | ES_MULTILINE | ES_READONLY /* | TBSTYLE_TOOLTIPS  */
                    /* | ES_SUNKEN | ES_NOHIDESEL|*/ /*ES_AUTOVSCROLL*/ /*|ES_AUTOHSCROLL*/ , 
                    0, 0, /* CW_USEDEFAULT, CW_USEDEFAULT,*/
                    WIN_XSIZE, WIN_YSIZE, /*SCREEN_X, SCREEN_Y, */
					hwnd, (HMENU)EDITID, ((LPCREATESTRUCT)lParam)->hInstance, NULL);


#if defined(COLOR_DISP2)
		if( 0 != ColorType )
			m_Brush = CreateSolidBrush( (COLORREF)COLOR_BLACK );
#endif

		SetWindowLong( _hwndEdit, 
						GWL_EXSTYLE, /* GWL_USERDATA|DWL_USER|GWL_STYLE|GWL_WNDPROC|GWL_ID|DWL_DLGPROC|DWL_MSGRESULT*/
						TRUE); /// added.

		//hcur1 = LoadCursor( NULL, IDC_CROSS );
		//hcur1 = LoadCursorFromFile(TEXT("icon1.ico"));


		SetFont(_hwndEdit);

#ifdef RICHED_COLOR //////////////////////////////////////
		hDll = LoadLibrary("riched32"); /// added.
{
		CHARFORMAT cf = {0};
		
		cf.cbSize = sizeof(CHARFORMAT);
		cf.dwMask = CFM_COLOR; /// CFM_COLOR; /// CFM_FACE; /// CFM_BACKCOLOR; /// CFM_ALL2|CFM_COLOR; /// |CFM_BOLD;
		cf.dwEffects = CFE_BOLD;
		cf.crTextColor = COLOR_WHITE;
	//	cf.yHeight = ;
	//	cf.yOffset = ;
	//	cf.bCharSet = ;
	//	cf.bPitchAndFamily = ;
	//	cf.szFaceName[LF_FACESIZE];

		/* color */
		///_tcscpy(cf.szFaceName, string2);
		SendMessage(_hwndEdit, EM_SETCHARFORMAT|EM_SETBKGNDCOLOR,SCF_SELECTION, (LPARAM)&cf); /// color added
}
#endif

#if 0 /// 2013.05.22
		hSB = CreateStatusWindow(WS_CHILD|WS_VISIBLE, TEXT("This is a test"), _hwnd, 0);
		if( NULL == hSB )
		{
			MessageBox(NULL, TEXT("CreateStatusWindow failed!"), TEXT("Error"), MB_OK);
		}

		fResult = SendMessage(hSB, SB_SETTEXT, SBT_OWNERDRAW, (LPARAM)pstr);
		if( FALSE == fResult )
		{
			MessageBox(NULL, TEXT("SB_SETTEXT failed!"), TEXT("Error"), MB_OK);
		}
#endif

		SendMessage(_hwndEdit, EM_SETLIMITTEXT, MAX_EDIT_BUF_SIZE, 0L);

		ReadUserConfig(hwnd); //To get serial settings

		if( ReadQuickUserConfig(hwnd) ) /* NAND files */
		{
			ReWriteQuickUserConfig(); /// re-arrange : EBOOT -> STEPLDR -> NK
			ReadQuickUserConfig(hwnd);
		}

		ReadQuickUMONConfig(hwnd); /* Umon Files */

		MenuConnect(hwnd);

		GetWindowRect(_hwndEdit, &rect);
		_EditHwnd = _hwndEdit;

		return 0; 


    case WM_COMMAND:
		wmEvent = HIWORD(wParam);
		wmId    = LOWORD(wParam); 
        if(lParam==0) //is menu command?
		{
			switch(wmId) ///LOWORD(wParam))
			{
			case IDM_EXIT: /* ESC key */
			case CM_EXIT:
				for(tID = TIMER_ID_WIN_UPDATE; tID <TIMER_ID_MAX; tID ++)
				{
					KillTimer(hwnd, tID);
				}


	#ifdef RICHED_COLOR //////////////////////////////////////
				FreeLibrary(hDll); /// added.
	#endif

				LOGFile_close();
				Quit(hwnd);
				ReleaseFont();
				downloadCanceled = 1;

				ScrClear(hwnd); /// 2013.04.10, added.
				
				SetRegistry(); /* Saved Last Windows size */

				DestroyWindow(_MainHwnd); /// 2010.05.12 added.
				DestroyWindow(_hwndEdit); /// 2010.05.12 added.

				if( _MainHwnd ) { CloseHandle( _MainHwnd ); _MainHwnd=NULL; }
				if( _hwndEdit ) { CloseHandle( _hwndEdit ); _hwndEdit=NULL; }

#ifdef COLOR_DISP2 /// 2010.05.14
				if( m_Brush ) { DeleteObject( m_Brush ); m_Brush = NULL; }
#endif

				PostQuitMessage(0);
				return 0;

				break;

			case CM_CONNECT:
				MenuConnect(hwnd);
				break;

			case CM_DISCONNECT:
				MenuDisconnect(hwnd);
				break;

			case IDM_CONNECT_DISCONNECT: /* function key, F2 toggle  */
				MenuConnectDisconnect(hwnd);
				break;

			case CM_TRANSMIT:
				MenuTransmit(hwnd);
				break;

			case IDM_OPTIONS: /* F12 key */
			case CM_OPTIONS:
				MenuOptions(hwnd);
				break;

#ifdef HEXA_MODE_SUPPORT	/* 2011.02.08 Hexa mode display */
			case IDM_TEXT_HEXA_MODE: /* F5 ; text mode or Hexa mode */
				if(msgMode) msgMode=0;  /// Toggle 1 -> 0
				else msgMode=1;    /// 0 -> 1
				break;
#endif

			case IDM_CLEAR_BUFFER: /* function key, F11 */
			case CM_CLEAR_BUF:
				ScrClear(hwnd);
				break;

			case IDM_USBTRANSMIT: /* Shift + F10 */
			case CM_USBTRANSMIT:
				MenuUsbTransmit(hwnd);
				break;

//#ifdef SANSIX_SMP201_CUSTOMIZING
			case IDM_UMON_TRANSMIT_TO_RAM: /* F4 */
			case CM_RAM_USBTRANSMIT_BL1:
				if( TRUE == autoSendKey )
				{
					ScrClear(hwnd); /// added.

					KillTimer(hwnd, TIMER_ID_AFTER_BL1);
					KillTimer(hwnd, TIMER_ID_AUTO_DOWNLOAD_KEY_SEND);

					is_ram_usbtransmit_bl1 = FALSE;
					if( TRUE == RAM_MenuUsbTransmit(hwnd, UMON_IRAM_BL1_FILE_INDEX) ) /* 4th file in dnw_usbboot.ini ... bl1 */
					{
						EB_Printf(TEXT("[dnw] L2 >> iRAM USB Booter, bl1 TX OK.  2sec Waiting... \n"));
						is_ram_usbtransmit_bl1 = TRUE;
						SetTimer(hwnd,TIMER_ID_AFTER_BL1,  2000,NULL);  /// <- 3000
						/* Do Timer, TIMER_ID_AFTER_BL1  -> Write EBOOT to RAM 
						   That is, call function,  RAM_MenuUsbTransmit(hwnd, UMON_EBOOT_FILE_INDEX);
						*/
					}
				}
				else
				{
					KillTimer(hwnd, TIMER_ID_AFTER_BL1);
					KillTimer(hwnd, TIMER_ID_AUTO_DOWNLOAD_KEY_SEND);
					EB_Printf(TEXT("[dnw] check [AutoSend] of option(F12) menu.. \n"));
				}
				break;

			case IDM_ALL_BINS_TO_NAND:
			case CM_ROM_ALL:
				if( BinFileIndex >= 3 ) 
				{
					BinFileIndex = 0;
					DownloadedBin = 0x00;
					break;
				}

				BinType = ROM_MenuUBOOT2(hwnd, BinFileIndex);
				DownloadedBin |= BinType;
				if( BinType )  /* 1st file in dnw_usbboot.ini ... bl1 */
				{
					BinFileIndex ++;
				}
				break;
				
			case IDM_NK_TO_NAND:
			case CM_ROM_UBOOT2_1ST: /* F7 => in dnw_usbboot.ini */
		#if 0
				BinFileIndex = 0;  /* F7 initila */
				DownloadedBin = 0x00;

				if( DNW_EBOOT == (DownloadedBin & DNW_EBOOT) )
				{
					EB_Printf(TEXT("[dnw] EBOOT already downloaded..... one more ++++++ \n"));
				}
		#endif
				BinType = ROM_MenuUBOOT2(hwnd, 0);
				if( BinType )
				{
					DownloadedBin |= DNW_EBOOT;
				}
				break;

			case IDM_EBOOT_TO_NAND:
			case CM_ROM_UBOOT2_2ND: /* F8 => in dnw_usbboot.ini */
		#if 0
				if( DNW_NK == (DownloadedBin & DNW_NK) )
				{
					EB_Printf(TEXT("[dnw] NK.bin already downloaded..... one more +++++ \n"));
				}
		#endif
				BinType = ROM_MenuUBOOT2(hwnd, 1);
				if( BinType )
				{
					DownloadedBin |= DNW_NK;
				}
				break;

			case IDM_STEPLDR_TO_NAND:
			case CM_ROM_UBOOT2_3RD: /* F9 => in dnw_usbboot.ini */
		#if 0
				if( DNW_STEP == (DownloadedBin & DNW_STEP) )
				{
					EB_Printf(TEXT("[dnw] StepLdr.nb0 already downloaded..... one more +++++  \n"));
				}
		#endif
				BinType = ROM_MenuUBOOT2(hwnd, 2);
				if( BinType )
				{
					DownloadedBin |= DNW_STEP;
				}
		#if 0
				if( TOTAL_BIN_OK == DownloadedBin )
				{
					DownloadedBin = 0x00; /* initial */
				}
		#endif
				break;
//#endif

			case CM_UBOOT:
				MenuUBOOT(hwnd);
				break;

			case IDM_UBOOT2: /* Shift + F11 */
			case CM_UBOOT2:
				MenuUBOOT2(hwnd);
				break;

			case CM_USBRECEIVE:
				MenuUsbReceive(hwnd);
				break;      

			case CM_USBSTATUS:
				MenuUsbStatus(hwnd);
				break;

			case IDM_ABOUT: /* F10 */
			case CM_ABOUT:
				MenuAbout(hwnd);
				break;

			case IDM_EDIT_COPY:
				SendMessage(_hwndEdit, WM_COPY, 0, 0);
				break;

			case IDM_EDIT_ALL:
				SendMessage(_hwndEdit, EM_SETSEL, 0, -1);
				break;

			case IDM_EDIT_COPYALL:
				SendMessage(_hwndEdit, EM_SETSEL, 0, -1);
				SendMessage(_hwndEdit, WM_COPY, 0, 0);
				break;

			default:
				//EB_Printf(TEXT("[dnw] . lParam=0x%X  wParam=0x%X\n"), lParam, wParam );
				if (LOWORD(wParam) >= HISTORYMENUID && LOWORD(wParam) < (HISTORYMENUID+MAXHISTORY/3))
				{
					MenuUsbTransmitHistory(hwnd, LOWORD(wParam)-HISTORYMENUID);
				}
				if (LOWORD(wParam) >= (HISTORYMENUID+MAXHISTORY/3) && LOWORD(wParam) < (HISTORYMENUID+(MAXHISTORY*2)/3))
				{
					MenuUBOOTHistory(hwnd, LOWORD(wParam)-HISTORYMENUID);
				}
				if (LOWORD(wParam) >= (HISTORYMENUID+(MAXHISTORY*2)/3) && LOWORD(wParam) < (HISTORYMENUID+MAXHISTORY))
				{
					MenuUBOOTHistory2(hwnd, LOWORD(wParam)-HISTORYMENUID);
				}
				break;
			}
			return 0;
		}
		else
		{
			///EB_Printf(TEXT("[dnw] . lParam=0x%X  wParam=0x%X\n"), lParam, wParam );
		}
		return 0;

		break;

    // WM_PAINT should be processed on DefWindowProc(). 
    // If there is WM_PAINT, there should be UpdateWindow(_hwndEdit). 

/*
	case WM_PAINT:
		UpdateWindow(_hwndEdit);
		return 0;
	*/


#if 0
	case WM_KEYDOWN:
		switch(wParam)
		{
			case 0xbf: /// '/':
			case 0xbc: /// ',':
				break;

			case VK_F1: /* 0x70 : clear buffer	*/
			case VK_F2: /* 0x71 : COM port toggle */
			case VK_F4: /* 0x73 : UMON transmit to RAM */
			case VK_F12:/* 0x7B : options */
			default :
				///EB_Printf(TEXT("[dnw] WM_KEYDOWN.. 0x%X\n"), wParam );
				break;
		}
		break;
#endif

	case WM_SETFOCUS:
		SetFocus( _hwndEdit );
		break;

#if 0
	case WM_SETCURSOR:
		if (LOWORD(lParam) == HTCLIENT)
		{
			SetCursor(hcur1);
			return 0;
		}
		break;
#endif

	case WM_CLOSE:
	case WM_QUIT:
    case WM_DESTROY:
		for(tID = TIMER_ID_WIN_UPDATE; tID <TIMER_ID_MAX; tID ++)
		{
			KillTimer(hwnd, tID);
		}

	#ifdef RICHED_COLOR //////////////////////////////////////
		FreeLibrary(hDll); /// added.
	#endif
	
		LOGFile_close();
		Quit(hwnd);
		ReleaseFont();
		downloadCanceled = 1;

		ScrClear(hwnd); /// 2013.04.10, added.

		SetRegistry(); /* Saved Last Windows size */

		DestroyWindow(_MainHwnd); /// 2010.05.12 added.
		DestroyWindow(_hwndEdit); /// 2010.05.12 added.

		if( _MainHwnd ) { CloseHandle( _MainHwnd );  _MainHwnd=NULL; } /// added.
		if( _hwndEdit ) { CloseHandle( _hwndEdit );  _hwndEdit=NULL; }/// added.
		
#ifdef COLOR_DISP2 /// 2010.05.14
		if( m_Brush ) { DeleteObject( m_Brush ); m_Brush = NULL; }
#endif

		PostQuitMessage(0);
		return 0;

	case WM_TIMER:
		switch(wParam)
		{
			case TIMER_ID_WIN_UPDATE:
				UpdateWindowTitle();
				break;

			/* --------------- UMON RAM Files --------------------- */
			case TIMER_ID_AFTER_BL1:
				KillTimer(hwnd, TIMER_ID_AFTER_BL1);
				if( TRUE == autoSendKey ) /// if( TRUE == is_ram_usbtransmit_bl1 )
				{
					if( TRUE == RAM_MenuUsbTransmit(hwnd, UMON_EBOOT_FILE_INDEX) ) /* 5th file in dnw_usbboot.ini,	*/
					{
						//// KillTimer(hwnd, TIMER_ID_AFTER_BL1);
						is_ram_usbtransmit_bl1 = FALSE;
						is_auto_download_Key = FALSE;
						if( TRUE == autoSendKey )
						{
							SetTimer(hwnd, TIMER_ID_AUTO_DOWNLOAD_KEY_SEND, 500, NULL);  /* 400ms FIX : SPACE BAR sending */
							EB_Printf(TEXT("[dnw] L2 >> Auto download ; Eboot TX OK...\n"));
						}
					}
					else
					{
						EB_Printf(TEXT("[dnw] Auto retry... 3sec wait..  or DO power off \n"));
					}
				}
				break;

			case TIMER_ID_AUTO_DOWNLOAD_KEY_SEND:
				KillTimer(hwnd, TIMER_ID_AUTO_DOWNLOAD_KEY_SEND );
				is_auto_download_Key = TRUE;
				WriteCommBlock(0x20); /* SPACE BAR send for downloading eboot menu */
				WriteCommBlock(0x20); /* retry  */
				WriteCommBlock(0x20); /* retry  */

#if 0 /// def SLC_NAND
{
volatile int delayi = 0;
				for(delayi=0; delayi < 1000; delayi ++) { ; }
				WriteCommBlock('F'); /* SLC NAND Format send */

				for(delayi=0; delayi < 5*1000; delayi ++) { ; }
}
#endif
				break;

			case TIMER_ID_MSG_WRITE_TO_FILE:
				///KillTimer(hwnd, TIMER_ID_MSG_WRITE_TO_FILE );
				if( msgSaveOnOff )
				{
					if( fFileWrite && buff_fin /*&& GetIsConnect() */ )
					{
						fclose(fFileWrite);
						fFileWrite = fopen( (const char*)buff_fin, "a+");
						if( NULL == fFileWrite )
						{
							/// error
							EB_Printf(TEXT("[dnw] can not write dnw log file. File buffer is NULL. Error=%u\n"), GetLastError() );
						}
					}
				}
				break;
				
			default:
				break;
		}
		return 0;

#if 0
	case WM_MOVE:
	{
		int  xpos, ypos;
		WIN_XBgn =  LOWORD(lParam)&0x0ffff; /* x cal */  /// added.
		WIN_YBgn =  HIWORD(lParam)&0x0ffff; /* y cal */  /// added.


		GetWindowRect(_hwndEdit, &rect);
		_EditHwnd = _hwndEdit;


		xpos = WIN_XBgn-editXBgn;
		ypos = WIN_YBgn-editYBgn;

		if( xpos <=0 ) xpos = 0;
		if( ypos <=0 ) ypos = 0;

		
		MoveWindow (_MainHwnd, xpos, ypos, (WIN_XSIZE), (WIN_YSIZE), TRUE);

		MoveWindow (_hwndEdit, xpos, ypos, (WIN_XSIZE-W_dif), (WIN_YSIZE-H_dif), TRUE);
	    EB_Printf(TEXT("[dnw] WM_MOVE ==> [X:%d, Y:%d],  [%d, %d] \n"), WIN_XBgn, WIN_YBgn, editXBgn, editYBgn );
		
	    return 0;
		break;
	}
#endif

    case WM_SIZE:
		/* main window */
		MainXBgn   = MainRect.left;
		MainYBgn   = MainRect.top;
		MainWidth  = MainRect.right;
		MainHeight = MainRect.bottom;

		/* edit  window */
		editXBgn   = rect.left;
		editYBgn   = rect.top;
		editWidth  = rect.right;
		editHeight = rect.bottom;

		/* main frame �� edit frame�� ���̷� ���Ͽ� windows ũ�Ⱑ �ٸ���... ����.... */
		W_dif = abs(editXBgn-MainXBgn)+abs(editWidth-MainWidth);
		H_dif = abs(editYBgn-MainYBgn)+4;
		///H_dif = abs(editYBgn-MainYBgn)+WIN_XBgn;

	#if 0
		EB_Printf(TEXT("[dnw] Main:[%d, %d, %d, %d] \n"), MainXBgn, MainYBgn, MainWidth, MainHeight);
		EB_Printf(TEXT("[dnw] edit:[%d, %d, %d, %d] [%d,%d]\n"), editXBgn, editYBgn, editWidth, editHeight, WIN_XBgn, WIN_YBgn);
		//EB_Printf(TEXT("[dnw] [%d, %d, %d, %d] \n"), 
		//	rect.left-MainRect.left, rect.top-MainRect.top, rect.right-MainRect.right, rect.bottom-MainRect.bottom 	);
		//EB_Printf(TEXT("[dnw] pos:[%d, %d] \n"), W_dif, H_dif );
	#endif
	
		if( FALSE == is_resize ) 
		{
			is_resize = TRUE;

			MoveWindow (_hwndEdit, 0, 0, (WIN_XSIZE-W_dif), (WIN_YSIZE-H_dif), FALSE);
			return 0;
		}


		MoveWindow (_hwndEdit, 0, 0, LOWORD(lParam), HIWORD(lParam), TRUE);
		WIN_XSIZE = LOWORD (lParam)+W_dif; /* x cal */  /// added.
		WIN_YSIZE = HIWORD (lParam)+H_dif; /* y cal */  /// added.

        return 0;


	//If the size of the parent window is not adjustable,
	//WM_SIZE message is not received.
	//If the size of the parent window is adjustable,
	//WM_SIZE message is received although window size is not changed.
	//MoveWindow(,,,,,TRUE) will make WM_PAINT.
	
	//If DefWindowProc() doesn't process WM_PAINT and WM_PAINT is processed by user, 
	//UpdateWindow(_hwndEdit) is should be executed inide WM_PAINT case,
	//which update the child window.
	    
    case WM_CHAR:
		WriteCommBlock((char)wParam);    //UNICODE problem!!!
		return 0;

#if defined(COLOR_DISP2) /// 2010.05.14
	/*
	  * Read-only or disabled edit controls do not send the WM_CTLCOLOREDIT message; 
	  * instead, they send the WM_CTLCOLORSTATIC 
	  */

	//case WM_CTLCOLORSCROLLBAR:
    case WM_CTLCOLOREDIT: //for changing FONT & COLOR
	    //EB_Printf(TEXT("[dnw] COLOREDIT +++ \n") );
	case WM_CTLCOLORSTATIC:
		if( 0 != ColorType ) /* 0:default, 1:Black style */
		{
			SetBkColor((HDC)wParam, COLOR_BLACK );
			SetTextColor((HDC)wParam, COLOR_WHITE );
			return (LRESULT)m_Brush;  
		}
		//return 0;
		//return (LRESULT)m_Brush;  
		//return GetStockObject(LTGRAY_BRUSH);
		//return (HBRUSH)m_Brush.GetSafeHandle();
		break;

#if 0	  
    case WM_CTLCOLOR: //for changing FONT & COLOR
    case WM_CTLCOLOREDIT: //for changing FONT & COLOR
	    EB_Printf(TEXT("[dnw] WM_CTLCOLOR  \n"));
		if ( HIWORD(lParam) == CTLCOLOR_EDIT ) 
		{
			EB_Printf(TEXT("[dnw] WM_CTLCOLOREDIT  \n"));
			// Set the text background color.
			SetBkColor((HDC)wParam,  RGB(128,128,128) );

			// Set the text foreground color.
			///SetTextColor(wParam, RGB(255, 255, 255) );
			// Return the control background brush.
			return 0; /// GetStockObject(LTGRAY_BRUSH);
		}
		else
			return 0; /// GetStockObject(WHITE_BRUSH);
#endif
#endif /////////////////////////////// COLOR_DISP /// 2010.05.14

//////////////////////////////////////////////////////////////////////////////
#if 0 /// refer 
	case WM_MOVING:
	case WM_MOVE:
	case WM_NULL:
	case WM_ACTIVATE:
	case WM_SETFOCUS:
	case WM_KILLFOCUS:
	case WM_ENABLE:
	case WM_SETREDRAW:
	case WM_SETTEXT:
	case WM_GETTEXT:
	case WM_GETTEXTLENGTH:
	case WM_PAINT:
	case WM_ERASEBKGND:
	case WM_SYSCOLORCHANGE:
	case WM_SHOWWINDOW:
	case WM_WININICHANGE:
	case WM_DEVMODECHANGE:
	case WM_ACTIVATEAPP:
	case WM_FONTCHANGE:
	case WM_TIMECHANGE:
	case WM_CANCELMODE:
	case WM_SETCURSOR:
	case WM_MOUSEACTIVATE:
	case WM_CHILDACTIVATE:
	case WM_QUEUESYNC:
	case WM_GETMINMAXINFO:
		PMINMAXINFO p = (PMINMAXINFO)lParam;
	case WM_PAINTICON:
	case WM_ICONERASEBKGND:
	case WM_NEXTDLGCTL:
	case WM_SPOOLERSTATUS:
	case WM_DRAWITEM:
	case WM_MEASUREITEM:
	case WM_DELETEITEM:
	case WM_VKEYTOITEM:
	case WM_CHARTOITEM:
	case WM_SETFONT:
	case WM_GETFONT:
	case WM_SETHOTKEY:
	case WM_GETHOTKEY:
	case WM_QUERYDRAGICON:
	case WM_COMPAREITEM:
	case WM_GETOBJECT:
	case WM_COMPACTING:
	case WM_COMMNOTIFY:
	case WM_WINDOWPOSCHANGING:
		PWINDOWPOS p = (PWINDOWPOS) lParam;
	case WM_WINDOWPOSCHANGED:
	case WM_POWER:
	case WM_COPYDATA:
	case WM_CANCELJOURNAL:
	case WM_CONTEXTMENU:
	case WM_STYLECHANGING:
	case WM_STYLECHANGED:
	case WM_GETICON:
	case WM_NCCREATE:
	case WM_NCCALCSIZE:
	case WM_NCHITTEST:
	case WM_NCPAINT:
	case WM_NCACTIVATE:
	case WM_NCMOUSEMOVE:
	case WM_NCLBUTTONDOWN:
	case WM_NCLBUTTONUP:
	case WM_NCLBUTTONDBLCLK:
	case WM_NCRBUTTONDOWN:
	case WM_NCRBUTTONUP:
	case WM_NCRBUTTONDBLCLK:
	case WM_NCMBUTTONDOWN:
	case WM_NCMBUTTONUP:
	case WM_NCMBUTTONDBLCLK:
	case WM_KEYDOWN:
	case WM_KEYUP:
	case WM_CHAR:
	case WM_DEADCHAR:
	case WM_SYSKEYDOWN:
	case WM_SYSKEYUP:
	case WM_SYSCHAR:
	case WM_SYSDEADCHAR:
	case WM_UNICHAR:
	case WM_IME_STARTCOMPOSITION:
	case WM_IME_ENDCOMPOSITION:
	case WM_IME_COMPOSITION:
	case WM_COMMAND:
	case WM_SYSCOMMAND:
	case WM_HSCROLL:
	case WM_VSCROLL:
	case WM_INITMENU:
	case WM_INITMENUPOPUP:
	case WM_MENUSELECT:
	case WM_MENUCHAR:
	case WM_ENTERIDLE:
	case WM_UNINITMENUPOPUP:
	case WM_MOUSEMOVE:
	case WM_LBUTTONDOWN:
	case WM_LBUTTONUP:
	case WM_LBUTTONDBLCLK:
	case WM_RBUTTONDOWN:
	case WM_RBUTTONUP:
	case WM_RBUTTONDBLCLK:
	case WM_MBUTTONDOWN:
	case WM_MBUTTONUP:
	case WM_MBUTTONDBLCLK:
	case WM_MOUSEWHEEL:
	case WM_XBUTTONDOWN:
	case WM_XBUTTONUP:
	case WM_XBUTTONDBLCLK:
	case WM_MOUSEHWHEEL:
	case WM_ENTERMENULOOP:
	case WM_EXITMENULOOP:
	case WM_SIZING:
	case WM_CAPTURECHANGED:
	case WM_ENTERSIZEMOVE:
	case WM_EXITSIZEMOVE:
	case WM_IME_SETCONTEXT:
	case WM_IME_NOTIFY:
	case WM_IME_CONTROL:
	case WM_IME_COMPOSITIONFULL:
	case WM_IME_SELECT:
	case WM_IME_CHAR:
	case WM_IME_KEYDOWN:
	case WM_NCMOUSELEAVE:
		break;
#endif
//////////////////////////////////////////////////////////////////////////////

    }


    return DefWindowProc(hwnd, Message, wParam, lParam); 

}

//8: \b
//13: \r

// 1)about EM_SETSEL message arguments
//   start_position,end_position
//   The selected character is from start_position to end_position-1;
//   So, We should do +1 to the position of last selected character.
// 2)The char index start from 0.
// 3)WM_CLEAR,WM_CUT doesn't operate on EM_SETSEL chars.




#define STRING_LEN  4096  
volatile static int isUsed=0;


#if 1 /* 2011.02.08 , Text Mode or Hexa Mode */
const TCHAR HexEncodeTable[16+1] = TEXT("0123456789ABCDEF"); 
#endif

void EB_Printf(TCHAR *fmt,...)
{
    va_list ap;
    int i,slen,lineIdx;
    int txtRepStart,txtRepEnd,txtSelEnd;
    static int wasCr=0; //should be static type.
    static TCHAR string[STRING_LEN+4096] = {0,}; //margin for '\b'
    static TCHAR string2[STRING_LEN+4096] = {0,}; //margin for '\n'->'\r\n'
    static int prevBSCnt=0;
    int str2Pt=0;
    static int tmpmsgMode=0xff;


#ifdef RICHED_COLOR //////////////////////////////////////
	CHARFORMAT cf = {0};

	cf.cbSize = sizeof(CHARFORMAT);
	cf.dwMask = CFM_BACKCOLOR; /// CFM_COLOR; /// CFM_FACE; /// CFM_BACKCOLOR; /// CFM_ALL2|CFM_COLOR; /// |CFM_BOLD;
	cf.dwEffects = CFE_BOLD;
	cf.crTextColor = COLOR_RED;
//	cf.yHeight = ;
//	cf.yOffset = ;
//	cf.bCharSet = ;
//	cf.bPitchAndFamily = ;
//	cf.szFaceName[LF_FACESIZE];
#endif ///////////////////////////////////////



#ifdef _DELETE_FUNC_ /* -- 2013.04.20 -- */
    while( 1 == isUsed )
    {
		; //EB_Printf can be called multiplely  //KIW
    }
#endif


#ifdef HEXA_MODE_SUPPORT
	if( (1 == msgMode) && (tmpmsgMode != msgMode) ) 
	{
		tmpmsgMode = msgMode;
		memset( string, 0x00, sizeof(string) );
		memset( string2, 0x00, sizeof(string2) );
	}
#endif

    txtRepStart=SendMessage(_hwndEdit,WM_GETTEXTLENGTH,0x0,0x0);
    txtRepEnd=txtRepStart-1;



#ifdef RICHED_COLOR
	//////////////////////////////////////
	/* set color */
	SendMessage(_hwndEdit, EM_SETCHARFORMAT|EM_SETBKGNDCOLOR, SCF_SELECTION|SCF_WORD, (LPARAM) &cf);
	//SendMessage(_hwndEdit, EM_SETCHARFORMAT, SCF_SELECTION|SCF_WORD, (LPARAM) &cf);
	///SetWordCharFormat(cf);
	//////////////////////////////////////
#endif


    va_start(ap,fmt);
    _vsntprintf(string2,STRING_LEN-1,fmt,ap);
    va_end(ap);

    string2[STRING_LEN-1]='\0';

    //for better look of BS(backspace) char.,
    //the BS in the end of the string will be processed next time.
    for(i=0;i<prevBSCnt;i++) //process the previous BS char.
		string[i]='\b';

    string[prevBSCnt]='\0';
    lstrcat(string,string2);
    string2[0]='\0';

    slen=lstrlen(string);
    for(i=0;i<slen;i++)
    	if(string[slen-i-1]!='\b')break;
    
    prevBSCnt=i; // These BSs will be processed next time.
    slen=slen-prevBSCnt;

    if(slen==0)
    {
		isUsed=0;
		return;
    }

    for(i=0;i<slen;i++)
    {

#ifdef HEXA_MODE_SUPPORT	/* 2011.02.08 Hexa mode display */
		if( 1 == msgMode ) /* Hex mode all (including special chars)  ==> type : FF */
		{
			if( ColumnNumber && (0==(i%ColumnNumber)) )
			{
			    string2[str2Pt++]='\r';txtRepEnd++;
			    string2[str2Pt++]='\n';txtRepEnd++;
			}

			// ���� �ڵ尡 ���� ��� 
			string2[str2Pt++] = HexEncodeTable[ (string[i] & 0xF0) >> 4 ]; 
			string2[str2Pt++] = HexEncodeTable[ (string[i] & 0x0F) ]; 
			string2[str2Pt++] = TEXT(' '); 
			txtRepEnd += 3;
			
		}
	#if 0
		else if( 2 == msgMode ) /* Hex mode all (including special chars) ==?> type : 0xFF */
		{
			// ���� �ڵ尡 ���� ��� 
			string2[str2Pt++] = '0'; 
			string2[str2Pt++] = 'x'; 
			string2[str2Pt++] = HexEncodeTable[ (string[i] & 0xF0) >> 4 ]; 
			string2[str2Pt++] = HexEncodeTable[ (string[i] & 0x0F) ]; 
			string2[str2Pt++] = ' '; 
			txtRepEnd += 5;
		}
	#endif
		else /// if (0 == msgMode) /* Text Mode 2011.02.08 */
#endif ///
		{
		
			if( (string[i]=='\n'))
			{
			    string2[str2Pt++]='\r';txtRepEnd++;
			    string2[str2Pt++]='\n';txtRepEnd++;
			    wasCr=0;
			    continue;
			}
			if( (string[i]!='\n') && (wasCr==1) )
			{
			    string2[str2Pt++]='\r';txtRepEnd++;
			    string2[str2Pt++]='\n';txtRepEnd++;
			    wasCr=0;
			}
			if(string[i]=='\r')
			{
			    wasCr=1;
			    continue;
			}

			if( string[i]=='\b' ) 
			{
			    //flush string2
			    if(str2Pt>0)
			    {
					string2[--str2Pt]='\0';
					txtRepEnd--;
					continue;
			    }
			    //str2Pt==0;	    
			    if(txtRepStart>0)
			    {
					txtRepStart--;		
			    }
			    continue;
			}

			string2[str2Pt++]=string[i];
			txtRepEnd++;
		}
		// if(str2Pt>FILENAMELEN-3)break; //why needed? 2001.1.26
    }


    string2[str2Pt]='\0';    
    if(str2Pt>0)
    {

	#ifdef RICHED_COLOR //////////////////////////////////////
		/* color */
		///_tcscpy(cf.szFaceName, string2);
		SendMessage(_hwndEdit,EM_SETCHARFORMAT|EM_SETBKGNDCOLOR,SCF_SELECTION, (LPARAM)&cf); /// color added
	#endif


		/* EditBox�� �ؽ�Ʈ �̾ �߰��ϱ�  , EM_SETTEXTEX*/
		SendMessage(_hwndEdit,EM_SETSEL,     (WPARAM)txtRepStart, (LPARAM)txtRepEnd+1);
		SendMessage(_hwndEdit,EM_REPLACESEL, (WPARAM)FALSE,       (LPARAM)((LPSTR)string2) ); 

    }
    else
    {
		if(txtRepStart<=txtRepEnd)
		{

	#ifdef RICHED_COLOR //////////////////////////////////////
			SendMessage(_hwndEdit,EM_SETCHARFORMAT|EM_SETBKGNDCOLOR,SCF_SELECTION, (LPARAM)&cf); /// color added
	#endif
			SendMessage(_hwndEdit,EM_SETSEL,     (WPARAM)txtRepStart, (LPARAM)txtRepEnd+1);
			SendMessage(_hwndEdit,EM_REPLACESEL, (WPARAM)0,           (LPARAM)"");
		}
    }

#if 1 /* log file save */
	if( msgSaveOnOff )
	{
		if( fFileWrite && buff_fin )
		{
			fwrite(string2, sizeof(unsigned char), str2Pt, fFileWrite); 
	#if 1 /* 2012.07.07 fflush() ������� ����.... ��¹��۴� ��� ó���� �ȴ�... flclose() ��� ��� ���� */
			fflush(fFileWrite); /* 2012.07.07, fflush() �Լ��� ����� ���� �Է��� ��� ���� ���̰�	���� �� �����Ұ�.... */			
	#endif
		}
	}
#endif


    //If edit buffer is over EDIT_BUF_SIZE,
    //the size of buffer must be decreased by EDIT_BUF_DEC_SIZE.
    if(txtRepEnd>EDIT_BUF_SIZE)
    {
        lineIdx=SendMessage(_hwndEdit,EM_LINEFROMCHAR,EDIT_BUF_DEC_SIZE,0x0);
	//lineIdx=SendMessage(_hwndEdit,EM_LINEFROMCHAR,txtRepEnd-txtRepStart+1,0x0); //for debug
        txtSelEnd=SendMessage(_hwndEdit,EM_LINEINDEX,lineIdx,0x0)-1;
		SendMessage(_hwndEdit,EM_SETSEL,0,txtSelEnd+1);
	
		SendMessage(_hwndEdit,EM_REPLACESEL,0,(LPARAM)"");
		//SendMessage(_hwndEdit,WM_CLEAR,0,0); //WM_CLEAR doesn't work? Why?
		//SendMessage(_hwndEdit,WM_CUT,0,0); //WM_CUT doesn't work? Why?

		//make the end of the text shown.
		txtRepEnd=SendMessage(_hwndEdit,WM_GETTEXTLENGTH,0x0,0x0)-1;
		SendMessage(_hwndEdit,EM_SETSEL,txtRepEnd+1,txtRepEnd+2); 
		SendMessage(_hwndEdit,EM_REPLACESEL,0,(LPARAM)" ");
		SendMessage(_hwndEdit,EM_SETSEL,txtRepEnd+1,txtRepEnd+2); 
		SendMessage(_hwndEdit,EM_REPLACESEL,0,(LPARAM)"");
    }

    isUsed=0;
}

void ScrClear(HWND hwnd)
{
#ifdef RICHED_COLOR //////////////////////////////////////
	CHARFORMAT cf = {0};

	cf.cbSize = sizeof(CHARFORMAT);
	cf.dwMask = CFM_COLOR; /// CFM_FACE; /// CFM_BACKCOLOR; /// CFM_ALL2|CFM_COLOR; /// |CFM_BOLD;
	cf.dwEffects = CFE_BOLD;
	cf.crTextColor = COLOR_RED;
//	cf.yHeight = ;
//	cf.yOffset = ;
//	cf.bCharSet = ;
//	cf.bPitchAndFamily = ;
//	cf.szFaceName[LF_FACESIZE];

	SendMessage(_hwndEdit,EM_SETCHARFORMAT|EM_SETBKGNDCOLOR,SCF_SELECTION, (LPARAM)&cf); /// color added
#endif /* RICHED_COLOR */

    /// memset(string, 0x00, sizeof(TCHAR)*(STRING_LEN+4096) );
    /// memset( string2, 0x00, sizeof(string2) );

	SendMessage(_hwndEdit,EM_SETSEL,0,-1); 
	///SendMessage(_hwndEdit,WM_CLEAR, 0, 0);
	SendMessage(_hwndEdit,EM_REPLACESEL,0, (LPARAM)""); 
}





