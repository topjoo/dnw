#define STRICT
#define WIN32_LEAN_AND_MEAN

#include "resource.h"

#include <windows.h>
#include <windowsx.h>
#include <commctrl.h>
#include <tchar.h>
#include <string.h>
#include <process.h> /* For _beginthread() */
#include <stdlib.h>

#include "def.h"
#include "dnw.h"
#include "engine.h"
#include "fileopen.h"
#include "d_box.h"
#include "usbtxrx.h"
#include <stdio.h> /// added.
#include <memory.h> /// added.

//NOTE: _beginthread() 
// To use _beginenthread(),Activate "Project/Settings/C/C++/Categry/Code generation/
// Use Run-Time library/Multithreaded or Debug Multithreaded"

// If DDK2000 is used,
// 1. Project_Settings/CC++/Preprocessor/Additional_include_directories = C:\NTDDK\inc
// 2. Project_Settings/Link/Input/Additional_library_path=c:\NTDDK\libfre\i386

// If DDKXP is used,
// 1. Project_Settings/CC++/Preprocessor/Additional include directories = C:\WINDDK\2600\inc\w2k
// 2-1. Project_Settings/Link/Input/Additional_library_path=C:\WINDDK\2600\lib\w2k\i386
//      This causes some warning about '.rdata' section attribute.
// 2-2. Project_Settings/Link/Input/Additional_library_path==C:\WINDDK\2600\lib\i386\free
//      There's no warning.

/*
===================== REVISON HISTORY =====================
1. 2000. 3.30: V0.01 
  First release of DNW
2. 2000.10.11: V0.2
  The edit control is used for scroll, copy&paste, smooth screen update
3. 2001.1.26: V0.3
  a) The CPU usage will be less. Sleep() is inserted during TX.
  b) The filesize and checksum are transmitted together with bin file.
  c) WriteCommBlock() bug is fixed. The txEmpty flag should be changed in only DoRxTx().
4. 2001.2.24: V0.31
  a) The size of edit buffer is changed by EM_LIMITTEXT message.
     EDIT_BUF_SIZE(30000) -> MAX_EDIT_BUF_SIZE(65000)
  b) If the edit box is greater than 50000,
     the size of edit box is reduced by 10000.
  c) The horizontal scroll bar is removed for better look. 
  d) In WaitCommEvent() loop, 
     the following condition is inserted to clear the overrun condition.
    	if((dwEvtMask & EV_ERR){...}
  e) EB_Printf() have some error to process large string data.
5. 2001.3.8: V0.32
  a) EDIT_BUF_SIZE is reduced 25000 because the EM_REPLACESEL message is done very slowly
     if the size is over about 30000.
6. 2001.4.11: V0.32A
  a) Experimentally, MAX_EDIT_BUF_SIZE is set to the default value(32767). 
     //SendMessage(_hwndEdit, EM_SETLIMITTEXT, MAX_EDIT_BUF_SIZE, 0L);
     RESULT: MAX_EDIT_BUF_SIZE doesn't affect the display delay problem.
             I think that the new method for deleting the contents should be applied
	     Let's do tonight
7. 2001.5.14: V0.34
   a) I have known that the edit control isn't adequate for console program.
      So, I would give up the development of DNW using the edit control
      The last decision is as follows;
      MAX_EDIT_BUF_SIZE (65000) //up to 65535
      EDIT_BUF_SIZE (30000)   
      EDIT_BUF_DEC_SIZE (10000)
   b) If the selected text is deleted, the edit control displays the first of the text.
      In this case, to show the end of the text, dummy REPLACE_SEL is added.

8. 2001.11.23: V0.4
   a) USB download function is added.
   b) GetOverlappedResult() is used in TxFile() in order to save the cpu time more efficiently 
   c) Serial Configuration dialog box
   d) In secbulk.sys is changed to support IRP_MN_QUERY_CAPABILITIES.
      So, the surpriseRemoval is allowed. When the USB is yanked impolitely, 
      the warning dialog box won't appear in WIN2000.

9. 2001.11.24: v0.41alpha
   a) WriteFile() supports overlapped I/O to check broken pipe.
   b) progress bar is added for transmit operation.
   c) USB,serial status is printed on the window title bar
   
10. 2001.12.5: v0.42a
   a) In secbulk.sys, the maximum number of bulk packit in 1ms frame duration is changed to 16 from 4.
      So, transfer rate is increased from 220KB/S to 405KB/S 
   b) Although the fileopen was failed(or canceled), the transmit wasn't canceled. This is fixed.      
   c) When the options menu is selected, a serial port will be reconnected.
   d) The receive test menu is added. 

11. 2001.12.6: v0.43
   a) Fou USB tx operation, TX_SIZE is increased from 2KB to 16KB.
      So, transfer rate is increased from 405KB/S to 490KB/S.
      (2KB:405KB/S 4KB:450KB/S  8KB:470KB/S 16KB:490KB/S)

12. 2001.12.7: v0.44b
   a) Although a serial port is not connected, the serial port is connected 
      after Configuration/Options menu -> fixed.
   b) The name dnw.cfg for v 0.4x is changed to dnw.ini 
      in order not to confuse old dnw.cfg for ver 0.3x
      
12. 2002.01.2: v0.44c
   a) The edit box size is changed to display 80x25 characters 
      
13. 2002.02.22: v0.45
   a) In windows95, DNW doesn't search USB stack.
   b) When download, there should be a cancel button
   c) Sometimes, the progress bar is not filled although download is doing.
      I think it's because InitDownloadProgress() is executed 
      before than DownloadProgressProc().
      So, I inserted the code to wait until DownloadProgressProc() is executed as follows;
	  while(_hDlgDownloadProgress==0); //wait until the progress dialog box is ready.
   d) secbulk is optimized 
14. 2002.04.01: v0.46
   a) If DNW is start to transmit although the b/d is not ready, DNW will be hung.
      It's only solution to turn off and on the b/d.
      To solve this problem smoothly, the overlapped I/O will be used for USB transfer. 
      But, secbulk.sys may not support overlapped I/O. 
      Although I implemented the overlapped I/O, WriteFile() function didn't return before its completion.
   b) Because the overlapped I/O doens't work as my wish,
      and in order to quit the dnw.exe hung, modaless dialogue box is used for the progress bar.
   c) *.nb0

  15. 2002.04.10: v0.47
   a) I reduce the edit box size as follows;  
	#define MAX_EDIT_BUF_SIZE (0x7FFE) 
	#define EDIT_BUF_SIZE (0x6000)   
	#define EDIT_BUF_DEC_SIZE (0x1000)
      There is no good cause about why I change. I want to just reduce the edit box size.
   b) Sometimes, when transmit, there is no transmit although the transmit progrss dialog box is shown.
      I think that it's because the _enthread() fails.
      To debug this problem, the _enthread result is checked.

  16. 2002.04.19: v0.48
   a) The bug of WIN2K WINAPI is found. ->It's not fixed perfectly.
      Please let me know of the solution to avoid the memory problem of SetWindowText() API.

      The SetWindowText()(also,WM_SETTEXT message) consumes 4KB system memory every times.
      I think there is some bug in SetWindowText API.
      In my case, because SetWindowText() is called every 1 seconds, 
      the system memory used by DNW.exe is increased by 4KB every 1 seconds.
      For emergency fix, SetWindowText() will be called only when its content is changed.
      
      NOTE. This memory problem is not memory leakage problem 
            because the memory is flushed when the window is shrinked.

  17. 2002.05.03:v0.49
   a) Sometimes, when transmit, there is no transmit although the transmit progrss dialog box is shown.
      I have found the cause.
      It's because _hDlgDownloadProgress.
      If the TxFile thread is executed first than WM_INITDIALOG message,
      while(_hDlgDownloadProgress==NULL); will not exited because _hDlgDownloadProgress 
      in CPU register will be checked. So, the volatile should have been used 
      because _hDlgDownloadProgress value is changed in another thread.
      The solution is as follows;
      volatile HWND _hDlgDownloadProgress=NULL;
   b) Sometimes, the CPU usage will be always 100% if dnw.exe is being executed.
      This is because of the just above problem.
      If the problem 17-a) is occurred, the TxFile will be an obsolete thread.
      while(_hDlgDownloadProgress==NULL); will use the CPU at 100%.
      I think that this problem may be cleared because the problem 17-a) is cleared.
   c) The small icon,DNW is displayed in the window shell task bar and the window title.

  18. 2003.04.25:v0.50
   a) In case that a USB2Serial cable is used when COMPAQ Presario 1700, 
      a few last character display is postponed until the next group is received.
      -> MSDN recommends the while() for read operation, which has solved the problem.
   b) In DoRxTx(), the EV_ERR is added to SetCommMask(); -> which is more correct, I think.
   c) For overlapped WaitCommEvent,ReadFile,WriteFile, the return value should be checked.
      For ReadFile,WriteFile cases, the operation has no change.
      In previous version(V0.49), WaitCommEvent(,,NULL) should have not been used because OVERLAPPED I/O was being used.
      The combination of WaitCommEvent(,,&os) and GetOverlappedResult() will fix this problem.
   d) During developing the DNW v0.50, I had experienced some blue screen without any USB connection when I reset the SMDK2410.
      This problem was occurred when WaitCommEvent(,,&os) without GetOverlappedResult().
      This problem was not revived when is WaitCommEvent(,,NULL) although it's not correct. 
      
      From this phenomenon, I assume that the blue-screen, which is caused sometimes when resetting the SMDK2410, 
      may be caused by the mis-use of WaitCommEvent(,,NULL).

      But, it's still truth that the abnormal USBD response may cause the windows blue-screen
      ,which I experienced many times during my secbulk.sys development.
   
  19. 2003.04.29:v0.50A
   a) If the break condition is detected, "[DBG:EV_ERR]" message is displayed.
      So, the display of "[DBG:EV_ERR]" is removed.
*/

/*   
Items to be enhanced.
   - avoid SetWindowText() API problem.
   - remove debug stuff in following functions.
         void InitDownloadProgress(void);   
	 void DisplayDownloadProgress(int percent);
   - make status bar.
   - malloc() uses too much memory for large file transfer.
   - Enlarge the scroll buffer -> the edit box is not adequate.
   - file logging function
   - Ctrl+C should be work as copy function.
*/ 

/*
Edit Box Note:
- Check if the edit box is scrolled to show the text being deleted
  when the selected text is deleted in Win2000. In windows98, It's scrolled to show the deleted portion unfortunately.
*/

#define IS_OVERLAPPED_IO    (TRUE)
#define IS_OVERLAPPED_CHECK 		1 /// 2014.03.04, if Long Time, disconneted UART...
#define IS_OVERLAPPED_WAIT 			(30*1000) /// 30sec  <-- INFINITE


int userBaudRate,idBaudRate, autoSendKey, msgSaveOnOff=0, msgMode=0, localTime=0;
int userComPort;
int TotalROMfilenum, UmonFileNum=0;
int TotalRAMfils;
int FontType;
#ifdef ENGINEER_MODE /// �����ڿ��� �ʿ����.
int RetryUSB = 0; /// defauilt
#else
int RetryUSB = 1; /// 20 times
#endif

#ifdef COM_SETTINGS /// 2012.07.11
int userCOMparity=0, userCOMstop=0, userCOMdataIdx=1;
const int COMportDatabit[] = { 
	7,  /// index 0 : 7bit 
	8   /// index 1 : 8bit
};
#endif

#if defined(COLOR_DISP2) /// 2010.05.14
int ColorType=0;
#endif

int CPUtype=1; /// 6410:0, SMDKC100:1


#define MAX_BLOCK_SIZE (4096)

HANDLE idComDev = NULL;
OVERLAPPED osWrite, osRead;
volatile int isConnected=0; /// FALSE;
TCHAR rxBuf[MAX_BLOCK_SIZE+20] = {0,};
int index_rxBuf = 0; /// 2014.06.24

volatile char *SerialTxBuf = NULL;
volatile DWORD idxTxBuf = 0;
DWORD TxBufSize;
TCHAR Date_Time[20] = {0,}; /// 2013.04.09

volatile BOOL txEmpty=TRUE; /* int -> BOOL */

extern TCHAR szDownloadAddress[ADDR_LENGTH];
extern TCHAR szColumnNumber[16];

extern DWORD ColumnNumber;

extern HWND _EditHwnd, _MainHwnd; /// added.
extern WORD  DownloadedBin; /// added.
extern int 	 BinFileIndex;
DWORD  mpCount = 0;
extern char *os_name(void);
extern void GetComPortRegistry(void);

void MenuAbout(HWND hwnd)
{
	EB_Printf(TEXT("[dnw] --------------------------------------------------- \n") );
	EB_Printf(TEXT("[dnw] %s \n"), os_name() );
	EB_Printf(TEXT("[dnw] %s [Build:%s_%s] \n"), APPNAME, __DATE__ , __TIME__ );
	EB_Printf(TEXT("[dnw] --------------------------------------------------- \n") );

	GetComPortRegistry();

#if 0
	EB_Printf(TEXT("\r\n") );
	EB_Printf(TEXT("[dnw] ---------------------------------------------------------------------------------------- \n") );
	EB_Printf(TEXT("[dnw] << dnw updated history >> \n") );
	EB_Printf(TEXT("[dnw] 1) v1.70E - 2012.07.09 \n") );
	EB_Printf(TEXT("[dnw]   - Improved Log file saving function. added flushing fucntion. \n") );
	EB_Printf(TEXT("[dnw]     (log file example, .\\dnwlog\\dnw_2012Jul07_091610.txt) - YYYYMmmDD_hhmmss \n"));
	EB_Printf(TEXT("[dnw]   - [F10] -> views connectable COM port lists. \n") );
	EB_Printf(TEXT("[dnw] ---------------------------------------------------------------------------------------- \n") );

#endif
	


//	if( GetAsyncKeyState(VK_F1) & 0x8000 )
//		EB_Printf(TEXT("[dnw] --------------------------------------------------- \n") );
		
#if 0
    MessageBox(hwnd,TEXT("Serial Console with Serial/USB Download\n\n")
		    TEXT("1. e-mail: mobilesol.cs@samsung.com\n")
	  	    TEXT("2. USB Tx format: addr(4)+size(4)+data(n)+cs(2)   \n")
		    TEXT("3. Serial Tx format: size(4)+data(n)+cs(2)\n\n")
		    TEXT("For WinCE Version, WinCE 5.0, WinCE 6.0, \n")
			TEXT("Windows Mobile 5.0, Windows Mobile 6.0 UBOOT is supported\n"),
			TEXT("About ")APPNAME TEXT(" @Build:")__DATE__ , MB_OK | MB_ICONINFORMATION );
#endif
}




int GetIsConnect(void)
{
	return isConnected;
}

void Quit(HWND hwnd)
{
    CloseComPort();
}


BOOL MenuConnect(HWND hwnd)
{
	BOOL 	retVal = FALSE;

	if( 1 == isConnected ) /// TRUE
	{
		CloseComPort();
	}

#ifdef SERIAL_CONNECTING_DISPLAY /// 2012.07.05, connecting 
	isConnected = 2; /// Try to connecting
	UpdateWindowTitle();
#endif
	retVal = OpenComPort(userComPort);
	if( FALSE == retVal )
	{
#ifndef SERIAL_CONNECTING_DISPLAY /// 2012.07.05, connecting 
		EB_Printf(TEXT("[dnw] can not connect COM%d port in MenuConnect. (L:%d, V:%d) \n"), userComPort, __LINE__ , isConnected );
#endif

		if(1==isConnected) /// TRUE
		{
			CloseComPort();
		}
#ifdef SERIAL_CONNECTING_DISPLAY /// 2012.07.05, connecting 
		isConnected = 2; /// Try to connecting
		UpdateWindowTitle();
#endif
		Sleep(10);
		retVal = OpenComPort(userComPort);
		if( FALSE == retVal )
		{
			UpdateWindowTitle();
		}
	}
	return retVal;


}


void MenuDisconnect(HWND hwnd)
{
	if( 1==isConnected ) /// TRUE
	{
		CloseComPort();
	}
}


/* F2 */
BOOL MenuConnectDisconnect(HWND hwnd)
{
	BOOL 	retVal = TRUE;

	if(1 == isConnected) /// TRUE
	{
		CloseComPort();
		retVal = TRUE;
		return TRUE;
	}
	else if( 0==isConnected ) /// || 2==isConnected ) /// FALSE
	{
#ifdef SERIAL_CONNECTING_DISPLAY /// 2012.07.05, connecting 
		isConnected = 2; /// Try to connecting
		UpdateWindowTitle();
#endif
		retVal = OpenComPort(userComPort);
		if( TRUE == retVal )
		{
			UpdateWindowTitle();
		}
		else if( FALSE==retVal )
		{
#ifdef SERIAL_CONNECTING_DISPLAY /// 2012.07.05, connecting 
			isConnected = 2; /// Try to connecting
			UpdateWindowTitle();
#endif
			Sleep(50);
			retVal = OpenComPort(userComPort);
			if( TRUE == retVal )
			{
				UpdateWindowTitle();
			}
			else if( FALSE == retVal )
			{
#ifndef SERIAL_CONNECTING_DISPLAY /// 2012.07.05, connecting 
				DWORD dwError = GetLastError();
				EB_Printf(TEXT("[dnw] can not connect COM%d port in MenuConnectDisconnect. (L:%d, V:%d, Err=%u) \n"), userComPort, __LINE__ , isConnected, dwError );
#endif
			}
		}
	}
	return retVal;
}


/* 1000 msec ���� checking & Title update */
void UpdateWindowTitle(void)
{
    TCHAR title[FILENAMELEN] = {0,};
    TCHAR tch[32] = {0,};
    
    static int prevComPort=0xff;
    static int prevBaudRate=0xff;
    static int prevUsbAlive=0xff;
    static int prevIsConnected=0xff;
	static int prevautoSendKey=0xff; /// added.
	static int prevmsgSaveOnOff=0xff; /// 2011.12.05
	static TCHAR prevDownAddr[16] = {0,};
    int usbAlive=0;
	static int prevuserCOMparity=0xff, prevuserCOMstop=0xff, prevuserCOMdata=0xff, prevLocalTime=0xff;
	static int prevCPUtype=0xff;




	///////////////// USB port : One more /////////////////
	if(IsUsbConnected())
	{
		///lstrcat(title,TEXT(" [USB:OK]"));
		usbAlive=1;
	}
	else
	{
		///lstrcat(title,TEXT(" [USB:x]"));
		usbAlive=0;
	}


	
    if(userComPort!=prevComPort || userBaudRate!=prevBaudRate || usbAlive!=prevUsbAlive 
		|| isConnected!=prevIsConnected 
		|| !lstrcmp(prevDownAddr,szDownloadAddress) 
		|| autoSendKey !=prevautoSendKey || msgSaveOnOff != prevmsgSaveOnOff
		|| userCOMparity != prevuserCOMparity
		|| userCOMstop != prevuserCOMstop
		|| userCOMdataIdx != prevuserCOMdata
		|| CPUtype != prevCPUtype /// 2014.04.11
      )
    {

#if 1 /* ������ �̵� .... */

		///////////// COM port ////////////
		lstrcpy(title,APPNAME);
		lstrcat(title,TEXT("  [COM"));
	
		if(1 == isConnected ) // TRUE, serial connected : O.K.
		{

			if(userComPort<10)
			{
				tch[0]='0'+userComPort;
				tch[1]='\0';
			}
			else
			{	/* : ; < = > ? @ */
				tch[0]='0'+(userComPort/10);
				tch[1]='0'+(userComPort%10);
				tch[2]='\0';
			}

			lstrcat(title,tch);
			lstrcat(title,TEXT(","));
			lstrcat(title,_itot(userBaudRate,tch,10) );   //_itot :TCHAR version of itoa 
			lstrcat(title,TEXT("bps-"));
	#ifdef COM_SETTINGS /// 2012.07.11
			switch(userCOMparity)
			{
				case 0: /// NOPARITY
					lstrcat(title,TEXT("N:"));
					break;				
				case 1: /// ODDPARITY
					lstrcat(title,TEXT("O:"));
					break;				
				case 2: /// EVENPARITY
					lstrcat(title,TEXT("E:"));
					break;				
				case 3: /// MARKPARITY
					lstrcat(title,TEXT("M:"));
					break;				
				case 4: /// SPACEPARITY
					lstrcat(title,TEXT("S:"));
					break;				
				default: /// SPACEPARITY
					lstrcat(title,TEXT("*:"));
					break;				
			}
			

			memset( tch, 0x00, sizeof(tch) );
			tch[0]='0'+ COMportDatabit[userCOMdataIdx];
			tch[1]='\0';
			lstrcat(title,tch);

			switch(userCOMstop)
			{
				 case 0: /// ONESTOPBIT
					 lstrcat(title,TEXT(":1S]"));
					 break; 			 
				 case 1: /// ONE5STOPBITS
					 lstrcat(title,TEXT(":1.5S]"));
					 break; 			 
				 case 2: /// TWOSTOPBITS
					 lstrcat(title,TEXT(":2S]"));
					 break; 			 
				 default: /// TWOSTOPBITS
					 lstrcat(title,TEXT(":**]"));
					 break; 			 
			}
	#endif /////////////////////////////////////// 
			
		}
	#ifdef SERIAL_CONNECTING_DISPLAY /// 2012.07.05, connecting 
		else if(2 == isConnected)
		{
			if(userComPort<10)
			{
				tch[0]='0'+userComPort;
				tch[1]='\0';
			}
			else
			{	/* : ; < = > ? @ */
				tch[0]='0'+(userComPort/10);
				tch[1]='0'+(userComPort%10);
				tch[2]='\0';
			}
	
			lstrcat(title,tch);
			lstrcat(title,TEXT(" -> connecting...]"));
		}
	#endif
		else
		{
			lstrcat(title,TEXT(":x]"));
		}


		///////////////// USB port : One more /////////////////
		if(IsUsbConnected())
		{
			lstrcat(title,TEXT(" [USB:OK]"));
			usbAlive=1;
		}
		else
		{
			lstrcat(title,TEXT(" [USB:x]"));
			usbAlive=0;
		}

		////////////// RAM address ///////////////////
		lstrcat(title,TEXT(" [Addr:"));
		lstrcat(title,szDownloadAddress );	 //_itot :TCHAR version of itoa 
		lstrcat(title,TEXT("]"));
	
		//The bug of WIN2K WINAPI is found.
		//The SetWindowText()(also,WM_SETTEXT message) consumes 4KB system memory every times.
		//I think there is some bug in SetWindowText API.
		//In my case, because SetWindowText() is called every 1 seconds, 
		//the system memory used by DNW.exe is increased by 4KB every 1 seconds.
		//For emergency fix, SetWindowText will called only when its content is changed.
		//NOTE. This memory leakage is flushed when window is shrinked.
	
		//////////// automatic flag ////////////////
		if( autoSendKey )
			lstrcat(title,TEXT("-[AutoSend]"));
	
		if( msgSaveOnOff )
			lstrcat(title,TEXT("-[Logging]"));
	
	#ifdef HEXA_MODE_SUPPORT	/* 2011.02.08 Hexa mode display */
		if(1==msgMode)
		{
			lstrcat(title,TEXT("-[Hexa"));
			if(!ColumnNumber)
			{
				lstrcat(title,TEXT("]"));
			}
			else
			{
				memset( tch, 0x00, sizeof(tch) );
				lstrcat(title,TEXT("("));
				lstrcat(title,_itot(ColumnNumber,tch,10) );   //_itot :TCHAR version of itoa 
				lstrcat(title,TEXT(")]"));
			}
		}
	#endif

#endif


		SetWindowText(_hwnd, title);



	    prevComPort       = userComPort;
	    prevBaudRate      = userBaudRate;
	    prevUsbAlive      = usbAlive;
	    prevIsConnected   = isConnected;
		lstrcpy(prevDownAddr, szDownloadAddress);  /* strcpy() -> lstrcpy() */
		prevautoSendKey   = autoSendKey; /// added.
		prevmsgSaveOnOff  = msgSaveOnOff; /// 2011.12.05

		prevuserCOMparity = userCOMparity;
		prevuserCOMstop   = userCOMstop;
		prevuserCOMdata   = userCOMdataIdx;
		prevLocalTime     = localTime;
		prevCPUtype       = CPUtype;

    }

}



void MenuTransmit(HWND hwnd)
{
    HANDLE hFile = NULL;
    DWORD fileSize;
    unsigned short cs=0;
    DWORD i;
    BOOL result;
    unsigned long threadResult;
	BOOL rdRet;

	if(!isConnected)
	{
		EB_Printf(TEXT("[dnw] can not open COM%d port in MenuTransmit. Not connected! (L:%d, V:%d) \n"), userComPort, __LINE__, isConnected );
		return;
	}
	result=PopFileOpenDlg(hwnd,szFileName,szTitleName);
    
	if( 0 == result ) //file open fail
	{
		DWORD dwError = GetLastError();
		EB_Printf(TEXT("[dnw] can not open PopFileOpenDlg! (File:%s,%s, L:%d, Err=%u) \n"), szFileName, szTitleName, __LINE__ , dwError );
		return;
	}

    hFile=CreateFile(szFileName,GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,0,NULL);

    if( INVALID_HANDLE_VALUE==hFile || NULL==hFile )
    {
		DWORD dwError = GetLastError();
		EB_Printf(TEXT("[dnw] can not create File. (File:%s, L:%d, Error=%u) \n"), szFileName, __LINE__ , dwError );
		return;
    }
    
    fileSize=GetFileSize(hFile,NULL);

	if(SerialTxBuf) { free((void*)SerialTxBuf); SerialTxBuf=NULL; } /// 2010.5.12 added

    SerialTxBuf=(char *)malloc(fileSize+6);
    if( NULL==SerialTxBuf )
    {
		DWORD dwError = GetLastError();
		EB_Printf(TEXT("[dnw] can not allocate the serial Tx buffer memory. (Size:%d, L:%d, Error=%u) \n"), fileSize+6,  __LINE__ , dwError  );
		if(hFile) { CloseHandle(hFile); hFile=NULL; } /// added.
		return;
    }

    rdRet = ReadFile(hFile,(void *)(SerialTxBuf+4),fileSize,&TxBufSize,NULL);
    if( (TxBufSize!=fileSize) || !rdRet )
    {
    	if( !rdRet )
    	{
			DWORD dwError = GetLastError();
			EB_Printf(TEXT("[dnw] find some error while ReadFile. (rdRet:%d, L:%d, Error=%u) \n"), rdRet,  __LINE__ , dwError );
    	}
		else
		{
			EB_Printf(TEXT("[dnw] find some error while ReadFile. (Size:%d, L:%d) \n"), fileSize,  __LINE__ );
		}
		
		if(hFile) { CloseHandle(hFile); hFile=NULL; } /// added.
		if(SerialTxBuf) { free((void*)SerialTxBuf); SerialTxBuf=NULL; } /// 2010.5.12 added
		return;
    }

    *((DWORD *)SerialTxBuf)=fileSize+6;   //attach filesize(n+6) 

    for(i=4;i<(fileSize+4);i++)
		cs+=(BYTE)(SerialTxBuf[i]);
    *((WORD *)(SerialTxBuf+4+fileSize))=cs;   //attach checksum 
    
    TxBufSize+=6;
    idxTxBuf=0;

    if(hFile) { CloseHandle(hFile);  hFile=NULL; }

    //EB_Printf(TEXT("[dnw] cs=%x\n"),cs);
    threadResult = _beginthread( (void (*)(void *))TxFile,  /* void( __cdecl *start_addr)(void*) */
    							THREAD_STACK_SIZE,         /* stack size */
    							(void *)NULL               /* arglist */
    						  );
    if( -1 != threadResult )
    {
		Sleep(10); // 2013.03.25,  /// 2012.02.20, update.....	2011.12.05
		
		//Create the download progress dialogbox.
		CreateDialog(_hInstance,MAKEINTRESOURCE(IDD_DIALOG1),hwnd,DownloadProgressProc); //modaless
		//ShowWindow(_hDlgDownloadProgress,SW_SHOW); 
		//isn't needed because the dialog box already has WS_VISIBLE attribute.
    }
    else
    {
		DWORD dwError = GetLastError();
		if(hFile) { CloseHandle(hFile); hFile=NULL; } /// 2012.07.07 added.
		if(SerialTxBuf) { free((void*)SerialTxBuf); SerialTxBuf=NULL; } /// 2012.7.7 added
		EB_Printf(TEXT("[dnw] can not create TxFile beginthread becuase memory is not sufficient (L:%d, Error=%u) \n"), __LINE__, dwError );
    }
    //The dialog box will be closed at the end of TxFile().
    //free(SerialTxBuf) & CloseHandle(hWrite) will be done in TxFile()
}



void MenuOptions(HWND hwnd)
{
    int result;
    //Create the download progress dialogbox.
    result=DialogBox(_hInstance,MAKEINTRESOURCE(IDD_DIALOG2),_hwnd,OptionsProc); //modal
    if( 1 == result ) /// && isConnected==1)
    {
		MenuConnect(hwnd); //reconfig the serial port.
    }
	else
	{
		/// Cancel or ESC 
	}
}


void SerialTimeOut(void)  /// added.
{
	COMMTIMEOUTS commTimeOuts;

	commTimeOuts.ReadIntervalTimeout         = MAXDWORD;
	commTimeOuts.ReadTotalTimeoutMultiplier  = 0;
	commTimeOuts.ReadTotalTimeoutConstant    = 0; /* msec */
	commTimeOuts.WriteTotalTimeoutMultiplier = 0;
	commTimeOuts.WriteTotalTimeoutConstant   = 0;
	SetCommTimeouts(idComDev,&commTimeOuts); /* ������ ��� ����̽��� �б⾲�� Ÿ�Ӿƿ� ���� */				
}


/*****************************
 *                           *
 * serial communication part *
 *                           *
 *****************************/
BOOL OpenComPort(int port)
{
const  TCHAR *textCom[]= { 
		TEXT("COM0"),TEXT("COM1"),TEXT("COM2"),TEXT("COM3"),TEXT("COM4"),TEXT("COM5"),
		TEXT("COM6"),TEXT("COM7"),TEXT("COM8"),TEXT("COM9"), TEXT("\\\\.\\COM10"),
		TEXT("\\\\.\\COM11"),TEXT("\\\\.\\COM12"),TEXT("\\\\.\\COM13"),TEXT("\\\\.\\COM14"),TEXT("\\\\.\\COM15"),
		TEXT("\\\\.\\COM16"),TEXT("\\\\.\\COM17"),TEXT("\\\\.\\COM18"),TEXT("\\\\.\\COM19"),TEXT("\\\\.\\COM20"),
		TEXT("\\\\.\\COM21"),TEXT("\\\\.\\COM22"),TEXT("\\\\.\\COM23"),TEXT("\\\\.\\COM24"),TEXT("\\\\.\\COM25"),
		TEXT("\\\\.\\COM26"),TEXT("\\\\.\\COM27"),TEXT("\\\\.\\COM28"),TEXT("\\\\.\\COM29"),TEXT("\\\\.\\COM30"),
		TEXT("\\\\.\\COM31"),TEXT("\\\\.\\COM32"),TEXT("\\\\.\\COM33"),TEXT("\\\\.\\COM34"),TEXT("\\\\.\\COM35"),
		TEXT("\\\\.\\COM36"),TEXT("\\\\.\\COM37"),TEXT("\\\\.\\COM38") 
	};



	/* COMM device�� ���� �������� �����Ѵ�.
	   nPort Number >=10 and then,   szPort.Format("\\\\.\\COM%d", nPort);
	*/
	DCB dcb;
	COMMTIMEOUTS commTimeOuts;
	unsigned long tThread;
	COMSTAT comStat; /// 2011.1.29 added.
	DWORD dwErrorFlags; /// 2011.1.29 added.
	int  retry_cnt = 0;


	memset(&comStat, 0x00, sizeof(COMSTAT) ); /// 2014.1.4

	//====================================================
	isConnected = 2; /// Try to connecting....................... /// FALSE; /// 2012.02.20 added. disconnect!!!!!!!!
	//====================================================


	if( idComDev ) { CloseHandle(idComDev); idComDev=NULL; }
	if( osRead.hEvent ) { CloseHandle(osRead.hEvent); osRead.hEvent=NULL; }
	if( osWrite.hEvent ) { CloseHandle(osWrite.hEvent); osWrite.hEvent=NULL; }


    memset( &osRead, 0x00,sizeof(OVERLAPPED) ); /// 2014.3.5, added
    memset( &osWrite, 0x00,sizeof(OVERLAPPED) ); /// 2014.3.5, added

    osRead.Offset      = 0;
    osRead.OffsetHigh  = 0;
    osRead.hEvent      = NULL;
    osWrite.Offset     = 0;
    osWrite.OffsetHigh = 0;
    osWrite.hEvent     = NULL;


    osRead.hEvent = CreateEvent(NULL,TRUE/*bManualReset*/,FALSE,NULL);
     //manual reset event object should be used. 
     //So, system can make the event objecte nonsignalled.
     //osRead.hEvent & osWrite.hEvent may be used to check the completion of 
     // WriteFile() & ReadFile(). But, the DNW doesn't use this feature.
    if( (INVALID_HANDLE_VALUE==osRead.hEvent ) || (NULL==osRead.hEvent) )
    {
		DWORD dwError = GetLastError();
		EB_Printf(TEXT("[dnw] can not create osRead Event. (L:%d, Error=%u) \n"), __LINE__, dwError );
		isConnected = 0; /// 2012.07.04
		if( osRead.hEvent ) CloseHandle(osRead.hEvent); /// added.
		if( osWrite.hEvent ) CloseHandle(osWrite.hEvent); /// 2014.3.5, added.
		return FALSE;
    }

    osWrite.hEvent = CreateEvent(NULL,TRUE,FALSE,NULL);
    if( (INVALID_HANDLE_VALUE==osWrite.hEvent) || (NULL==osWrite.hEvent) )
    {
		DWORD dwError = GetLastError();
		EB_Printf(TEXT("[dnw] can not create osWrite Event. (L:%d, Error=%u) \n"), __LINE__ , dwError );
		isConnected = 0; /// 2012.07.04
		if( osRead.hEvent ) CloseHandle(osRead.hEvent); /// added.
		if( osWrite.hEvent ) CloseHandle(osWrite.hEvent); /// 2014.3.5, added.
		return FALSE;
    }

    
//====================================================
//====  Open COM port
//====================================================
	retry_cnt = 0;
	do {
	    idComDev=CreateFile(textCom[port /*-1*/],
							GENERIC_READ|GENERIC_WRITE,
							0, //exclusive access
							/*FILE_SHARE_READ|FILE_SHARE_WRITE,*/ 
							NULL, /* no security attrs  */
							OPEN_EXISTING,
		    #if IS_OVERLAPPED_IO
							FILE_FLAG_OVERLAPPED, /* 2014.03.04, |FILE_ATTRIBUTE_NORMAL */
		    #else
							/*FILE_ATTRIBUTE_NORMAL,*/ 0,
		    #endif	
							NULL);
		if(retry_cnt ++ > 3) break;
		if(INVALID_HANDLE_VALUE==idComDev || NULL==idComDev ) Sleep(50);
	} while( (INVALID_HANDLE_VALUE==idComDev) || (NULL==idComDev) );


    if( (INVALID_HANDLE_VALUE==idComDev) || (NULL==idComDev) )
    {
		/// EB_Printf(TEXT("[dnw] can not open COM Port. Retry it... (L:%d) \n") , __LINE__ );
		CloseComPort();
		isConnected = 0; /// 2012.07.04
		return FALSE;
    }

    if( FALSE == SetupComm(idComDev, MAX_BLOCK_SIZE, MAX_BLOCK_SIZE) ) /* input, output buffer size : 4096 */
    {
		DWORD dwError = GetLastError();
	    EB_Printf(TEXT("[dnw] can not set SetupComm COM%d port. (L:%d, Error=%u)\n"), userComPort, __LINE__, dwError  );
		///CloseComPort();
		///isConnected = 0; /// 2012.07.04
		///return FALSE;
	}

	ClearCommError(idComDev, &dwErrorFlags, &comStat); /// 2012.07.04

    if( FALSE == PurgeComm(idComDev,PURGE_TXABORT|PURGE_RXABORT|PURGE_TXCLEAR|PURGE_RXCLEAR) )
    {
    	DWORD dwError = GetLastError();
	    EB_Printf(TEXT("[dnw222] can not set PurgeComm COM%d port. (L:%d, Error=%u)\n"), userComPort, __LINE__, dwError );
		///CloseComPort();
		///isConnected = 0; /// 2012.07.04
		///return FALSE;
	}

	memset( &commTimeOuts, 0x00, sizeof(COMMTIMEOUTS) ); /// OK -> initial
	if( FALSE == GetCommTimeouts (idComDev, &commTimeOuts) )
	{
		DWORD dwError = GetLastError();
	    EB_Printf(TEXT("[dnw] GetCommTimeouts COM%d port. (L:%d, Error=%u)\n"), userComPort, __LINE__, dwError  );
	}
	else
	{
	#if 0
	    EB_Printf(TEXT("[dnw] ReadIntervalTimeout         : 0x%X\n" 
			           "      ReadTotalTimeoutMultiplier  : %u\n"
			           "      ReadTotalTimeoutConstant    : %u\n" 
			           "      WriteTotalTimeoutMultiplier : %u\n" 
			           "      WriteTotalTimeoutConstant   : %u\n"),
								commTimeOuts.ReadIntervalTimeout,
								commTimeOuts.ReadTotalTimeoutMultiplier,
								commTimeOuts.ReadTotalTimeoutConstant,
								commTimeOuts.WriteTotalTimeoutMultiplier,
								commTimeOuts.WriteTotalTimeoutConstant );
	#endif
	}


	// set up for overlapped I/O
	// CBR_9600 is approximately 1byte/ms. 
	// For our purposes, allow double the expected time per character for a fudge factor.
    commTimeOuts.ReadIntervalTimeout         = MAXDWORD; /* msec  MAXDWORD */
    commTimeOuts.ReadTotalTimeoutMultiplier  = 0;
    commTimeOuts.ReadTotalTimeoutConstant    = 0; /// 1000; /* msec */
    commTimeOuts.WriteTotalTimeoutMultiplier = 0;
    commTimeOuts.WriteTotalTimeoutConstant   = 0; /// 1000; /* msec */
    if( !SetCommTimeouts(idComDev,&commTimeOuts) ) /* ������ ��� ����̽��� �б⾲�� Ÿ�Ӿƿ� ���� */
    {
		DWORD dwError = GetLastError();
	    EB_Printf(TEXT("[dnw] can not set COM%d Port Timeout. Retry it!! (L:%d, Error=%u)\n"), userComPort, __LINE__, dwError );
		ClearCommError(idComDev,&dwErrorFlags,&comStat); /// added 2011.1.29
		PurgeComm(idComDev,PURGE_TXABORT|PURGE_RXABORT|PURGE_TXCLEAR|PURGE_RXCLEAR); /// added. 2012.02.17
		isConnected = 0; /// 2012.07.04

		if( osRead.hEvent ) CloseHandle(osRead.hEvent); /// 2014.3.5, added.
		if( osWrite.hEvent ) CloseHandle(osWrite.hEvent); /// 2014.3.5, added.
    	return FALSE;
    }


//====================================================
	memset(&dcb,0,sizeof(DCB)); /// 2012.07.04
    GetCommState(idComDev,&dcb);  /* ������ ��� ����̽��� ���� DCB ���� ��� */

    dcb.DCBlength         = sizeof(DCB);
    dcb.fBinary           = TRUE;                /* Binary mode,  EOF üũ ���� */
    dcb.fParity           = NOPARITY;            /* Parity bit ��� ���� */
	
#ifdef COM_SETTINGS /// 2012.07.11
    dcb.fParity           = userCOMparity;
#endif
	
	/* ---------------------------
            0 : NOPARITY
            1 : ODDPARITY
            2 : EVENPARITY
            3 : MARKPARITY
            4: SPACEPARITY
	------------------------------ */ 
    dcb.BaudRate          = userBaudRate;        /* 115200; ��� �ӵ� */
    dcb.ByteSize          = 8;                   /* 8: 8Bit, 7: 7Bit, 6:6Bit, 5:5Bit : 1����Ʈ�� ��Ʈ�� */
#ifdef COM_SETTINGS /// 2012.07.11
	dcb.ByteSize		  = COMportDatabit[userCOMdataIdx];
#endif /// 


    dcb.Parity            = 0;                   /* �и�Ƽ�� ���� , NOPARITY , EVENPARITY, ODDPARITY */
    dcb.StopBits          = 0;                   /* ��ž��Ʈ�� 0,1,2�� ����1,1.5,2�� �ǹ� */
#ifdef COM_SETTINGS /// 2012.07.11
	dcb.StopBits		  = userCOMstop;
#endif
     /* ---------------------------
            0 : ONESTOPBIT (1 stop bit)
            1 : ONE5STOPBITS (1.5 stop bits.)
            2 : TWOSTOPBITS (2 stop bit)
	------------------------------ */ 
												 
    dcb.fOutxCtsFlow      = FALSE;               /* CTS ��� �帧���� ��� ����. fOutxCtsFlow  �۽� �帧 ��� ���Ͽ� CTS��ȣ�� �ֽ��� ���� �����Ѵ� */
	                                             /* �� �׸��� TRUE�̰� CTS�� �����̸� ������ �� ������ �۽��� �����ȴ�. */

	dcb.fDtrControl	      = DTR_CONTROL_DISABLE; /* DTR �帧���� ���� , RTS_CONTROL_ENABLE */
	dcb.fRtsControl	      = RTS_CONTROL_DISABLE; /* RTS �帧���� , DTR_CONTROL_ENABLE */
    dcb.fOutxDsrFlow      = FALSE;               /* DSR ��� �帧���� ��� ����. fOutxDsrFlow  �۽� �帧 ��� ���Ͽ� DSR (data-set-ready) ��ȣ�� �ֽ��� ���� �����Ѵ�.  */
												 /* �� �׸��� TRUE�̰� DSR�� ������ �� �� ������ �� ������ �۽��� �����ȴ� */

	dcb.fOutX             = FALSE; 			  /* XON/XOFF ��� �帧���� ��� ���� */
	dcb.fInX              = FALSE; 			  /* XON/XOFF �Է� �帧���� ��� ���� */

#if _NOT_USED__
	if (m_bFlowChk) {
		dcb.fOutX         = FALSE;
		dcb.fInX          = FALSE;
		dcb.XonLim        = 2048;
		dcb.XoffLim       = 1024;
	}
	else {
		dcb.fOutxCtsFlow = TRUE;
		dcb.fRtsControl  = RTS_CONTROL_HANDSHAKE;
	}
#endif


	dcb.fDsrSensitivity   = FALSE;               /* DSR ���� */
	dcb.fTXContinueOnXoff = TRUE;                /* XOFF continues Tx  */
	dcb.fErrorChar        = FALSE;               /* Disable error replacement  */
	dcb.fNull             = FALSE;               /* Disable null stripping  */
	dcb.fAbortOnError     = TRUE;                /* ���� ����. ������ �߻��ϸ� �б�� ���� �۾��� ����� ���ΰ��� ���Ѵ�.  */
	                                             /* �� �׸��� TRUE�̸� ����(ERROR_IO_ABORTED)�� �߻��� ���� �� ������ �б�� ���� �۾��� �����ϰ� ���� ���¿� �Բ� ����ȴ�.  */
												 /* �������α׷����� ClearCommError() �� ������ �߻��� ��Ȳ�� �˾�ç �� ���� ��� ��� �۾��� �����Ѵ�  */




    /* --- �ϵ����� ���� ���� �ʱ�ȭ --- */
    if( TRUE == SetCommState(idComDev,&dcb) )
    {
		SetCommMask(idComDev, EV_RXCHAR ); /// 2012.07.04

		tThread = _beginthread( (void (*)(void *))DoRxTx, THREAD_STACK_SIZE,(void *)0);

		if( -1 == tThread )
		{
			/// error
			DWORD dwError = GetLastError();
			EB_Printf(TEXT("[dnw] can not create DoRxTx beginthread. (tThread=%d, L:%d, Error=%u)\n"), tThread, __LINE__ , dwError );
			///Sleep(10); /// added. 2011.1.29
			ClearCommError(idComDev,&dwErrorFlags,&comStat); /// added 2011.1.29
			PurgeComm(idComDev,PURGE_TXABORT|PURGE_RXABORT|PURGE_TXCLEAR|PURGE_RXCLEAR); /// added. 2012.02.17
			CloseComPort();
			isConnected=0; /// FALSE;
			return FALSE; /// 2012.02.17
		}
		isConnected=1; /// 1 : connected!!!!! TRUE;
		return TRUE;
    }
    else
    {
		DWORD dwError = GetLastError();
		EB_Printf(TEXT("[dnw] can not set COM%d port state. (L:%d, Error=%u)\n"), userComPort, __LINE__ , dwError );
		
		ClearCommError(idComDev,&dwErrorFlags,&comStat); /// added 2011.1.29
		/// 2013.12.26, PurgeComm(idComDev,PURGE_TXABORT|PURGE_RXABORT|PURGE_TXCLEAR|PURGE_RXCLEAR); /// added. 2012.02.17
		CloseComPort(); /// 2011.1.29 added
		isConnected=0;///FALSE;
		return FALSE;
    }
	return FALSE;
}



void CloseComPort(void)
{
	SerialTimeOut(); /// 2010.05.20 added.
	///Sleep(50); /// 2011.1.27
	DWORD dwErrorFlags;
	
	if( 1==isConnected ) /// 2013.04.12 deleted,.... bug fix || (2==isConnected) )
	{
		isConnected=0; /// FALSE;
		if(osRead.hEvent) CloseHandle(osRead.hEvent);
		if(osWrite.hEvent) CloseHandle(osWrite.hEvent);
		if(idComDev) { CloseHandle(idComDev); idComDev=NULL; }

		ClearCommError(idComDev, &dwErrorFlags, NULL); /// 2012.07.04

		SetCommMask(idComDev, 0);
		//disable event notification and wait for thread to halt
		EscapeCommFunction(idComDev,CLRDTR);
		PurgeComm(idComDev,PURGE_TXABORT|PURGE_RXABORT|PURGE_TXCLEAR|PURGE_RXCLEAR);
		Sleep(50); /// 300); 
    }
	isConnected=0; /// FALSE;
    ////////////Sleep(100); 

	if(osRead.hEvent) CloseHandle(osRead.hEvent);
	if(osWrite.hEvent) CloseHandle(osWrite.hEvent);
	if(idComDev) { CloseHandle(idComDev); idComDev=NULL; }

    
    //wait until CloseComPort() effective.
    //If not, OpenComPort()::CreateFile(...) will fail.

}



WORD 	CheckMsg(int ReVLength)
{

	if( !autoSendKey ) return 0;

	if( ReVLength < MSG_DNW_BEGIN_LEN ) return 0;

	if( NULL != strstr( rxBuf, MSG_DNW_BEGIN_TXT ) )
	{
		return DNW_BGN;
	}
	else if( NULL != strstr( rxBuf, MSG_DNW_END_TXT ) )
	{
		return DNW_END;
	}
	else if( NULL != strstr( rxBuf, MSG_DNW_SCR_CLEAR_TXT ) )
	{
		return DNW_CLR;
	}
/*
	else if( NULL != strstr( rxBuf, TEXT("Waiting....")) )
	{
		return DNW_ING;
	}
	else if( NULL != strnstr( rxBuf, MSG_DNW_NK_FIN_TXT, MSG_DNW_NK_FIN_LEN) )
	{
		return DNW_NK;
	}
	else if( NULL != strnstr( rxBuf, MSG_DNW_EBOOT_FIN_TXT, MSG_DNW_EBOOT_FIN_LEN) )
	{
		return DNW_EBOOT;
	}
	else if( NULL != strnstr( rxBuf, MSG_DNW_STEPLDR_FIN_TXT, MSG_DNW_STEPLDR_FIN_LEN) )
	{
		return DNW_STEP;
	}
*/
	else
	{
		return 0; /* NOT found !! */
	}
	
}

//////////////////////////////////////

void ResetCmdToDNW(void)
{
	memset(rxBuf, 0x00, sizeof(rxBuf));
}


void uSecDelay(int nTime)
{
	LARGE_INTEGER litmp; 
	LONGLONG QPartBegin, QPartEnd;
	double dfMinus, dfFreq, dfTim;

	QueryPerformanceFrequency(&litmp);
	dfFreq = (double)litmp.QuadPart;
	QueryPerformanceCounter(&litmp);
	QPartBegin = litmp.QuadPart;
	///EB_Printf(TEXT("[%u]\n"), QPartBegin);

	do
	{
		QueryPerformanceCounter(&litmp);
		QPartEnd = litmp.QuadPart;
		dfMinus = (double)(QPartEnd-QPartBegin);
		dfTim = dfMinus / dfFreq;
	} while(dfTim<0.001*nTime);
	
}


#ifdef __COMMENT_____

typedef struct _OVERLAPPED {
  ULONG_PTR Internal;
  ULONG_PTR InternalHigh;
  union {
    struct {
      DWORD Offset;
      DWORD OffsetHigh;
    };
    PVOID  Pointer;
  };
  HANDLE    hEvent;
} OVERLAPPED, *LPOVERLAPPED;
#endif /// ------------------


void DoRxTx(void *args)
{
	OVERLAPPED os;
	DWORD dwEvtMask;
	int nLength, mPos=0;
	BOOL fStat;
	DWORD dwWritten;
	DWORD nCount=0, idx=0;
	WORD  MsgType=0, iend=0;

	COMSTAT comStat;
	DWORD dwErrorFlags = 0;
	extern BOOL bUSBTxFile;
	DWORD dwError;
	SYSTEMTIME sysTime; /// 2013.04.09
	BOOL  bRC;

	memset(Date_Time, 0x00, sizeof(Date_Time) );

    memset(&sysTime,0,sizeof(SYSTEMTIME)); /// 2013.04.09
	memset(&comStat, 0x00, sizeof(COMSTAT) ); /// 2014.1.4

    memset(&os,0,sizeof(OVERLAPPED));
    os.hEvent = CreateEvent(NULL,TRUE,FALSE,NULL);
    if( (INVALID_HANDLE_VALUE == os.hEvent) || (NULL == os.hEvent) )
    {
		DWORD dwError = GetLastError();
		EB_Printf(TEXT("[dnw] can not create the os.hEvent event. (L:%d, Error=%u)\n"),  __LINE__ , dwError );
		ClearCommError(idComDev,&dwErrorFlags,&comStat); /// added 2011.1.29
		/// 2013.12.26, PurgeComm(idComDev,PURGE_TXABORT|PURGE_RXABORT|PURGE_TXCLEAR|PURGE_RXCLEAR); /// added. 2012.02.17
		CloseComPort(); /// added.
		_endthread();
		return; /// added 2011.1.29
    }

/*
   EV_RXCHAR (0x01) : ���ڰ� ���ŵǾ���
   EV_RXFLAG  (0x02) : DCB����ü�� EvtChar �� ���ڰ� ���ŵǾ� �Է¹��ۿ� ����Ǿ���
   EV_TXEMPTY (0x04) : ��� ���۷� ������ ���ڰ� ���۵Ǿ���
   EV_CTS       (0x08) : CTS ��ȣ�� ����Ǿ���
   EV_DSR       (0x10) : DSR ��ȣ�� ����Ǿ���
   EV_BREAK   (0x40) : �Է½ÿ� ���ڱ� �ߴ��� �Ǿ���
   EV_ERR       (0x80) : ������ ���� �Ǿ���
   EV_RING     (0x100) : ��ȭ���� �����
*/


    /// if(!SetCommMask(idComDev, EV_RXCHAR| EV_TXEMPTY| EV_ERR|EV_RXFLAG|EV_BREAK| EV_CTS| EV_DSR))
	if(!SetCommMask(idComDev, EV_RXCHAR|EV_TXEMPTY|EV_ERR |EV_RXFLAG|EV_BREAK))
	{

		SetCommMask(idComDev, 0);
		ClearCommError(idComDev,&dwErrorFlags,&comStat); /// added 2011.1.29
		//disable event notification and wait for thread to halt
		EscapeCommFunction(idComDev,CLRDTR);
		PurgeComm(idComDev,PURGE_TXABORT|PURGE_RXABORT|PURGE_TXCLEAR|PURGE_RXCLEAR);
		
		DWORD dwError = GetLastError();
		EB_Printf(TEXT("[dnw] can not set COM%d port mask! (L:%d, Error=%u) \n"), userComPort, __LINE__ , dwError );
		if( os.hEvent ) { CloseHandle(os.hEvent); os.hEvent=NULL; }
		CloseComPort(); /// added.
		_endthread();
		return; /// added.
	}

	bRC = ClearCommError(idComDev, &dwErrorFlags, &comStat); /// added 2014.08.13
	if( 0==bRC ) 
	{ 
		dwError = GetLastError();
		EB_Printf(TEXT("[dnw] ClearCommError() is failed. dwError(%u) \r\n"), dwError );
	} 
	
	if(dwErrorFlags & CE_BREAK) 
	{ 
		EB_Printf( TEXT("[dnw] CE_BREAK detected on COM%d port. \n"), userComPort); 
	} 
	

	PurgeComm(idComDev,PURGE_TXABORT|PURGE_RXABORT|PURGE_TXCLEAR|PURGE_RXCLEAR); /// 2014.01.04

	/// __try { /// 2013.04.09
		
    while(1==isConnected )
    {
		dwEvtMask=0;

    #if IS_OVERLAPPED_IO
		fStat = WaitCommEvent(idComDev,&dwEvtMask,&os);   

	#ifdef IS_OVERLAPPED_CHECK /// 2014.03.04 ----
		if( HasOverlappedIoCompleted(&os) )
		{
			/// EB_Printf(TEXT("Completed") );
			///Returns TRUE if the I/O operation has completed, and FALSE otherwise.
		}
		else
	#else /// 2014.07.23
		//Apr.28.2003: fStat should be checked for the cpu time saving. 
		if(!fStat)   //Apr.28.2003:GetOverlappedResult() is needed.  
	#endif /// -------------------------
		{
			/// To cancel all pending asynchronous I/O operations, use the CancelIo function. 
			/// The CancelIo function only cancels operations issued by the calling thread for the specified file handle. 
			/// I/O operations that are canceled complete with the error ERROR_OPERATION_ABORTED.
			/// To get more details about a completed I/O operation, call the GetOverlappedResult or GetQueuedCompletionStatus function.
		

		    //By experiment. Only when there was no signalled event, the following was executed.
		    //EB_Printf(TEXT("[dnw] [WaitCommEvent=false]\n") ); 
		    ///--> ���� ������ ���ڰ� ������ ���..
		    if( ERROR_IO_PENDING == GetLastError() )
		    {

		#ifdef IS_OVERLAPPED_CHECK /// 2014.03.04 ----
				// I/O�� �Ϸ�� �� ���� ��ٸ���.
				WaitForSingleObject(os.hEvent, IS_OVERLAPPED_WAIT);
		#endif /// -----------------------------
	
		    	/* �񵿱� ����� ���¸� �����ϴ� ��� */
				while( ! GetOverlappedResult(idComDev, &os, &dwWritten, TRUE) ) /// 2014.01.04 /// if() -> while()
				{
					dwError = GetLastError();
					if(ERROR_IO_INCOMPLETE == dwError ) 
					{
						/// normal result if not finished
						continue;
					}
					else if(ERROR_HANDLE_EOF == dwError ) /// 2014.07.23
					{
						/// End of file reached.
						EB_Printf(TEXT("\r\n\r\n[dnw] COM%d port End of file reached !!! \r\n"), userComPort );
						break;
					}
					else
					{
						/// 2013.12.24 --- dwWritten = 0;
						PurgeComm(idComDev,PURGE_TXABORT|PURGE_RXABORT|PURGE_TXCLEAR|PURGE_RXCLEAR); /// added. 2012.02.17
						ClearCommError(idComDev, &dwErrorFlags, &comStat);
						break;
					}
				}


		    }
		    else
		    {
				dwError = GetLastError();
				///state := WaitForSingleObject(ovlap.hEvent,10);
				dwWritten = 0; /// 2013.09.30, added.
				ClearCommError(idComDev,&dwErrorFlags,&comStat); /// 2010.05.20 added.
				PurgeComm(idComDev,PURGE_TXABORT|PURGE_RXABORT|PURGE_TXCLEAR|PURGE_RXCLEAR); /// added. 2012.02.17

				switch( dwErrorFlags )
				{
					case CE_BREAK: /// 0x0010 The hardware detected a break condition.
						EB_Printf(TEXT("\r\n\r\n[dnw] COM%d port is disconnected by CE_BREAK !!! \r\n"), userComPort );
						break;
				 	case CE_FRAME: /// 0x0008 The hardware detected a framing error.
						EB_Printf(TEXT("\r\n\r\n[dnw] COM%d port is disconnected by CE_FRAME !!! \r\n"), userComPort );
						break;
				 	case CE_OVERRUN: /// 0x0002 A character-buffer overrun has occurred. The next character is lost.
						EB_Printf(TEXT("\r\n\r\n[dnw] COM%d port is disconnected by CE_OVERRUN !!! \r\n"), userComPort );
						break;
				 	case CE_RXOVER: /// 0x0001 An input buffer overflow has occurred. There is either no room in the input buffer, or a character was received after the end-of-file (EOF) character.
						EB_Printf(TEXT("\r\n\r\n[dnw] COM%d port is disconnected by CE_RXOVER !!! \r\n"), userComPort );
						break;
				 	case CE_RXPARITY: /// 0x0004 The hardware detected a parity error.
						EB_Printf(TEXT("\r\n\r\n[dnw] COM%d port is disconnected by CE_RXPARITY !!! \r\n"), userComPort );
						break;
				 	default:
						EB_Printf(TEXT("\r\n\r\n[dnw] COM%d port is disconnected by default(0x%X) !!! \r\n"), userComPort,dwErrorFlags );
						break;
				}

				/// comStat.cbInQue  : The number of bytes received by the serial provider but not yet read by a ReadFile operation.
				
				/// comStat.cbOutQue : The number of bytes of user data remaining to be transmitted for all write operations. 
				/// This value will be zero for a nonoverlapped write.

				EB_Printf(TEXT("[dnw] COM%d port is disconnected!!! (Error=%d, V:%d) [InQ(%d), OutQ(%d)]\r\n"), 
						userComPort, dwError, isConnected, comStat.cbInQue, comStat.cbOutQue  );

				/// PurgeComm(idComDev,PURGE_TXABORT|PURGE_RXABORT|PURGE_TXCLEAR|PURGE_RXCLEAR); /// added. 2014.1.5

				/// COM port is closed..
				///if( 0!=comStat.cbInQue && 0!=comStat.cbOutQue )
				{
					CloseComPort();
			#ifdef IS_OVERLAPPED_CHECK /// 2014.03.05 ----
					// I/O�� �Ϸ�� �� ���� ��ٸ���. -> HandleClose
					if(os.hEvent) CloseHandle(os.hEvent);
					if(osRead.hEvent) CloseHandle(osRead.hEvent);
					if(osWrite.hEvent) CloseHandle(osWrite.hEvent);
			#endif /// -----------------------------

					memset(rxBuf, 0x00, sizeof(rxBuf));

					break;
				}
		
		    }

		}
    #else
		WaitCommEvent(idComDev,&dwEvtMask,NULL);  //wait until any event is occurred.
    #endif

		if( EV_TXEMPTY == (dwEvtMask & EV_TXEMPTY) )
		{
		    txEmpty = TRUE;
		}


		if( EV_RXCHAR == (dwEvtMask & EV_RXCHAR) ) /// A character was received and placed in the input buffer.
		{
		    do   //Apr.28.2003:The caveat on MSDN,"Serial Communications in Win32" recommends while();
		    {


			#if 0 /*--- display time or date&time,  2014.06.24 --- */
				if( 0==localTime ) /// NONE
				{
					index_rxBuf = 0;
				}
				else if( 1==localTime ) /// Time Only
				{
					index_rxBuf = 13;

					GetLocalTime( &sysTime );
					wsprintf(&rxBuf[0], TEXT("[%02d%02d%02d.%03d] "),	/// 13
								sysTime.wHour, sysTime.wMinute, sysTime.wSecond, sysTime.wMilliseconds); 
				}
				else if( 2==localTime ) /// Date & Time
				{
					index_rxBuf = 18;

					GetLocalTime( &sysTime );
					wsprintf(&rxBuf[0], TEXT("[%04d%02d%02d;%02d%02d%02d] "),  /// 18
							sysTime.wYear, sysTime.wMonth, sysTime.wDay, sysTime.wHour, sysTime.wMinute, sysTime.wSecond); 
				}
				else /// default : NONE
				{
					index_rxBuf = 0;
				}
			#endif /////--------------------



			#if 1	    
				if( nLength = ReadCommBlock( rxBuf, MAX_BLOCK_SIZE) )
			#else
				if( nLength = ReadCommBlock(&rxBuf[index_rxBuf], MAX_BLOCK_SIZE) )
			#endif
				{
				    if(nLength>=MAX_BLOCK_SIZE /*for debug*/)
				    {
						///memset(rxBuf, 0x00, sizeof(rxBuf) ); /* initial added. */
						EB_Printf(TEXT("\n\n[dnw] find error overrun (length=%d, L:%d) \n"), nLength, __LINE__ );
				    }
				    else
				    {

				#if 1 /*--- 2013.04.09, Aging �� PC�� �ð��� �� �ʿ䰡  �ִ�.  ------ */
						if( 2==localTime ) /// Date & Time
						{
							GetLocalTime( &sysTime );
							wsprintf(Date_Time, TEXT("[%04d%02d%02d;%02d%02d%02d] "),  /// 18
									sysTime.wYear, sysTime.wMonth, sysTime.wDay, sysTime.wHour, sysTime.wMinute, sysTime.wSecond); 
							EB_Printf(Date_Time);
						}
						else if( 1==localTime ) /// Time Only
						{
							GetLocalTime( &sysTime );
							wsprintf(Date_Time, TEXT("[%02d%02d%02d.%03d] "),   /// 13
										sysTime.wHour, sysTime.wMinute, sysTime.wSecond, sysTime.wMilliseconds); 
							EB_Printf(Date_Time);
						}
				#endif ////////////////////////////////////////////////////////////////////////



					#if 0 /// 2014.06.24, For inserting Time or DATE&TIme
						rxBuf[nLength+index_rxBuf]='\0';
					#else
					    rxBuf[nLength]='\0';
					#endif


					    //OutputDebugString(rxBuf);
					    EB_Printf(rxBuf);


					////////////////// automatic added... ///////////////////////
					#if 1
						if( autoSendKey )
						{
							///WriteCommBlock('/');  /* DNW to 6410 or C100 CPU */

							MsgType = CheckMsg( nLength );

							if( (DNW_END == MsgType) )
							{
								ResetCmdToDNW();
								nLength = 0;
								////WriteCommBlock(',');  /* ENDED....	*/

								BinFileIndex = 0;
								DownloadedBin = 0x00;
							}
							else if( DNW_BGN == MsgType )
							{
								ResetCmdToDNW();
								nLength = 0;

								if( TOTAL_BIN_OK != DownloadedBin ) /* �̹� 3�� ���� ��� ó���ߴ�. */
								{
									Sleep(1500); /// (1000); /* For CloseDownloadProgress()	*/
								 	while( TRUE == bUSBTxFile ) 
									{ 
										Sleep(1); 
									} /// 2010.05.26 added.

									SendMessage(_MainHwnd, WM_COMMAND, CM_ROM_ALL, 0 );
								}

								if( TOTAL_BIN_OK == DownloadedBin )
								{
									BinFileIndex = 0;
									DownloadedBin = 0x00;
									mpCount ++;
								}

								///////////CloseDownloadProgress(); /// added.
								///////////Sleep(1);
								/////////// break;
							}
							else if( (DNW_CLR == MsgType) )
							{
								ResetCmdToDNW();
								nLength = 0;
								
								////WriteCommBlock(',');  /* ENDED....	*/
						#if 0
								Sleep(100); /* For CloseDownloadProgress()	*/
 								SendMessage(_MainHwnd, WM_COMMAND, CM_CLEAR_BUF, 0 );

								BinFileIndex = 0;
								DownloadedBin = 0x00;
						#endif
							}
						#if 0
							else if( (DNW_ING == MsgType) )
							{
								ResetCmdToDNW();
							}
						#endif
						
						}	
					#endif /////////////////////////////////////////////////////////
					////////////////// automatic added... ///////////////////////

				    }
				}

		    }while(nLength);  
		}

		if( EV_ERR == (dwEvtMask & EV_ERR) ) /// A line-status error occurred. Line-status errors are CE_FRAME, CE_OVERRUN, and CE_RXPARITY.
		{
			// Clear OVERRUN condition.
			// If OVERRUN error is occurred,the tx/rx will be locked.
		  	//// ---- EB_Printf(TEXT("[dnw] [EV_ERR=0x%X] \n"),dwErrorFlags);
			/// 2013.12.24 --- dwWritten = 0; /// 2013.09.30, added.
			/// --------------
			/// Retrieves information about a communications error and reports the current status of a communications device. 
			/// The function is called when a communications error occurs, 
			/// and it clears the device's error flag to enable additional input and output (I/O) operations.
		    ClearCommError(idComDev,&dwErrorFlags,&comStat);

	#if 1 /// __DEBUG__
			if( CE_BREAK == (dwErrorFlags&CE_BREAK) ) /// 0x0010  [inQ(%d), outQ(%d)]") );
			{
				EB_Printf(TEXT("\r\n[dnw] The hardware detected a break condition. [inQ(%d), outQ(%d)] \r\n"), comStat.cbInQue, comStat.cbOutQue  );
			}

			if( CE_FRAME == (dwErrorFlags&CE_FRAME) ) /// 0x0008 
			{
				EB_Printf(TEXT("\r\n[dnw] The hardware detected a framing error. [inQ(%d), outQ(%d)] \r\n"), comStat.cbInQue, comStat.cbOutQue  );
			}

			if( CE_RXPARITY == (dwErrorFlags&CE_RXPARITY) ) /// 0x0004 
			{
				EB_Printf(TEXT("\r\n[dnw] The hardware detected a parity error. [inQ(%d), outQ(%d)] \r\n"), comStat.cbInQue, comStat.cbOutQue  );
			}

		#if 0
			if( CE_OVERRUN == (dwErrorFlags&CE_OVERRUN) ) /// 0x0002 
			{
				EB_Printf(TEXT("\n[dnw] A character-buffer overrun has occurred. The next character is lost. [inQ(%d), outQ(%d)] \r\n"), comStat.cbInQue, comStat.cbOutQue  );
			}

			if( CE_RXOVER == (dwErrorFlags&CE_RXOVER) ) /// 0x0001 
			{
				///EB_Printf(TEXT("\n[dnw] An input buffer overflow has occurred. There is either no room in the input buffer, or a character was received after the end-of-file (EOF) character. dwErrorFlags(0x%X) \n"), dwErrorFlags, comStat.cbInQue, comStat.cbOutQue  );
				EB_Printf(TEXT("\n[dnw] An input buffer overflow has occurred. [inQ(%d), outQ(%d)] \r\n"), comStat.cbInQue, comStat.cbOutQue  );
			}
		#endif
	#endif //////////////////////

			/// ------------------------------------
			/// Discards all characters from the output or input buffer of a specified communications resource. 
			/// It can also terminate pending read or write operations on the resource.

			memset(rxBuf, 0x00, sizeof(rxBuf));
			PurgeComm(idComDev,PURGE_TXABORT|PURGE_RXABORT|PURGE_TXCLEAR|PURGE_RXCLEAR); /// 2014.08.13
			
		}

		/// The event character was received and placed in the input buffer. 
		/// The event character is specified in the device DCB structure, which is applied to a serial port by using the SetCommState function.
		if( EV_BREAK == (dwEvtMask & EV_BREAK) )  /// A break was detected on input.
		{
			ClearCommError(idComDev, &dwErrorFlags, &comStat);
			///EB_Printf(TEXT("\r\n[dnw] detect EV_BREAK signal!!! [inQ(%d), outQ(%d)]"), comStat.cbInQue, comStat.cbOutQue );

			memset(rxBuf, 0x00, sizeof(rxBuf));
			PurgeComm(idComDev,PURGE_TXABORT|PURGE_RXABORT|PURGE_TXCLEAR|PURGE_RXCLEAR); /// 2014.08.13
		}
		if( EV_RXFLAG == (dwEvtMask & EV_RXFLAG) ) 
		{
			/// EB_Printf(TEXT("\n[dnw] EV_RXFLAG signal!!! \n"));
		}


	#if 1 //////////////////////
		if( EV_CTS == (dwEvtMask & EV_CTS) )  /// The CTS (clear-to-send) signal changed state.
		{
			EB_Printf(TEXT("\n[dnw] EV_CTS signal!!! \n"));
		}

		if( EV_DSR == (dwEvtMask & EV_DSR) ) /// The DSR (data-set-ready) signal changed state.
		{
			EB_Printf(TEXT("\n[dnw] EV_DSR signal!!! \n"));
		}

		if( EV_RING == (dwEvtMask & EV_RING) )  /// A ring indicator was detected.
		{
			EB_Printf(TEXT("\n[dnw] EV_RING signal!!! \n"));
		}

		if( EV_RLSD == (dwEvtMask & EV_RLSD) )  /// The RLSD (receive-line-signal-detect) signal changed state.
		{
			EB_Printf(TEXT("\n[dnw] EV_RLSD signal!!! \n"));
		}
	#endif


    }	


	///} 
	/// __except (EXCEPTION_EXECUTE_HANDLER) {
	///	EB_Printf(TEXT("\n[dnw] EXCEPTION_EXECUTE_HANDLER GetLastError(%u) \n"), GetLastError() );
	///	CloseComPort();
	///}

	
	if( os.hEvent ) 
	{
		CloseHandle(os.hEvent);
		os.hEvent=NULL; 
	}
    _endthread();
}


int ReadCommBlock(char *buf,int maxLen)
{
    BOOL fReadStat;
    COMSTAT comStat;
    DWORD dwErrorFlags;
    DWORD dwLength;
	DWORD dwtmRead; /// 2014.08.11
	DWORD dwError;

	memset(&comStat, 0x00, sizeof(COMSTAT) ); /// 2014.1.4


	/// only try to read number of bytes in queue
    ClearCommError(idComDev,&dwErrorFlags,&comStat);
    dwLength=min((DWORD)maxLen,comStat.cbInQue);

#if 1 /// 2014.08.11
	// ���� ����Ÿ�� �ִٸ� ���� �Ŀ� �о�� ����Ÿ ���� ���� ���� ����Ÿ ���� 
	// ���Ͽ� ������ ���� �Լ��� �޼����� ������. 
	dwLength = comStat.cbInQue; 
	dwtmRead = dwLength;
#endif

    if(dwLength>0)
    {
    #if IS_OVERLAPPED_IO

		fReadStat = ReadFile(idComDev, buf, dwtmRead, &dwLength, &osRead);

	#ifdef IS_OVERLAPPED_CHECK /// 2014.03.04 ----
		if( HasOverlappedIoCompleted(&osRead) )
		{
			/// EB_Printf(TEXT("Completed") );
		}
		else
	#endif /// -------------------------
		if(!fReadStat)   //Apr.28.2003:GetOverlappedResult() may be needed.
		{
			//By experiment, fReadStat was always TRUE,of course, and the following was never executed.
			//EB_Printf(TEXT("\n[dnw] [RX_RD_WAIT]\n") ); 
			//--> ���� ������ ���ڰ� ������ ���..
			if( ERROR_IO_PENDING == GetLastError() )
			{

		#ifdef IS_OVERLAPPED_CHECK /// 2014.03.04 ----
				// I/O�� �Ϸ�� �� ���� ��ٸ���.
				WaitForSingleObject(osRead.hEvent, IS_OVERLAPPED_WAIT);
		#endif /// -----------------------------
	

				// ���� ���ڰ� ���� �ְų� ������ ���ڰ� ���� ���� ��� Overapped IO�� Ư���� ���� ERROR_IO_PENDING ���� �޽����� ���޵ȴ�.
				//timeouts�� ������ �ð���ŭ ��ٷ��ش�.
				while( !GetOverlappedResult(idComDev,&osRead,&dwLength,TRUE) ) /// 2012.07.03 /// if() -> while()
				{
					dwError = GetLastError();
					if(ERROR_IO_INCOMPLETE == dwError ) 
					{
						/// normal result if not finished
						continue;
					}
					else
					{
						/// an error occurred, try to recover
						/// 2013.12.24 --- dwLength = 0;
						ClearCommError(idComDev, &dwErrorFlags, &comStat);
						break;
						/// 2013.12.26, PurgeComm(idComDev,PURGE_TXABORT|PURGE_RXABORT|PURGE_TXCLEAR|PURGE_RXCLEAR); /// added. 2012.02.17
					}
				}
			}
			else
			{
				DWORD dwError = GetLastError();
				EB_Printf(TEXT("[dnw] find COM%d port Rx error. (Len:%d, L:%d, Error=%u) \n"), userComPort, dwLength, __LINE__ , dwError );

				/// some other error occurred
				dwLength = 0; /// 2012.07.03
				ClearCommError(idComDev, &dwErrorFlags, &comStat); /// 2012.07.03
				PurgeComm(idComDev,PURGE_TXABORT|PURGE_RXABORT|PURGE_TXCLEAR|PURGE_RXCLEAR); /// added. 2014.07.08
			}
		}
    #else
		fReadStat=ReadFile(idComDev,buf,dwLength,&dwLength,NULL);
		if(!fReadStat)
		{
			DWORD dwError = GetLastError();
			EB_Printf(TEXT("[dnw] find COM%d port Rx error. (L:%d, Error=%u) \n"), userComPort, __LINE__ , dwError );
		}
    #endif
    }



#if 0 /// 2014.08.11
	if( dwtmRead == dwLength )
		return dwLength;
	else
		return 0;
#else
	return dwLength;
#endif
}





#define TX_SIZE 2048
//TX_SIZE must be less than 4096
void TxFile(void *args)
{
    void *txBlk = NULL;
    DWORD txBlkSize;
    DWORD fWriteStat;
    DWORD temp;
    COMSTAT comStat; /// 2011.11.29
    DWORD dwErrorFlags;
	DWORD dwError;

	memset(&comStat, 0x00, sizeof(COMSTAT) ); /// 2014.1.4


    InitDownloadProgress();
    while( FALSE==txEmpty )
    {
		;
    }
	
    if( 0==TxBufSize ) TxBufSize=1; /// 2010.05.25 critical error fix.

    while(1)
    {
		if((TxBufSize-idxTxBuf) > TX_SIZE)
			txBlkSize=TX_SIZE;
		else
			txBlkSize=TxBufSize-idxTxBuf;
	
		txBlk=(void *)(SerialTxBuf+idxTxBuf);

		txEmpty = FALSE;


    #if IS_OVERLAPPED_IO
		fWriteStat = WriteFile(idComDev,txBlk,txBlkSize,&temp,&osWrite);


	#ifdef IS_OVERLAPPED_CHECK /// 2014.03.04 ----
		if( HasOverlappedIoCompleted(&osWrite) )
		{
			/// EB_Printf(TEXT("Completed") );
		}
		else
	#endif /// -------------------------

		if(!fWriteStat)   //Apr.28.2003:GetOverlappedResult() may be needed.
		{
			if( ERROR_IO_PENDING==GetLastError() )
			{

		#ifdef IS_OVERLAPPED_CHECK /// 2014.03.04 ----
				// I/O�� �Ϸ�� �� ���� ��ٸ���.
				WaitForSingleObject(osWrite.hEvent, IS_OVERLAPPED_WAIT);
		#endif /// -----------------------------
	
				while( ! GetOverlappedResult(idComDev,&osWrite,&temp,TRUE) ) /// 2014.01.04 /// if() -> while()
				{
					//more efficient in order to save the cpu time
					dwError = GetLastError();
					if(ERROR_IO_INCOMPLETE == dwError ) 
					{
						/// normal result if not finished
						continue;
					}
					else
					{
						/// 2013.12.24 --- temp = 0;
						ClearCommError(idComDev, &dwErrorFlags, &comStat);
						break;
						/// 2013.12.26, PurgeComm(idComDev,PURGE_TXABORT|PURGE_RXABORT|PURGE_TXCLEAR|PURGE_RXCLEAR); /// added. 2012.02.17

					}
				}

			}
			else
			{
				DWORD dwError = GetLastError();
				EB_Printf(TEXT("[dnw] find error in TxFile. (L:%d, Error=%u) \n"),  __LINE__ , dwError );

				/// 2013.12.24 --- temp = 0;
				ClearCommError(idComDev, &dwErrorFlags, &comStat); /// 2012.07.03
				/// 2013.12.26, PurgeComm(idComDev,PURGE_TXABORT|PURGE_RXABORT|PURGE_TXCLEAR|PURGE_RXCLEAR); /// added. 2012.02.17
				///// break; /////////////// added.
			}
		}
		else
		{
		    //By experiment, never executed.
		    //EB_Printf(TEXT("\n[dnw] [TX_NO_WR_WAIT]\n") ); 
		}
    #else
		WriteFile(idComDev,txBlk,txBlkSize,&temp,NULL);
		Sleep(TX_SIZE*1000/11520-10); //to save cpu time.
		while(txEmpty==FALSE);
    #endif

		idxTxBuf+=TX_SIZE;
	
		DisplayDownloadProgress(idxTxBuf*100/TxBufSize);

		if(downloadCanceled==1)break;	//download is canceled by user.

		if(idxTxBuf>=TxBufSize)break;
    }

    if(SerialTxBuf) free((void *)SerialTxBuf);

    CloseDownloadProgress();

    _endthread();
}



void WriteCommBlock(char c)
{
    void *txBlk = NULL;
    DWORD txBlkSize;
    static char _c;
    DWORD temp;
    DWORD fWriteStat; /// 2011.11.29
    COMSTAT comStat; /// 2011.11.29
    DWORD dwErrorFlags;
	DWORD dwError;


	memset(&comStat, 0x00, sizeof(COMSTAT) ); /// 2014.1.4

    _c=c;

    while(txEmpty==FALSE)
    {
		;
    }
	
    txBlk=&_c;
    txBlkSize=1;

    //txEmpty=FALSE; why needed??? this line should be removed.
#if IS_OVERLAPPED_IO
    fWriteStat = WriteFile(idComDev,txBlk,txBlkSize,&temp,&osWrite);

#ifdef IS_OVERLAPPED_CHECK /// 2014.03.04 ----
	if( HasOverlappedIoCompleted(&osWrite) )
	{
		/// EB_Printf(TEXT("Completed") );
	}
	else
#endif /// -------------------------

	if(!fWriteStat)   //Apr.28.2003:GetOverlappedResult() may be needed.
	{
		if(GetLastError()==ERROR_IO_PENDING)
		{

	#ifdef IS_OVERLAPPED_CHECK /// 2014.03.04 ----
			// I/O�� �Ϸ�� �� ���� ��ٸ���.
			WaitForSingleObject(osWrite.hEvent, IS_OVERLAPPED_WAIT);
	#endif /// -----------------------------


			while( ! GetOverlappedResult(idComDev,&osWrite,&temp,TRUE) ) /// 2014.01.04 /// if() -> while()
			{
				//more efficient in order to save the cpu time
				dwError = GetLastError();
				if(ERROR_IO_INCOMPLETE == dwError ) 
				{
					/// normal result if not finished
					continue;
				}
				else
				{
					/// 2013.12.24 --- temp = 0; /// 2013.09.30, added
					ClearCommError(idComDev, &dwErrorFlags, &comStat);
					break;
					/// 2013.12.26, PurgeComm(idComDev,PURGE_TXABORT|PURGE_RXABORT|PURGE_TXCLEAR|PURGE_RXCLEAR); /// added. 2012.02.17
				}
			}

		}
	#if 1
		else
		{
			/// 2013.12.24 --- temp = 0; /// 2013.09.30, added
			ClearCommError(idComDev, &dwErrorFlags, &comStat); /// 2012.07.04
			/// 2013.12.26, PurgeComm(idComDev,PURGE_TXABORT|PURGE_RXABORT|PURGE_TXCLEAR|PURGE_RXCLEAR); /// added. 2012.02.17
			///EB_Printf(TEXT("[dnw] ERROR:WriteCommBlock error!! \r\n") );
			///// break; /////////////// added.
		}
	#endif
	}

#else
    WriteFile(idComDev,txBlk,txBlkSize,&temp,NULL);
#endif
    while(txEmpty==FALSE);
}
    


