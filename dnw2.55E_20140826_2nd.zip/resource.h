//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by dnw.rc
//
#define _CRT_SECURE_NO_WARNINGS  /* compile �� warning error fix, �ٸ� header ���� ���� �ֻ��� �� �����׾� �Ѵ�. */

#define COLOR_DISP2
/// #define ENGINEER_MODE, project file�� ����..
#define HEXA_MODE_SUPPORT 				1 /// 2012.07.03
#define SERIAL_CONNECTING_DISPLAY 		1 /// 2012.07.05, connecting 
#define COM_SETTINGS 					1 /// 2012.07.10
///#define _STDOUT_FLUSH_ 					1 /// 2012.07.11







#define IDR_MENU1                       101
#define IDI_ICON1                       103
#define IDD_DIALOG1                     104
#define IDD_DIALOG2                     105
#define IDI_DISK                        107
#define IDI_CONNECT                     108
#define IDI_ICON2                       116
#define CM_UBOOT                        117
#define IDR_ACCELERATOR1                118
#define IDR_ACCELERATOR2                119
#define IDC_PROGRESS1                   1000

#define IDC_RADIO921600                 1001  /* 921.6 Kbps */
#define IDC_RADIO460800                 1002
#define IDC_RADIO380400                 1003
#define IDC_RADIO312500                 1004
#define IDC_RADIO256000                 1005
#define IDC_RADIO230400                 1006
#define IDC_RADIO153600                 1007  /* AVC-LAN comm. */
#define IDC_RADIO128000                 1008
#define IDC_RADIO115200                 1009  /* 115.2 Kbps */
#define IDC_RADIO76800                  1010
#define IDC_RADIO57600                  1011
#define IDC_RADIO56000                  1012
#define IDC_RADIO38400                  1013
#define IDC_RADIO31250                  1014
#define IDC_RADIO19200                  1015
#define IDC_RADIO14400                  1016
#define IDC_RADIO9600                   1017
#define IDC_RADIO4800                   1018
#define IDC_RADIO2400                   1019



#define IDC_RADIOCOM0                   1021
#define IDC_RADIOCOM1                   1022
#define IDC_RADIOCOM2                   1023
#define IDC_RADIOCOM3                   1024
#define IDC_RADIOCOM4                   1025
#define IDC_RADIOCOM5                   1026
#define IDC_RADIOCOM6                   1027
#define IDC_RADIOCOM7                   1028
#define IDC_RADIOCOM8                   1029
#define IDC_RADIOCOM9                   1030
#define IDC_RADIOCOM10                  1031
#define IDC_RADIOCOM11                  1032
#define IDC_RADIOCOM12                  1033
#define IDC_RADIOCOM13                  1034
#define IDC_RADIOCOM14                  1035
#define IDC_RADIOCOM15                  1036
#define IDC_RADIOCOM16                  1037
#define IDC_RADIOCOM17                  1038
#define IDC_RADIOCOM18                  1039
#define IDC_RADIOCOM19                  1040
#define IDC_RADIOCOM20                  1041
#define IDC_RADIOCOM21                  1042
#define IDC_RADIOCOM22                  1043
#define IDC_RADIOCOM23                  1044
#define IDC_RADIOCOM24                  1045
#define IDC_RADIOCOM25                  1046
#define IDC_RADIOCOM26                  1047
#define IDC_RADIOCOM27                  1048
#define IDC_RADIOCOM28                  1049
#define IDC_RADIOCOM29                  1050
#define IDC_RADIOCOM30                  1051
#define IDC_RADIOCOM31                  1052
#define IDC_RADIOCOM32                  1053
#define IDC_RADIOCOM33                  1054
#define IDC_RADIOCOM34                  1055
#define IDC_RADIOCOM35                  1056
#define IDC_RADIOCOM36                  1057
#define IDC_RADIOCOM37                  1058




#define IDC_RADIO_AUTO_SEND_OFF         1145
#define IDC_RADIO_AUTO_SEND_ON          1146

#define IDC_RADIO_MSG_SAVE_OFF          1150
#define IDC_RADIO_MSG_SAVE_ON           1151


#define IDC_EDIT1                       1155
#define IDC_EDIT_HEX_COL                1156
#define IDC_EDIT2                       1157 /// 2014.04.15, UART baudrate

#define IDC_FONT0_OEM_FIX               1170
#define IDC_FONT1_ANSI_FIX              1171
#define IDC_FONT2_DEVICE                1172
#define IDC_FONT3_SYSTEM_FIX            1173

#if defined( COLOR_DISP2 )
#define IDC_COLOR_TYPE_GRAY             1180
#define IDC_COLOR_TYPE_BLACK            1181
#endif

#if 1 /* 2011.02.08 , Text Mode or Hexa Mode */
#define IDC_OUT_TEXT_MODE               1190
#define IDC_OUT_HEXA1_MODE              1191
//#define IDC_OUT_HEXA2_MODE              1092
#endif

#define IDC_COM_NOPARITY 				1300 /// 0 // NOPARITY
#define IDC_COM_ODDPARITY 				1301 // 1
#define IDC_COM_EVENPARITY 				1302 /// 2
#define IDC_COM_MARKPARITY 				1303 /// 3
#define IDC_COM_SPACEPARITY 			1304 /// 4


#define IDC_COM_ONESTOPBIT 				1305 /// 0  (1 stop bit)
#define IDC_COM_ONE5STOPBITS    		1306 /// 1 ( 1.5 stop bits.)
#define IDC_COM_TWOSTOPBITS 			1307 /// 2 (2 stop bit)


#define IDC_COM_DATA_7BIT 				1310  
#define IDC_COM_DATA_8BIT 				1311 
#define IDC_COM_DATA_DEF_BIT 			IDC_COM_DATA_8BIT

#define IDC_RETRY_USB_DEFAULT           1200
#define IDC_RETRY_USB_20_TIMES          1201
#define IDC_RETRY_USB_30_TIMES          1202
#define IDC_RETRY_USB_40_TIMES          1203

#define IDC_LOCALTIME_NONE              1400
#define IDC_LOCALTIME_TIMEONLY          1401
#define IDC_LOCALTIME_DATETIME          1402

#define IDC_CPU_SMDK6410                1410
#define IDC_CPU_SMDKC100                1411



#define CM_ABOUT                        40003
#define CM_TRANSMIT                     40005
#define CM_CONNECT                      40006
#define CM_EXIT                         40007
#define CM_DISCONNECT                   40008
#define CM_USBTRANSMIT                  40009
#define CM_SERIALSETTINGS               40010
#define CM_USBSTATUS                    40011

#define CM_OPTIONS                      40016
#define CM_USBRECEIVE                   40017
#define CM_UBOOT2                       40019
#define CM_CLEAR_BUF                    40020
#define IDM_EDIT_COPY                   40023
#define IDM_EDIT_ALL                    40024
#define IDM_EDIT_COPYALL                40025
#define CM_RAM_USBTRANSMIT_BL1          40026
#define CM_RAM_USBTRANSMIT_EBOOT        40027
#define CM_ROM_UBOOT2_1ST               40028
#define CM_ROM_UBOOT2_2ND               40029
#define CM_ROM_UBOOT2_3RD               40030
#define CM_ROM_ALL                      40031

/* Function key, F1 ... F12 */
#define IDM_CLEAR_BUFFER                40040
#define IDM_CONNECT_DISCONNECT          40041
#define IDM_EXIT                        40042
#define IDM_ABOUT                       40043

#define IDM_UBOOT2                      40044  /* Shift + F11 */
#define IDM_USBTRANSMIT                 40045  /* Shift + F10 */

#define IDM_ALL_BINS_TO_NAND            40046  /* HOT key F6 */
#define IDM_NK_TO_NAND                  40047  /* HOT key F7 */
#define IDM_EBOOT_TO_NAND               40048  /* HOT key F8 */
#define IDM_STEPLDR_TO_NAND             40049  /* HOT key F9 */
#define IDM_ALL_TO_NAND                 40050

#define IDM_UMON_TRANSMIT_TO_RAM        40051
#define IDM_OPTIONS                     40052
#define IDM_TEXT_HEXA_MODE              40053 /* F5 ; Text mode or Hexa mode */

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        120
#define _APS_NEXT_COMMAND_VALUE         40054
#define _APS_NEXT_CONTROL_VALUE         1095
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

