S3C2410X USB downloader Installation Guide Release 1.11   SEP.03.2002

1. Release History
r0  :MAR/24/02: -alpha release
     APR/01/02: -beta release
	         dnw.exe is upgraded to version 0.46.
	         u241mon.bin is upgraded to fix some small bug.
r1  :APR/11/02: -DNW.exe is seperated from the release package for the convenience of update.
                -The multi-download is implemented. 
r1.1:AUG/20/02: -usbsetup.c has been fixed.
r1.11:SEP/03/02: -The clocking on CLKOUT0,1 is stopped because it's not used.


2. Files
dnw.exe: PC USB/Serial downloader program
	 (dnw.exe isn't included. Please download the latest dnw.exe from www.samsungsemi.com.)
secbulk.inf,secbulk.sys: PC USB driver
u241mon.bin: S3C2400X USB downloader firmware


3. Installation.
1) Program the u241mon.bin into the flash memory of SMDK2410X board. 
2) Configure the J35,J36 to 1-2.
3) Turn on the board. The LED will flash. If doesn't, go to step 1) and check the board.
4) If you had installed the device driver for SMDK2400X/SMDK2410X,
   overwrite the new secbulk.sys at C:\WINDOWS\SYSTEM32\DRIVERS.
   In this case, the step 6) will be skipped.
5) connect the SMDK2410X board and PC
6) When the USB device driver installation window apper,
   install the USB device driver(secbulk.inf).
   secbulk.inf and secbulk.sys should be in the same directory. 
7) run dnw.exe.
8) Turn off and on the board.
9) If you can see the message([USB:OK]) in the window title bar, the installation succeeds.

NOTE.
1) If you have installed the device driver previous time, 
   replaec the old secbulk.sys in C:\WINDOWS\SYSTEM32\DRIVERS be the attached secbulk.sys.
2) The maximum speed of old secbulk.sys with SMDK2400 was 490KB/S.
   But, the new secbulk.sys is optimized for SMDK2410 and the maximum speed will be about 770KB/S.
   Please use new secbulk.sys for S3C2410X.


4. Download a .bin file.
1) Configure the serial port in the Configuration/Options menu.
2) Configure the download address,normally 0x30000000, in the menu.
3) Select the SerialPort/Connect menu to open COM port if you need.
4) Turn off and turn on(or Reset) SMDK2410X board to get USB device address from PC.
5) You can see the U241MON banner as follows;

+---------------------------------------------+
| S3C2410X USB Downloader ver 0.2  04/10/2002 |
+---------------------------------------------+
FCLK=180MHz,DMA mode
USB: IN_ENDPOINT:1 OUT_ENDPOINT:3
FORMAT: <ADDR(DATA):4>+<SIZE(n+10):4>+<DATA:n>+<CS:2>
NOTE: 1. Power off/on or press the reset button for 1 sec
         in order to get a valid USB device address.
      2. For additional menu, Press any key. 

USB host is connected. Waiting a download.

6) Select the USBPort/Transmit to transmit a .bin/.nb0 file.
  
  
6. Contact Point
If you have any questions, send us e-mail.
e-mail address : purnnamu@sec.samsung.com,purnnamu@hitel.net


7. Important Notice.
We have done best to remove bugs in these programs. But, there may be some bugs.
If you want to use the USB downloader commercially, we can't guarantee these programs.
		  
  