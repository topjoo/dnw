#ifndef __DNSTATUS_H__
#define __DNSTATUS_H__

BOOL CALLBACK DownloadProgressProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
void InitDownloadProgress(void);
void DisplayDownloadProgress(int percent);
void CloseDownloadProgress(void);

int ReadUserConfig(HWND hwnd);
int WriteUserConfig(void);
//#ifdef SANSIX_SMP201_CUSTOMIZING
int ReadQuickUserConfig(HWND hwnd);
int ReWriteQuickUserConfig(void);
int ReadQuickUMONConfig(HWND hwnd);
int WriteQuickUMONConfig(void);
//#endif

BOOL CALLBACK OptionsProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);

extern int downloadCanceled;

extern volatile HWND _hDlgDownloadProgress;


#define DNW_LOG_FILE 		TEXT(".\\dnwconfig\\dnw.ini")  /// 2014.04.10, TEXT("c:\\dnw.ini")

#define BAUD_RATE_NUM 		19

const int baudTable[BAUD_RATE_NUM]={
		921600,     /* 1, CBR_921600 */
		460800,     /* 2, CBR_460800 */
		380400,     /* 3, CBR_380400 */
		312500,     /* 4, added 2011.1.27 */
		CBR_256000, /* 5   256000 */
		230400,     /* 6 */
		153600,     /* 7, added 2011.1.27, AVC-LAN comm */
		CBR_128000, /* 8 */
		CBR_115200, /* 9  */
        76800,      /* 10 */
		CBR_57600,  /* 11 */
		CBR_56000,  /* 12 */
		CBR_38400,  /* 13 */
		31250,      /* 14, added 2011.1.27 */
		CBR_19200,  /* 15  */
		CBR_14400,  /* 16 */
		CBR_9600,   /* 17 */
		CBR_4800,   /* 18 */
		CBR_2400,	/* 19 */
	};



#define DATE_LEN 			32


#endif //__DNSTATUS_H__


