#ifndef __USBTXRX_H__
#define __USBTXRX_H__

void MenuUsbTransmit(HWND hwnd);
void MenuUsbTransmitHistory(HWND hwnd, int history);
void MenuUBOOTHistory(HWND hwnd, int history);
void MenuUBOOTHistory2(HWND hwnd, int history);
void MenuUBOOT(HWND hwnd);
void MenuUBOOT2(HWND hwnd);
void MenuUsbReceive(HWND hwnd);
void MenuUsbStatus(HWND hwnd);
int IsUsbConnected(void);
WORD ROM_MenuUBOOT2(HWND hwnd, int Fileindex);
BOOL RAM_MenuUsbTransmit(HWND hwnd, int Fileindex);

#endif //__USBTXRX_H__

